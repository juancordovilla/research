function RunExample
%Run Example: take

%Add path
addpath('./Fun')


% Input Signal
t = 0:0.001:2;
y = chirp(t,100,1,200,'quadratic'); %chirp signal (ascending tone)


%Basic Parameters
P.FSamp     = 16000; %Sample Freq in Hz of the signal
P.FLSec     = 0.032; %Frame Length in seconds
P.FSSec     = 0.010; %Frame Shift in seconds
P.NCH       = 26;   %Number of Channels for Mel
P.CepL      = 13;   %Lenth of Ceptrum. The first one correspond to C0 (~energy). If 13: [C0 C1 ....C12]
P.MF        = -7.6362;  %Min Floor in Log-Mel-Msd. You can put 0 if not sure. -7.6 for .wav speech signals with amplitude [-1,1]

%Derived Parameters
P.MinMS     = exp(P.MF); 
P.FL        = P.FSamp*P.FLSec; 
P.FS        = P.FSamp*P.FSSec; 
P.N2pi      = 2^ceil(log2(P.FL*2));
P.win       = hamming(P.FL); %window for spectrogram


%Obtein representations 
[My, nf]=Segmx(y,P.FL,P.FS); %Segmentation. nf is number of frames
[Y, xx]=Msd(My,'x',P.N2pi,P); %Magnitude spectrogram
Fby=SmoothFreqCompr(Y,P.NCH,P.FSamp,P.N2pi,P.MF); %Log-Mel spectrogram
Cxest=Fbank2Cepst(Fby,-1,P.CepL,0,1,0); %Cepstrogram
CxestD=AppDeltas(Cxest,2,2,'feat'); %Cepstrogram with Delta and Delta+Delta



%Plot representations
subplot(511), plot(y), xlim([1 length(y)])
subplot(512), imagesc(Y)
subplot(513), imagesc(Fby)
subplot(514), imagesc(Cxest)
subplot(515), imagesc(CxestD)




