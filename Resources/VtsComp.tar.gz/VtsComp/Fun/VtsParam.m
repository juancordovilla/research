function P=VtsParam(ResDir)
%VTS Parameters

P.FLSec     = 0.032; %Frame Length in Seconds
P.FSSec     = 0.010; %Frame Shift in Seconds
P.NCH       = 32; %Number of Channel (Mel or Gammatone filterbank)
P.MF        = -8; %Minimum Floor
P.ImputeGmmDir = [ResDir '/VtsGmm']; %Inputation Vts Gmm Directory
P.ImpNGaus  = '128'; %Inputation Number of Gaussians
