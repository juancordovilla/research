function CList=CListFExtDir(Dir,Ext)
%Cell List of File with Extention of a Directory 

fy=dir([Dir '/*' Ext]); 
l=size(fy,1);
CList=cell(l,1);
for i=1:l
    CList{i}=[Dir '/' fy(i).name];    
end


