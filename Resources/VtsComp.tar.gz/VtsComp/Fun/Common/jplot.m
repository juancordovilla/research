function jplot(x,c)
%Juan Plot

%Color
if nargin <2
    c='b';
end


%Concert to column
[ns,nch]=size(x);
if ns~=1
    xma=ns;
else
    xma=nch;
end


%Limits
xmi=1;
ymi=min(x(:))-1.2*abs(min(x(:)));
yma=1.2*max(x(:))+eps;


%Plot
plot(x,c),axis([xmi xma ymi yma])

