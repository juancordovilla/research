function P=DerivParam(P)
% Important Derived Parameters

P.FL        = P.FSamp*P.FLSec; 
P.FS        = P.FSamp*P.FSSec; 
P.N2pi      = 2^ceil(log2(P.FL*2));
P.win       = hamming(P.FL); 
