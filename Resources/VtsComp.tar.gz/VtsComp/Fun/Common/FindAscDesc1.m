function [ai,di]=FindAscDesc1(Vad)
%Find Ascending Descending 1 (output the indexes of 1)


[nch,nf]=size(Vad);
if nch~=1
    Vad=Vad';
end


%nf=length(Vad); Vad(1)=0; Vad(nf)=0; %to ensure that Vad start and end with 0
a=Vad==1&[0 Vad(1:nf-1)]==0; ai=find(a==1);
d=Vad==1&[Vad(2:nf) 0]==0; di=find(d==1);

