function  Fbxest=TmpVTSEnh(Fby,Fbnest,k,P)
%


[NCH,nf]=size(Fby);




% Load Model
fprintf('Imputation %s with model: %s\n',k,P.ImputeGmmDir);
load([P.ImputeGmmDir '/Gmm.mat']); P.GMM=mix;



%

switch k
    
     case 'Vts'
        Fbxest=Impute(P.GMM,Fby,Fbnest,-1,P.MF,'Vts');
    
    
    case 'VtsCov'        
        %FLFr=20; M=[Fby(:,1:FLFr) Fby(:,end-FLFr:end)]; v=var(M,0,2); CovFbnest=repmat(v,[1, nf]);
        v=var(Fbnest,0,2); CovFbnest=repmat(v,[1, nf]);        
        Fbxest=Impute(P.GMM,Fby,Fbnest,CovFbnest,P.MF,'VtsCov');	
        
    case 'VtsCov0'
        CovFbnest=zeros(NCH,nf); 
        Fbxest=Impute(P.GMM,Fby,Fbnest,CovFbnest,P.MF,'VtsCov');
end        
        
     
%IMPORTANT: Check output
i=isnan(Fbxest)|isinf(Fbxest);
if sum(i(:))>0
    Fbxest(i)=P.MF;
    fprintf('WANING in TmpVTSEnh: Some NaN or Inf replaced by P.MF\n');
end

% subplot(411), jimagesc(Fby)
% subplot(412), jimagesc(Fbx)
% subplot(413), jimagesc(Fbn)
% subplot(414), jimagesc(Fbxest)
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



