function [VN,VK]=VadNoise(Y,vad,ClK)
%Closest K for the mean

if sum(not(vad))==0
    fprintf('WARNING in VadNoise: there isnt silences in vad\n')
end

VK=false(size(Y)); VK(:,vad==0)=1;
VN=IntMKnownP(Y,VK,ClK);


