function UttC=DrawTextUttGr(NU)
%Draw Text Utterances from a Grammar
%NU: Number of Utterances

UttC=cell(NU,1);
for i=1:NU
    UttC{i}=DrawDIRHACom;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Com=DrawDIRHACom
%

S={'<SIL>'}; %Silence or Short pause
K={'DIRHA' 'DIRHA <SIL>'}; %Keyword
A={'Set 5 degrees' 'Switch to channel 5' 'Open' 'Close'}; %Action
O={'The temperature' 'The window' 'The television'}; %Object
P={'Of the kitchen' 'Of the livingroom'}; %Place
Com=[RaW(S) ' ' RaW(K) ' ' RaW(A) ' ' RaW(O) ' ' RaW(P) ' ' RaW(S)];


function W=RaW(WC)
%Random Word
l=randi(length(WC));
W=WC{l};