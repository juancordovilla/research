function mix=gmm(nparams, ncentres, covar_type)
%
%.nparams?? .ncentres, .covar_type

mix.nparams=nparams;
mix.ncentres=ncentres;
mix.covar_type=covar_type;
