function ReSampDir(DI,DO,fso,Ext)
%Change Sample Freq of a Dir


[s,m,n] = rmdir(DO,'s'); mkdir(DO); 

fx=dir([DI '/*' Ext]); 
l=size(fx,1); 

for i=1:l
    
    
    fi=[DI '/' fx(i).name];
    fo=[DO '/' fx(i).name];  
    fprintf('%d/%d:%s\n',i,l,fo);
    %[xi,fsi]=WavReadTUGrazStudio(fi);  
    [xi,fsi]=audioread(fi); 
    [N,D] = rat(fso/fsi);
    xo=resample(xi,N,D);      
    audiowrite(fo,xo,fso); 
   
%     subplot(211), plot(xi),
%     subplot(212), plot(xo), pause

end












