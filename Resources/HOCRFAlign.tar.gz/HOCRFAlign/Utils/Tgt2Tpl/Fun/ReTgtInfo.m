function Info=ReTgtInfo
%
%
Info.SSAcc.SS3StOrd='HEL';
Info.SSAcc.SS8StOrd='HGIEBTSL';
%
Info.SSAcc.AccStOrd='BME';
Info.SSAcc.AccStN=[1 2 3]; %Acc State Numbers
Info.SSAcc.RAccMax=[10 42 100]; %RAcc Maximum. from http://raptorx.uchicago.edu/documentation/ values I think for relative (not absolute)
%In case TG error: C1 is prob (not SS3:   H     E     L ...) and C(end) is # (not prob)   