function DIS=ReDisoPred(A)
%
Z=jtextscan(A,' %d %c %c %f %f');
DIS.Seq=Z{2};
DIS.Dis=Z{3};
DIS.DisM=[Z{4} Z{5}];
