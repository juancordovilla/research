function C=ReLinF(FeatF)
%Read Lines of a File
fi=fopen(FeatF,'r');

if fi==-1
    %error('Not exists: %s\n',FeatF)
    warning('Not exists: %s\n',FeatF); C=-1;
else
    
    %Count number of lines
    C2 = textscan(fi,'%s','delimiter','\n'); C2=C2{:};
    fclose(fi);
    l=length(C2);
    
    %Read removing newline characters
    C=cell(l,1);    
    fi = fopen(FeatF);    
    l = fgetl(fi);
    i=1;
    while ischar(l)
        C{i}=l;
        l = fgetl(fi);
        i=i+1;
    end    
    fclose(fi);
    
    
    
    
end