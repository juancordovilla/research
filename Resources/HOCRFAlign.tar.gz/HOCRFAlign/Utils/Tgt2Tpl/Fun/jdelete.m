function jdelete(F)
%

if iscell(F)
    l=length(F);
    for  i=1:l    
        jdelete1F(F{i});
    end
else
     jdelete1F(F);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%

function jdelete1F(F)
%
if isdir(F)
    [x,x,x]=rmdir(F, 's');
else
    if exist(F,'file')
        delete(F);
    end
end