function V=PostM2FuzzyLabV(PoM)
%Posterior Matrix To Fuzzy Label Vector 
%PoM: posterior Matrix p(y|x), each row sum  1
%if there are 3 columns V is a number (0,3).
%e.g: PoM(1,:)=[0.002053 0.114514 0.883433] then V=2.8834
%PoM(1,:)=[0.33 0.333 0.33] V=1.33

[v,p]=max(PoM,[],2); V=p-1+v;

