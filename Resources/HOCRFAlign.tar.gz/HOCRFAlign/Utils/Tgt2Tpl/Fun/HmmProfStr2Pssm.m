function LPSSM=HmmProfStr2Pssm(S)
%Hmm Profile Structure To Pssm
%LPSSM: can conteins -Inf (correspond to Pr=0 or '*' in Hmm)
%
%From: Aydin15_"Learning sparse models for a dynamic Bayesian network classifier of protein secondary structure".
%https://bmcbioinformatics.biomedcentral.com/articles/10.1186/1471-2105-12-154

%
L=S.ModelLength;


LMa=S.LMatchEmission;
LNu=repmat(S.LNullEmission,[L,1]) ;

% Ma=S.MatchEmission;
% Nu=repmat(S.NullEmission,[L,1]) ;
% %
% %PSSM=Ma;   
% PSSM=Ma./Nu;         %Best results
% %PSSM=log(Ma)-log(Nu);       
% %PSSM=log(Ma)-log(Nu);    PSSM=1./(1+exp(-PSSM));          
% 
% %Log-PSSM
% A=log(PSSM); A(isinf(A) | isnan(A))=0; LPSSM=A; 



%
A=LMa-LNu; 
LPSSM=A'; %transpose here, for Juan's format (where every column is an aa)
