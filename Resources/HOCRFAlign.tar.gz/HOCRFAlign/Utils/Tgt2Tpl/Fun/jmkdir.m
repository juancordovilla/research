function jmkdir(Dir,kind)
%Dir can a path or a cell of paths
%kind: 's' (silent mode)

if nargin<2
    kind='n';
end

if iscell(Dir)
    L=length(Dir);
    for i=1:L
        jmkdir2(Dir{i},kind);
    end
else
    jmkdir2(Dir,kind);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%
function jmkdir2(Dir,kind)
%
if ~exist(Dir,'dir')
    [pn,bn]=fileparts(Dir);
    if exist(pn,'dir')
        [x,x,x]=mkdir(Dir);
    else
        if kind=='n'
            warning('using mkdir -p');
        end
        system(['mkdir -p ' Dir]);
    end
end