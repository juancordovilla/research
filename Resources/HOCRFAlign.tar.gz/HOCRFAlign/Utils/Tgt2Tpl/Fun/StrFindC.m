function IJC=StrFindC(TexC,PatC)
%String Find in the Cells. Find the patterns (PatC) in the texts (TextC)
%IJC: rows and columns where PatC found (ERROR FUTURE: for some reason the
%J is not exact)
%PatC: {'hola' 'aquel'}
%TexC: {{'esto hola'} {'killo aquel'}}



%As usually PatC smaller than TexC the loop is in PatC
NT=length(TexC); %Number of Texts
NP=length(PatC); %Number of Patterns
r=1:NT; %rows


IJC=cell(1,NP);
for p=1:NP      

    
    %I: rows where PatC{p} found
    %J: columns "
    J=strfind(TexC,PatC{p});    
    a=~cellfun(@isempty,J);
    I=r(a);      
    
    %Join  
    IJ=[];
    for i=I       
       a=[repmat(i,[length(J{i}),1]) J{i}']; 
       IJ=[IJ;a];          
    end        
   IJC{p}=IJ;        
   
   
end




