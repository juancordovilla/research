function A=Str2NumC(C)
%String To Number of a Cell of Strings
%C: Cell of Strings (of numbers) { '-2'    '4'    '-1'    '-1'    '-5'   '3'    '3'}    
%A: Array of Numbers  [-2     4    -1    -1    -5     3     3    -3    ]
b=sprintf('%s ',C{:});
A=sscanf(b,'%f'); 

