function WrLinF(TmpF,C,k)
%Write Lines in a File. C is a cell of strings

if nargin<3
    k='n'; %Silent mode
end


jdelete(TmpF);


L=length(C);
fi=fopen(TmpF,'w');
for i=1:L
    fprintf(fi,'%s\n',C{i});
end
fclose(fi);


if k=='n'
    fprintf('Written: %s\n',TmpF);
end
