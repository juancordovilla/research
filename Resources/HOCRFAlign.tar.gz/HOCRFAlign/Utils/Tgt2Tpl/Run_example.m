function Run_example
%





addpath('./Fun')


%         DBName: 'DeepFr'
%          ExOpt: [1×1 struct]
%      JProgrDir: '/home/jamc/Eiweiss/JProgr'
%         ResDir: '/home/jamc/Eiweiss/Results'
%      DbSoftDir: '/home/jamc/Eiweiss/DbSoft'
%          WDir2: '/home2/jamc/Eiweiss'
%          JHome: '/home/jamc'
%          RecSt: 'FEExt'
%           OptV: [1 1 1 1 0 0 1 0]
%        MScrDir: '/home/jamc/Eiweiss/JProgr/MatScripts'
%          DbDir: '/home/jamc/Eiweiss/DbSoft/BioDb/FoldRec/DeepFr'
%         PdbDir: '/home/jamc/Eiweiss/DbSoft/BioDb/FoldRec/DeepFr/Pdb/AllPdb'
%       ExtFeDir: '/home/jamc/Eiweiss/DbSoft/BioDb/FoldRec/DeepFr/Feat'
%     BioSoftDir: '/home/jamc/Eiweiss/DbSoft/BioSoft'

RaptTplFe('./Tpl','1aab-d1aab','./Tgt','./PdbTool') 