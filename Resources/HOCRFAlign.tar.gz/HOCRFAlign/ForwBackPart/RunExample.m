function RunExample
%Example to show that the forward and the backward partition-functions of a
%1st-CRF-Align match when we use the paper formulation (eq. 3a and 3b) 
%This is a proof of concept.

%Parameters (you can modify Lq and Lt)
NSt=3; %Number of States
Lq=41; %Query Length
Lt=45; %Template Length

%Log of scoring-function matrix Log(Psi) (eq. 1)
LPM=randn(NSt,NSt,Lq,Lt);

%Log of forward and backward partition-functions (LZf and LZb). 
%Check that both are the same (eq. 5)
[LZf,LZb]=LForwBackPart(LPM)


