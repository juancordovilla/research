﻿HOW TO USE EstPdbAli

- EstPdbAli (Estimate Pdb from Alignment) is a program that takes a query protein sequence and a PDB file of a template protein and estimates their alignment and the PDB file of the query protein. Difference aligners are allowed: Crf1 [Morales18], Crf2 [Morales18], CNFPred [Ma12] and MatG [Matlab-NWAlign]. Optionally you can indicate the query/template residues positions where the alignment should starts and ends.

- The binary program EstPdbAli (Estimate Pdb from Alignment) has been compiled with Matlab16b to run on a Linux_X86_64 (Kubuntu 16.04) platform. To run it you need either a Matlab16b installation or easier, a Matlab Runtime Libraries R2016b for Linux that you can download from https://uk.mathworks.com/products/compiler/matlab-runtime.html. 

- To execute the example RunExample.sh:
    1) Install the external software in BioSoftDir as indicated below.
    2) Adapt the three paths of the parameter file In/Param.txt: BioSoftDir (Bio-Software Directory), ExtFeDir (External Feature Directory), and CrfModDir  (Crf1 and Crf2 Models Directory).
    3) Adapt the path of the McrRoot at RunExample.sh
    4) Run in a terminal RunExample.sh and check that the result in ./Out/1oav-d1iva@1emo-d1emo_1.fasta is:
    >1emo-d1emo_1
    SAVDMDE-CKEP-----DVCKHGQCINTDG--SYRCECPFGYILAGNECVD
    >1oav-d1iva
    KKKCIAKDYGRCKWGGTPCCRGRGCICSIMGTNCECKPRLIMEGLGLA---

- The most time consuming part is the feature extraction. If the .tgt and .tpl are already provided (in $ExtFeDir/Rapt/Tgt and Tgt) this time is considerably reduced.
    
    

    

INSTALL EXTERNAL SOFTWARE

You must install all the external software in a BioSoft directory named exactly as explained below. CNFPred is used to extract the features (.tpl and .tgt files) but it can be used also as an aligner for comparisons.

1) PDB_Tool: must be installed in the folder BioSoft/RaptorX_XuGroup_UnivChica/PDB_Tool
I already provide it for Linux_X86_64. Otherwise install from here: https://github.com/realbigws/PDB_Tool

2) Modeller: in BioSoft/Modeller_UniCaliforniaSanFranc/modeller-9v8
- Download from: http://www.salilab.org/modeller/9v8/modeller-9v8.tar.gz
- Unzip, change name of unzipped folder modeller-9v8 to modeller-9v8Unz, go to modeller-9v8Unz, execute ./Install and answer the three questions as: 
System: x86_64
Absolute Path: CORRESPONDING_PREVIOUS_PATH/BioSoft/Modeller_UniCaliforniaSanFranc/modeller-9v8
License: MODELIRANJE

3) CNFSearch: in BioSoft/RaptorX_XuGroup_UnivChica/CNFsearch1.66_release
- Go to: http://raptorx.uchicago.edu/download/amFtY0B1Z3IuZXM=/
- Download CNFsearch1.66_release.zip and copy in BioSoft/RaptorX_XuGroup_UnivChica 
- Unzip, go to CNFsearch1.66_release and execute ./setup.pl


 
4) BIG DATABASES FOR FEATURE EXTRACTION: in /BioSoft/RaptorX_XuGroup_UnivChica/CNFsearch1.66_release/databases/NR_new
- Go to http://raptorx.uchicago.edu/download/amFtY0B1Z3IuZXM=/
- Download nr70.tar.gz and nr90.tar.gz (it can take 30 min)
- Go to BioSoft/RaptorX_XuGroup_UnivChica/CNFsearch1.66_release/databases and create a folder named NR_new
- Unzip both and copy their content in NR_new
NOTE: If you already have NR_new in other folder you can link it as:
ln -s .../BioSoft/RaptorX_XuGroup_UnivChica/CNFPred/CNFsearch1.66_release/databases/NR_new 
.../BioSoft/RaptorX_XuGroup_UnivChica/CNFsearch1.66_release/databases/NR_new


LICENSE

Software and Data conform to the PLOS-ONE Open Source Definition 
(http://journals.plos.org/plosone/s/materials-and-software-sharing#loc-sharing-software)



HELP

For any question: Dr. Juan A. Morales-Cordovilla. jamc@ugr.es


REFERENCES

[Morales18] Juan A. Morales-Cordovilla, Victoria Sanchez Calle, Martin Ratajczak.
"Protein alignment based on higher order conditional random fields for template-based modeling".
PLOS-ONE, 2018 (in revision)

[Ma12] J. Ma, J. Peng, S. Wang, J. Xu. "A conditional neural fields model for protein
threading". Bioinformatics. 28(12):59-66. 2012;
