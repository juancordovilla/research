MATERIAL AND PROGRAM USED IN THE PAPER

Juan A. Morales-Cordovilla, Victoria Sanchez Calle, Martin Ratajczak.
"Protein alignment based on higher order conditional random fields for template-based modeling".
PLOS-ONE, 2018

You can find the following folders:

- Databases: all the list files used for training, validation and test.
- Program: our binary Linux-Matlab16b program EstPdbAli (Estimate Pdb from Alignment) with an example of used.
- Results: summary and detailed description of the results.
- ForwBackPart: Matlab example that shows the computation of the forward and backward partion functions.
- Utils: 
    Tgt2Tpl: input: PdbTool-files (from Pdb-file) and Tgt-file (from buildFeat), output: Tpl

LICENSE

Software and Data conform to the PLOS-ONE Open Source Definition 
(http://journals.plos.org/plosone/s/materials-and-software-sharing#loc-sharing-software)

HELP

For any question: Dr. Juan A. Morales-Cordovilla. jamc@ugr.es





