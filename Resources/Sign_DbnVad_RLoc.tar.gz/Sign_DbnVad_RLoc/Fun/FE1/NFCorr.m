function aspectrum=NFCorr(aspectrum_tmp,nf)
%Number of Frame Correction
[nch_tmp nf_tmp]=size(aspectrum_tmp);
aspectrum=min(aspectrum_tmp(:))*ones(nch_tmp,nf);
nfmi=min(nf_tmp,nf);
aspectrum(:,1:nfmi)=aspectrum_tmp(:,1:nfmi);

