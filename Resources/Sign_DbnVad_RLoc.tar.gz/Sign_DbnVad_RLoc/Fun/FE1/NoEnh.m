function [Fby,py]=NoEnh(y,ys,Room,P,x,xs)
%No Enhancement


l=P.OctChN-1; P.OctChHz=P.MiPitHz*2.^(log2(P.MaPitHz/P.MiPitHz)*(0:l)/l); 
P.OctChSa=round(P.FSamp./P.OctChHz); P.OctChSa=P.OctChSa(end:-1:1);


[My nf]=Segmx(y,P.FL,P.FS);

Y=Msd(My,'x',P.N2pi,P);        
Fby=SmoothFreqCompr(Y,P.NCH,P.FSamp,P.N2pi,P.MF);        
py=AcPitch(My,P); 


% subplot(211), imagesc(My)
% subplot(212), imagesc(TG)
% 12
% pause
