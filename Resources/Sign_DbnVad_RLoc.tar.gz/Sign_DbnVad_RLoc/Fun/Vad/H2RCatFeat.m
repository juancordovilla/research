function FHFeat=H2RCatFeat(HFeat,NRoom)
%Home to Room Cat Feat
FeatL=size(HFeat,1)/NRoom;
FHFeat=[];
for i=1:NRoom
    FHFeat=[FHFeat HFeat((i-1)*FeatL+1:i*FeatL,:)];             
end 
