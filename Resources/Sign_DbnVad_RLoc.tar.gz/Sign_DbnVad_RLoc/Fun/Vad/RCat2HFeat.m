function HFeat=RCat2HFeat(FHFeat,NRoom)
%Room Cat Feat To Home Feat
[FeatL,anf]=size(FHFeat);
nf=anf/NRoom;
HFeat=zeros(NRoom,nf);
for i=1:NRoom
    HFeat((i-1)*FeatL+1:i*FeatL,:)=FHFeat(:,(i-1)*nf+1:i*nf);      
end 
