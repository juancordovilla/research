function [UadNoLoc]=DbnHUttActDet(ys,xs,do,bn,P,XVad,XVadNoLoc)
%

%Home Feature Extraction (very heavy so we can safe this data for future)
a=[do '/HFeatMat.mat'];
if ~exist(a,'file')
    HFeat=HVadFeat(ys,xs,do,bn,P,'f');
    save(a,'HFeat'); 
else
    load(a);
end


%Estimate VAD with DBN
NRoom=length(P.ARoomN);        
CatHFeat=H2RCatFeat(HFeat,NRoom);  
CatXVadNoLoc=H2RCatFeat(XVadNoLoc,NRoom);     CatXVadNoLoc=[CatXVadNoLoc; not(CatXVadNoLoc)]; %to be always sum prob = 1    
CatPr=JuanClassify(CatHFeat,CatXVadNoLoc,[do '/VadTrFeat' bn],[P.VadDbnMDir],P.TempP.VadTrF,'Dbn');  
CatPr=CatPr(1:end-1,:); %1x(5*nf)   (it doesn't  consider the compensate class (the last class to have sum probability 1))
Pr=RCat2HFeat(CatPr,NRoom);
VadNoLoc=Pr>0.65; %The output is clear 0 or 1
        
%VAD to Utterance Activity Detection               
UadNoLoc=HVad2Uad(VadNoLoc,P);







