function [hx,th]=MagOrdThr(sx)
%Manitude Order Thresholding (binarization)
%sx: soft x (En=sqrt(mean(My.^2));)
%hx: hard x (vad)


mu=mean(sx); th=mu+2*std(sx(sx<mu)); %Juan Formula
th=ones(size(sx))*th;
hx=sx>th;