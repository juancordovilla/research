function S=StArFNFiller(IS,FN,v)
%Structure Array Field Name Filler (relleno)
%IS: Input Structure
%FN: Field Name 
%v: vector (cell or array)



S=IS;

N=length(S);

c=class(v);

switch c
    case 'cell'
        for i=1:N;   S(i).(FN)=v{i};   end
    case 'double'
        for i=1:N;   S(i).(FN)=v(i);   end
end




