function Cl=ClPr2Cl(Y)
%Y each column is a sample NCl*NSamples
%Cl=[0 1 2 ..];
[v,p]=max(Y);
Cl=p-1;
