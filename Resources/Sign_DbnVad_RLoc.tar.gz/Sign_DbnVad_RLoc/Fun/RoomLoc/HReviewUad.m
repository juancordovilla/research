function Uad=HReviewUad(UadI,UttL)
%Remove too short utteranceces
[NRoom,nf]=size(UadI);
Uad=UadI;
for i=1:NRoom
    Uad(i,:)=ReviewUad(UadI(i,:),UttL);      
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Uad=ReviewUad(UadI,UttL)
%
%Remove short
Uad=bwareaopen(UadI,round(UttL/2)); 

%Remove long
UttLMa=UttL*3;
[a,d]=FindAscDesc1(Uad); s=d-a;
for i=1:length(a)
    if s>UttLMa
        Uad(a(i):UttLMa:d(i))=0;        
    end
end
