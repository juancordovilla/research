function Uad=Fad2UttLoc(Fad,UadNoLoc,P)
%From Feat Actt Det (hard with steps) 2 Utt Localization
[NRoom,nf]=size(Fad);
Uad=zeros(NRoom,nf);
[v, p]=max(Fad);
ind=sub2ind([NRoom, nf],p,1:nf);
Uad(ind)=1;
ind=UadNoLoc==0; Uad(ind)=0;

Uad=HReviewUad(Uad,P.UttL);

% figure(1), PlotHUad(Fad);
% figure(2), PlotHUad(UadNoLoc);
% figure(3), PlotHUad(Uad);
% pause




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function MaIad=Feat2HUttLoc2(Fad)
% %From Fad To Iad with Room Selection
% %Meaning of Th for grouping:
% %----   ----    ----    ----        ----
% %----    ----     ----      ----        ----
% %Th:0   0.25    0.5     0.75        1.0
% 
% Th=0.25; %Group below this Th (see meaning above)
% 
% [NRoom,nf]=size(Fad);
% IadF=IadFeat(Fad);
% MaIadF=GroupDel(IadF,Th);
% MaFad=IadF2Fad(MaIadF,NRoom,nf);
% MaIad=MaFad>0;
% 
% %  %
% %  1
% %  figure(1)
% %  for i=1:NRoom
% %     subplot(NRoom,1,i), plot(Fad(i,:))
% %  end
% %  figure(2)
% %  for i=1:NRoom
% %     subplot(NRoom,1,i), plot(MaIad(i,:)), ylim([0 1.2])
% %  end
% %  22, pause
% 
% 
% function Fad=IadF2Fad(IadF,NRoom,nf)
% %
% Fad=zeros(NRoom,nf);
% l=size(IadF,1);
% for i=1:l
%   A=IadF(i,1); 
%   D=IadF(i,2); 
%   E=IadF(i,4); 
%   R=IadF(i,5);
%   Fad(R,A:D)=E;
% end
% 
% 
% function MaIadF=GroupDel(IadF,Th)
% %Groupe and Delete
% %A=IadF(:,1);D=IadF(:,2);L=IadF(:,3);E=IadF(:,4);R=IadF(:,5);
%  MaIadF=[];
% while (size(IadF,1)>0)
%   %size(IadF,1)
%   [m p]=max(IadF(:,4)); %E Max
%   MaIadF=[MaIadF; IadF(p,:)]; %Append   
%   grp=Group(p,IadF,Th); %Group
%   IadF(grp,:)=[]; %Delete 
% end
% 
% 
% 
% function grp=Group(p,IadF,Th)
% %
% MaA=IadF(p,1); MaD=IadF(p,2); 
% A=IadF(:,1); D=IadF(:,2); L=IadF(:,3);
% e=(abs(MaA-A)+abs(MaD-D))./(L);
% grp=e<Th;
% 
% 
% 
% 
% function IadF=IadFeat(Fad)
% %
% [NRoom,nf]=size(Fad);
% Iad=Fad>0;
% IadF=[];
% for i=1:NRoom
%   [A,D]=FindAscDesc1(Iad(i,:));
%   l=length(A);
%   R=i*ones(1,l); E=zeros(1,l);
%   for j=1:l; E(j)=mean(Fad(i,A(j):D(j))); end 
%   L=D-A;
%   aux=[A' D' L' E' R'];
%   IadF=[IadF; aux];
% end
% 
% 
% 
