function Uad=UttRLoc(UadNoLoc,ys,do,bn,RoomLK,P,XUadNoLoc,XUad)
%Utterance Room Localization (in which room is the utterance)
%kind: Pr or En

yr=All2MicSign(ys,P.AMicN,P.ARoomRefMicN); yr=yr(1:P.FL:end,:)'; %y reference





Uad=[];
switch RoomLK
    case 'Oracle' %XUad
        Uad=XUad;        
        
    case 'MaxE' %Max of Energy
        F=HSelMicE(ys,P.ARoomRefMicN,P); %Home Ref Microphone Energy    
        
    case 'MaxSnr' %Max of Snr
        F=HUad2Snr(UadNoLoc,ys,P);          
        
    case 'Dbn'
        F=ClRoomLoc(UadNoLoc,ys,do,bn,'Dbn',P,XUadNoLoc,XUad);      
        
    case 'Nn'
        F=ClRoomLoc(UadNoLoc,ys,do,bn,'Nn',P,XUadNoLoc,XUad);
        
    case 'LinDa'
        F=ClRoomLoc(UadNoLoc,ys,do,bn,'LinDa',P,XUadNoLoc,XUad);
        
    case 'QuadDa'
        F=ClRoomLoc(UadNoLoc,ys,do,bn,'QuadDa',P,XUadNoLoc,XUad);
        
    case 'Svm'
        F=ClRoomLoc(UadNoLoc,ys,do,bn,'Svm',P,XUadNoLoc,XUad);        
               
end


if isempty(Uad)
    Fad=HUad2Fad(UadNoLoc,F);
    Uad=Fad2UttLoc(Fad,UadNoLoc,P);    
end






% E=HSelMicE(ys,P.ARoomRefMicN,P); %Home Ref Microphone Energy  
% Fad=HUad2Fad(UadNoLoc,E);% 
% figure(1), PlotHUad(UadNoLoc);
% figure(2), PlotHUad(XUad);
% pause








