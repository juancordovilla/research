function PrClO=ClRoomLoc(UadNoLoc,ys,do,bn,ClKind,P,XUadNoLoc,XUad)
%Classification based Room Localizer


%
Mcc=HMicCC(ys,P); 
E=HSelMicE(ys,P.ARoomRefMicN,P); %Home Ref Microphone Energy



if P.TempP.URLocTrF  
  [Snr,SnrPerAd]=HUad2Snr(XUadNoLoc,ys,P);     
  XUad=RevXUad(XUad);   
  [Feat,PrCl,i]=Uad2FeatPrCl1s(E,SnrPerAd,Mcc,XUad);    
  [Feat,PrCl]=UniFeatRed(Feat,PrCl);   
  xx=JuanClassify(Feat,PrCl,[do '/RLocTrFeat' bn],-1,1,-1);   
  PrClO=zeros(size(UadNoLoc));  
else    
  [Snr,SnrPerAd]=HUad2Snr(UadNoLoc,ys,P);  
  [Feat,xx,i]=Uad2FeatPrCl1s(E,SnrPerAd,Mcc,UadNoLoc);
  PrCl=JuanClassify(Feat,-1,-1,[P.RoomLocMDir],0,ClKind);
  PrClO=zeros(size(UadNoLoc)); PrClO(:,i)=PrCl;  
end


% figure(1), PlotHUad(UadNoLoc);
% figure(2), PlotHUad(PrClO);
% 2, pause



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Feat,PrCl,i]=Uad2FeatPrCl1s(E,SnrPerAd,Mcc,Uad)
%Uad To Feat and PrCl of only 1s in Uad
[MccadO]=HUad2Fad(Uad,Mcc);
[EadO]=HUad2Fad(Uad,E); i=SnrPerAd<0.15;
Ead=EadO;       Ead(i)=0;
Mccad=MccadO;   Mccad(i)=0;

% figure(1), PlotHUad(Uad);
% figure(2), PlotHUad(SnrPerAd);
% %figure(3), PlotHUad(Mcc);
% %figure(4), PlotHUad(SnrPerAd);
% 2, pause


Feat=[Ead;Mccad];
%Feat=[Ead]; 
PrCl=Uad;  
UadOr=OrMCh(Uad); i=UadOr(1,:);
Feat=Feat(:,i); PrCl=PrCl(:,i);


function [FeatO,PrClO]=UniFeatRed(Feat,PrCl)
%Unique Feat Reduction
a=Feat'; [b,i1,i2]=unique(a,'rows');
FeatO=a(i1,:)';
a=PrCl'; PrClO=a(i1,:)';





function XUadO=RevXUad(XUad)
%Revision of XUad (to avoid multiple 1s in one columns)
s=sum(XUad); i=s>1; 
XUadO=XUad; XUadO(:,i)=0;
