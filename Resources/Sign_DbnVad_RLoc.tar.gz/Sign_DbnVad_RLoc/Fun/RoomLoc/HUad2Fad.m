function [Fad]=HUad2Fad(Uad,Feat)
%Home Uad To Feature Activity Detection

[NRoom nf]=size(Uad);

Fad=zeros(NRoom,nf);
for i=1:NRoom
    Fad(i,:)=Fad1Room(Uad(i,:),Feat(i,:));    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Fad=Fad1Room(Uad,E)
%Uad Energy of One Room
%E: is in Amplitud. E=sqrt(mean((My.^2))); 
Fad=zeros(1,length(Uad));

[ai,di]=FindAscDesc1(Uad); %Mean for 1
for i=1:length(ai); int=ai(i):di(i); Fad(int)=mean(E(int)); end
[ai,di]=FindAscDesc1(not(Uad)); %Mean for 0
for i=1:length(ai); int=ai(i):di(i); Fad(int)=mean(E(int)); end
