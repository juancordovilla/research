function E=HSelMicE(ys,MicLa,P)
%House Feat Energy
NMic=length(MicLa);
E=zeros(NMic,P.TempP.nf);
yr=All2MicSign(ys,P.AMicN,MicLa); %y reference
for i=1:NMic        
      [E(i,:)]=RFeatE(yr(:,i),P);         
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [E]=RFeatE(y,P)
%Room Features Energy
%Energy
[My nf]=Segmx(y,P.FL,P.FS); E=sqrt(mean((My.^2))); %[UadE]=MeanF(UadE,120);

