function Isol=Info2OrTSLoc(y, x, do, bn, Info, P)
%Info To Oracle Temp-Spatio Localizater

l=length(Info);
a=P.DilVadLFr*P.FS;

%if (a~=0); fprintf('WARNING: Oracle st and en increased %d samples\n',a); end


for i=1:l
    
    st=str2double(Info(i).st);
    en=str2double(Info(i).en);
    
 
    st=max(1,st-a); en=min(length(y(:,1)),en+a);
    
    
    Isol(i).st=st; Isol(i).en=en;    
    Isol(i).y=y(Isol(i).st:Isol(i).en,:);
    Isol(i).x=x(Isol(i).st:Isol(i).en,:); 
    Isol(i).bn=Info(i).bn; 
    Isol(i).XPos=Info(i).pos;  
    Isol(i).XRoom=Isol(i).XPos(1);
    Isol(i).WTrans=Info(i).WTrans;
    
    %Isol(i).Pos=Isol(i).XPos;
    %Isol(i).Room=Isol(i).XRoom;
    
end

