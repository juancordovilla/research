function [XVad,XVadNoLoc,XUadNoLoc,XUad]=OracleInfo(ys, xs, do, bn, P)
%
XIsol=Info2OrTSLoc(ys, xs, do, bn, P.Info, P);
XRoom=StArFNExtract(XIsol,'XRoom'); 
XIsol=StArFNFiller(XIsol,'Room',XRoom); %Isol2Iad needs Room field
XUad=HIsol2Uad(XIsol,P);
XUadNoLoc=OrMCh(XUad);
[xx,XVadNoLoc]=HRIndUAD(xs,xs,do,bn,P,'MagOrdVad',XUad); XVad=XVadNoLoc.*XUad;
XVadNoLoc=XUadNoLoc;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [UadNoLoc,VadNoLoc]=HRIndUAD(ys,xs,do,bn,P,kind,XVadNoLoc)
%Home, Room Independenly UAD
NRoom=length(P.ARoomN);  

VadNoLoc=zeros(NRoom,P.TempP.nf);  
[rys,MicO]=All2MicSign(ys,P.AMicN,P.ARoomRefMicN);
[rxs,MicO]=All2MicSign(xs,P.AMicN,P.ARoomRefMicN);
for i=1:NRoom    
  fprintf('Vad %s for room: %d\n',kind, i);
  [VadNoLoc(i,:)]=Uad1Room(rys(:,i),ys,rxs(:,i),xs, do, bn, P, kind,XVadNoLoc(i,:));  
end
UadNoLoc=HVad2Uad(VadNoLoc,P);       



function [Vad]=Uad1Room(y,ys, x,xs, do, bn, P, kind,XVad)
%Uad (Isolate Activity Detection) for a Room
switch kind    
    case 'MagOrdVad';      
        Vad=MagOrdVad(y,P);
        
    case 'Afe';  
        Vad=AFEVad(y,do,bn,P,x,2);  
end