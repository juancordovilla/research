function y=TempGenSig(P,k)
%



%
Mic=P.AMicN;

Pi1=[100 200]+20;
Pi2=[200 100];
M1=[1 0 0;
    0 1 0;
    0 0 1];
M2=[0 0 1;
    0 1 0;
    1 0 0];

switch k
    case 1 %Cross Pit, Same Room, Common OnOffSet        
        M1=[0;
            0;
            1];        
        M2=[1;
            0;
            0];        
        Pi1=[100 200]+20;
        Pi2=[200 100];
        Du1=[1.5 2 1.5];
        Du2=[1.5 2 1.5];
        
        s1=GeEv(M1,Pi1,Du1,'K',P.FSamp,Mic);
        s2=GeEv(M2,Pi2,Du2,'K',P.FSamp,Mic);
        
    case 2 %Cross Spectral,
        M2=[1 0 0;
            0 1 0;
            0 0 1];  
        
        M1=[0 0 1;
            0 1 0;
            1 0 0];    
        
        Pi1=[150 80];
        Pi2=[300];
        Du1=[0.5 4 0.5];
        Du2=[1.5 2 1.5];
        
        s1=GeEv(M1,Pi1,Du1,'K',P.FSamp,Mic);
        s2=GeEv(M2,Pi2,Du2,'K',P.FSamp,Mic);
        

     
        

end

%y=s1+s2;

[y, x, n]=Mix(s1,s2,0,0);

% subplot(311), plot(s1)
% subplot(312), plot(s2)
% subplot(313), plot(s)
% pause




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function s3=GeEv(M,Pi,Du,Po,FSamp,Mic)
%Generate Event
%M: Magnitude spectrum, in Magn
%Pi: Pitch in Hz
%Po: Position 'K', 'L', etc. 
%Du: Duration in Sec (sil_ini, signal, sil_end)

S.M=M; 
S.PitHz=Pi;   
S.FSampHz=FSamp;
S.DurSec=Du(2);  
%Generate Event
[s,S]=Signals('GammSign',-1,S); 

%Append ini and end silence
zini=zeros(Du(1)*FSamp,1);
zend=zeros(Du(3)*FSamp,1);
s2=[zini; s; zend];  

%Simulate in different rooms
s3=s2;
[s3]=Mono2SimHouse(s2,FSamp,Po,FSamp,Mic);
size(s2)
size(s3)
pause





