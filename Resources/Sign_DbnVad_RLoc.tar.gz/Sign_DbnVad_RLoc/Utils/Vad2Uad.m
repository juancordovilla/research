function Iad=Vad2Uad(Vad,StL)
%Voice Activity Detection To Utterance Activity Detection
%Stick StL 1s
[ai,di]=FindAscDesc1(Vad);
nf=length(Vad);
ai=max(ai-StL,1);
di=min(di+StL,nf);
Iad=zeros(1,nf); 
for i=1:length(ai); Iad(ai(i):di(i))=1; end
