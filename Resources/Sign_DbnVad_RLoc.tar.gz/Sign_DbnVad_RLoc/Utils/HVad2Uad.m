function Uad=HVad2Uad(Vad,P)
%
Uad=Vad;
[NRoom]=size(Vad,1);
for i=1:NRoom
    Uad(i,:)=Vad2Uad(Vad(i,:),round(P.DilVadLFr));
end

