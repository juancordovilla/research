function TrDbnVadRLoc(do,bn,P)
%Train DbnVad and Room Localizer


FeatExt='.Feat';
VadExt='.ClPr';


%Train VadDbn
VadX=ReadHTKF([do '/VadTrFeat' bn FeatExt], 0, 0);   
VadY=ReadHTKF([do '/VadTrFeat' bn VadExt], 0, 0);
ClTr(VadX,VadY,P.VadDbnMDir,'Dbn');
  

%Train (P.RoomLK kind)
RLocX=ReadHTKF([do '/RLocTrFeat' bn FeatExt], 0, 0);   
RLocY=ReadHTKF([do '/RLocTrFeat' bn VadExt], 0, 0);
[MRLocX,MRLocY]=MoreRLocTrData;
RLocX=[RLocX MRLocX];
RLocY=[RLocY MRLocY];


ClTr(RLocX,RLocY,P.RoomLocMDir,P.RoomLK);















