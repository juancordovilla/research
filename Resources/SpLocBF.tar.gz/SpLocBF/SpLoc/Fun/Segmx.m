function [M, nf]=Segmx(x,FL,FS)
%Segmentation FL (Frame Length), FS (Frame Shift)


%Old option
% lx=length(x);
% nf=ceil((lx-FL)/FS);
% M=zeros(FL,nf);
% j=0;
% for i=1:FS:lx-FL
%     j=j+1;
%     M(:,j)=x(i:i+FL-1);    
% end


%New option
p=FL-FS; M=buffer(x,FL,p,'nodelay'); M(:,end)=[]; nf=size(M,2);

