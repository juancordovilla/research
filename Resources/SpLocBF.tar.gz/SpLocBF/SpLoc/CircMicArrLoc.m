function [axest]=CircMicArrLoc(ys,do,bn,kind,CAP,P)
%Circular Microphone Array -based Localization
%ys: multich signal
%do: output directory
%bn: base name
%kind:
%CAP: Circular Array Param
%P: Parameters
%axest: Angle Clean Estimation



switch kind 
    case 1 %Popi
		fprintf('PoPi SLoc ');
        %B=SiftPopiGramC(ys,CAP.MicRMe,CAP.MicADeg,do,bn,P);
        B=PopiGramC(ys,CAP.MicRMe,CAP.MicADeg,do,bn,P);  %142   360   651      
        
        % Marginalization across Pitch        
        C1=sum(B,1); %1 360   651     
        % Marginalization across Time
        C=squeeze(sum(C1,3)); %1 360      


%     case 2 %SrpPhat
% 		fprintf('SrpPhat SLoc ');
%         B=srpphat(ys, P.FLSec, P.FSSec, P.FSamp,P);
%         C=squeeze(sum(B,2));               

end

%Angle Clean Estimation 
[v axest]=max(C);

% axest
%         subplot(311), jplot(ys)
%         subplot(312), jimagesc(squeeze(C1))
%         subplot(313), jplot(C)
%         pause