#include <stdlib.h> //rand, abs, system 
#include <stdio.h> //fopen, printf 
#include <math.h> //sqrt, fabs, ceil



/*Triangle window*/
void Triang (float *w, int l)
{
	int lim, n;
	
	if(l%2==0)
		lim=l/2-1;	
	else
		lim=(l-1)/2;
		
	for(n=0; n<=lim; n++)
	{
		w[n]=(float)(2*n)/(float)(l-1);
		w[l-1-n]=w[n];		
	}	
}


