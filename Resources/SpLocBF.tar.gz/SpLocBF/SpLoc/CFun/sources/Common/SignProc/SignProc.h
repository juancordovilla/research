
#define PI 3.141592653589793 //pi with 15 decimals

void Triang (float *w, int l);
int XcorrV(float *r, float *x1, float *x2, int lx, char kind);
void XcorrM(float *R, float *X1, float *X2, int nr, int nc, char kind);
