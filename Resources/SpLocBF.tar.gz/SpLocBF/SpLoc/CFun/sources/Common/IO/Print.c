#include <stdio.h>
#include <sys/time.h> //for timeval
#include <stdlib.h>
#include <unistd.h>  // usleep()



//////////////////////////////////////////////// SubFun /////////////////////////////////////////////



//////////////////////////////////////////////// Fun /////////////////////////////////////////////
/*Printf (stdout) a Matrix*/
void PrintfM(float *M, int nr, int nc)
{
  int i, j;
  
	for(i=0; i<nr; i++)
	{			
		for(j=0; j<nc; j++)
		    printf("%f ", M[i+j*nr]); //M[i,j]
		printf("\n");			
	}
	getchar();
	
}


/*Printf (stdout) a Integer Matrix*/
void PrintfIntM(int *M, int nr, int nc)
{
  int i, j;
  
	for(i=0; i<nr; i++)
	{			
		for(j=0; j<nc; j++)
		    printf("%d ", M[i+j*nr]);
		printf("\n");			
	}
	getchar();
	
}