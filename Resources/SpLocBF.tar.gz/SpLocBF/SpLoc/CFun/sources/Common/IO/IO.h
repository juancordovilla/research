//

#define MaxFNL 100 //Max File Name Lenght (in characters)

typedef struct Param{     //
			  float FSamp;
			  float FLSec;
			  float FSSec;	
			  int NCH;
			  int MiADelSa;
			  int MaADelSa;
			  int MiPitSa;
			  int MaPitSa;
			  int Np;
			  int nf;
			  //Derivate			  
                          int FL;
                          int FS;			  
                          }Param;

float* ReHtkF(int *nr, int *nc, char *fn);
void ReStrF(Param *P, char *FName);
void CatFN(char *fn, char *dir, char *bn, char *ext);



//Print
void PrintfM(float *M, int nr, int nc);
void PrintfIntM(int *M, int nr, int nc);
