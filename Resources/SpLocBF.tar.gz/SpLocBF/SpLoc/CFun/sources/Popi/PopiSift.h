void PopiG(char *fn, float *C, int nr, int nc, Param P);
