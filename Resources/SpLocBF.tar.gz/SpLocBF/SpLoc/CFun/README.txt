To compile and execute: make; ../bin/PopiSift ../bin/DemoIO/I/alzn0180.Fby



