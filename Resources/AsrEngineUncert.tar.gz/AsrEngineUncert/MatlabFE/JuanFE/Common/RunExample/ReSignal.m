function [y,x,fs]=ReSignal(SpeechRootDBase,SpCond1SpCond2,bn)
%Read Signal (using reference channel) from the path [SpeechRootDBase '/' SpCond1SpCond2 '/' bn '.wav']
%y: noisy 
%x: clean
%fs: sample frequency
RefCh=5; %Reference channel
fy=[SpeechRootDBase '/' SpCond1SpCond2 '/' bn '.wav'];
[y,fs]=audioread(fy); y=y(:,RefCh);
fn=[SpeechRootDBase '/' SpCond1SpCond2 '_noise/' bn '.wav'];
[n,fs]=audioread(fn); n=n(:,RefCh);
x=y-n;

