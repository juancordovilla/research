function Y=Sign2Feat2(y,do,bn,HmmDir,k,P)
%Signal To Featuregram 
%Y: featuregram
%
%do: dir output for intermediate results
%bn: basename of intermediate results
%k: kind of feature
%P: Parameter structure

switch k
    case 'Fmllr'
        C=Sign2Feat(y,P,'Mfcc');  
        Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P);  
        Y=NormFeUn(Y,[HmmDir '/GPar'],'feat',P.ExOpt.MvnK,-1); 
    case 'Fbank'
        Y=Sign2Feat(y,P);
        
        
end
