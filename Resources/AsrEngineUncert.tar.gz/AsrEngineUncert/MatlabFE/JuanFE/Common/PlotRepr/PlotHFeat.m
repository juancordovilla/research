function PlotHFeat(Feat,CellText)
%Plot Home Feat (for all rooms)
FS=15;

if nargin < 2
    CellText={''};
end


[NRoom,FL,nf]=size(Feat);

% Feat=NormA(Feat); Feat=Feat*256;
% for i=1:NRoom
%     subplot(NRoom,1,i),  image(squeeze(Feat(i,:,:))),     
%     t=title(['Room ' num2str(i)]);    set(t, 'FontSize', FS);  
% end


ma=max(Feat(:));
er=ma*ones(round(FL/5),nf); 



A=[];
for i=1:NRoom    
    A=[A; squeeze(Feat(i,:,:)); er];
end

t=sprintf('%s ',CellText{:});
imagesc(A), axis xy, title(t)
