function PlotHSign(Iad)
%Plot Home Uad (for all rooms)
%Iad: NRoom*NSamples

FS=12;


[NRoom,nf]=size(Iad);
ma=max(Iad(:)); ma=ma+ma/5;
mi=min(Iad(:)); mi=mi-mi/5;
if(mi==ma); ma=mi+1; end


for i=1:NRoom
    fprintf('Plotting %d/%d\n',i,NRoom);
    
    subplot(NRoom,1,i), plot(Iad(i,:),'k'),  axis([1 nf mi ma]), 
    
    t=title(['Room ' num2str(i)]);
    
    if i==1
        
    elseif i==NRoom                   
        t=xlabel('time (samples)');         set(t, 'FontSize', FS); 
    else
        
    end
    
    
    set(t, 'FontSize', FS);  
end
 