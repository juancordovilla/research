function jplot(x,c)
%Juan Plot




%Concert to column
[ns,nch]=size(x);
if ns~=1
    xma=ns;
else
    xma=nch;
end


%Limits
xmi=1;


a=min(x(:));
b=max(x(:));
ymi=a-1.1*abs(a);
yma=b+1.1*abs(b); %1.2*max(x(:))+eps;


%Plot

%Color
if nargin <2
   plot(x,'b')
else
    plot(x,c) 
end






axis([xmi xma ymi yma])

