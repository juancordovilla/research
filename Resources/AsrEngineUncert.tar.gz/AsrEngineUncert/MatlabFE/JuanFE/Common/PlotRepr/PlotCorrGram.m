function PlotCorrGram(A,f,P)
%
%f: frame number to be plotted
%

MaPitSa=P.MaPitSa;


[nch,nk,nf]=size(A); 

AC=squeeze(A(:,:,f));

ma=max(AC(:));
mi=min(AC(:));

for i=1:nch
   s=AC(i,1:MaPitSa);    
   subplot(nch,1,nch-i+1), plot(s), axis([1 MaPitSa mi ma])
   %subplot(nch,1,nch-i+1), plot(s), 
end


