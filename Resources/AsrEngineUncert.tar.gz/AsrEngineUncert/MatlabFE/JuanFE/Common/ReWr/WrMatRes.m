function WrMatRes(MatResF,a)
%Write MatRes


f=fopen(MatResF,'w');
fprintf(f,'%d ',a);
fprintf(f,'\n');
fclose(f);
fprintf('Written MatRes %s\n',MatResF);