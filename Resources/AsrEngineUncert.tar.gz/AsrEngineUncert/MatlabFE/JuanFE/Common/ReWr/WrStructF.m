function WrStructF(P,fn)
%Write Structure in a File
%fn: txt file



fi=fopen(fn,'w');

if (fi==-1)
  fprintf('WARNING in WrStr: file creation of %s is not possible\n',fn);
else

  FN=fieldnames(P);
  l=length(FN); 
  for i=1:l     
      
      v=P.(FN{i});           
      if(isnumeric(v)); v=num2str(v); end 
      if(isstruct(v)); v='struct'; end
      if(iscell(v)); v='cell'; end           
          
      ne=length(v); if (ne>100); ne=100; end    
      
     
      fprintf(fi,'%s = %s\n',FN{i}, v(1:ne));
  end
  fclose(fi);
  fprintf('Written %s\n',fn);

end