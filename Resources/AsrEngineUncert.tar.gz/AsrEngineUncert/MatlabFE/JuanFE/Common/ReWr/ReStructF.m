function S=ReStructF(fn)
%Read Structure txt File

fi=fopen(fn,'r');
S=textscan(fi,'%s = %s\n');
fclose(fi);

FN=S{1};
Val=S{2};

for i=1:length(FN)
    S.(FN{i})=Val{i};
end
