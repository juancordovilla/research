function WrMatF(f,M)
%


save(f,'M');
fprintf('Written: %s',f);