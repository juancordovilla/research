function [M,ThMa]=BatchMagOrdThr(A,BS)
%
%A: (En=sqrt(mean(My.^2));)
%BS: Batch Size (usually the max lenght of the pattern to find) (the search is around 3*BS) 






[FL, nf]=size(A);
k=1;
for t=1:BS:nf-BS+1     
    i1=t; e1=t+BS-1;      
    i2=max(1,i1-BS); e2=min(e1+BS,nf);  int2=i2:e2;    
    [x,Th(k)]=MagOrdThr(A(:,int2));       
    k=k+1;    
end
ThMa=max(Th);
M=A>ThMa;

