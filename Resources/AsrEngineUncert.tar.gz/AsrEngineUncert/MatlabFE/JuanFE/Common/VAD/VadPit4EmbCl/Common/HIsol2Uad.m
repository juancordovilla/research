function Iad=HIsol2Uad(Isol,P)
%Home Isol To Uad (for all rooms). Need Isol(i).Room

NRoom=1;
Iad=zeros(NRoom,P.TempP.nf);




for i=1:NRoom
  Iad(i,:)=IsolS2Uad(Isol,P.FS,P.TempP.nf,P.ARoomN{i});
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Iad=IsolS2Uad(Isol,FS,nf,RoomN)
%Isol Structure To Utterance Activity Detection of a Room
l=length(Isol);

Iad=zeros(1,nf);
for i=1:l        
    
    
    if (Isol(i).Room==RoomN)    
        
        
        st=Isol(i).st;  en=Isol(i).en;      
        
        
        %%%%%%%%%%%%%%
%         y=Isol(i).y(:,1);
%         Isol(i).WTrans
%         soundsc(y,16000);         
%         pause
        %%%%%%%%%%%%%%%%%
        
        
        st=max(1,round(st/FS)); en=min(nf,round(en/FS));   
        Iad(st:en)=1;          
    end   
end

