function Isol=Info2OrTSLoc(y, x, Info)
%Info To Oracle Temp-Spatio Localizater



%To Dilate
a=0;
if (a~=0); fprintf('WARNING: Oracle st and en increased %d samples\n',a); end




%
l=length(Info);
for i=1:l
    
    st=str2double(Info(i).st);
    en=str2double(Info(i).en);
    
 
    st=max(1,st-a); en=min(length(y(:,1)),en+a);
    
    
    Isol(i).st=st; Isol(i).en=en;    
    Isol(i).y=y(Isol(i).st:Isol(i).en,:);    
    Isol(i).x=x(Isol(i).st:Isol(i).en,:); 
    Isol(i).bn=Info(i).bn;     
    Isol(i).XPos=Info(i).pos;  
    Isol(i).XRoom=Isol(i).XPos(1);
    Isol(i).Room=Isol(i).XPos(1);
    Isol(i).WTrans=Info(i).WTrans;
    
    %Isol(i).Pos=Isol(i).XPos;
    %Isol(i).Room=Isol(i).XRoom;
    
end

