function [vad]=ReSidEmbVad(dy,bn,k)
%

%
v=ReadHTKF([dy '/' bn '.ClPr'],0,0); xvad=v(1,:);

%
fprintf('SidVad: %d\n',k);

switch k       

    case {0,-1}
        vad=xvad;                
    case 1
        Ext=['_SidVAD.mat']; a='V2';  
    case 2
        Ext=['_ZhangVAD.mat']; a='V4';       
        %%%%%%%%%%%%%%%%%%%%
    case 3
        Ext=['_UnSupVAD']; a='XVad';        
    case 4
        Ext=['_DSVAD.mat']; a='V2';             
    case 5
        Ext=['_Sohn.mat']; a='XVadNoLoc';
end

%
if k~=0 && k~=-1
    fn=[dy '/' bn Ext];
    S=load(fn); 
    vad=S.(a);    
end


% subplot(211), jplot(xvad)
% subplot(212), jplot(vad)
% pause


