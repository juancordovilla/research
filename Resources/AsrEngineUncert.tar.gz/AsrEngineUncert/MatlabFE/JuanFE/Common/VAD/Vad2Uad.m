 function [Uad,Vad]=Vad2Uad(Vado,PhL)
 %
 Vad=ModeF(Vado,PhL);
 Uad=DilateF(Vad,2*PhL);
 