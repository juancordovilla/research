function [H]=JuanHarmonicity(NAy,P)
%

[lak]=LastK(NAy);

%
H=NAyMaxInt(NAy,P,lak);

% %More precise
% Hy=NAyMaxInt(NAy,P,lak);
% He=NAyMaxInt(NAye,P,lak);
% mu=r0ye./r0y;
% H=He; i=mu<0.3; H(i)=Hy(i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [plak]=LastK(NAy,NAye,Thr)
%NAy and NAye: of white noise
[NCh,FL,nf]=size(NAy);
x=1:NCh;
% SAy=zeros(NCh,FL);
% SAye=zeros(NCh,FL);
% lak=zeros(1,NCh);
%  for c=1:NCh
%     SAy(c,:)=squeeze(mean(squeeze(NAy(c,:,:)),2));
%     SAye(c,:)=squeeze(mean(squeeze(NAye(c,:,:)),2));   
%     laky=find(SAy(c,:)>Thr,1,'last'); 
%     lakye=find(SAye(c,:)>Thr,1,'last');   
%     lak(c)=max(laky,lakye);
%  end
% p = polyfit(x,lak,2)
%
p = [0.1578  -10.7931  177.5223]; %Future: Maybe change it by interpol (better for other NCh)
plak = round(polyval(p,x));
% plot(lak), hold on, plot(plak,'r'), hold off, pause

function H=NAyMaxInt(NAy,P,lak)
%NAy Maximum of a Interval
[NCh,FL,nf]=size(NAy);
H=zeros(NCh,nf);
int=P.MaPitSa; %P.MiPitSa;
for c=1:NCh
    Rn=squeeze(NAy(c,:,:));     
    kmi=max(lak(c),P.MiPitSa);
    kma=min(round(FL*4/5),kmi+int);
    H(c,:)=max(Rn(kmi:kma,:)); 
end



