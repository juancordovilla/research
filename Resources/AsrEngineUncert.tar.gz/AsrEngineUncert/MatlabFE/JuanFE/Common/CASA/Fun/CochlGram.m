function [CG,CGe]=CochlGram(y,FSampHz,GamCFHz)
%Cochleagram and corresponding Hilbert Envelope
NCH=length(GamCFHz);
ns=length(y); 
CG=zeros(NCH,ns); CGe=zeros(NCH,ns); 
for c=1:NCH
    
    %Fast (1, half-wave-rect)
    [CG(c,:), env]=gammatone_c(y,FSampHz,GamCFHz(c),0); CGe(c,:)=env;
    

    
    
    %Slow
    %CG(c,:)=gammatone(y,FSampHz,GamCFHz(c),true);    CGe(c,:)=abs(hilbert(CG(c,:)));  
    
        
   
    %CGe(c,:)=CGe(c,:)-mean(CGe(c,:));   
    
    
    
end


