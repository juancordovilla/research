function [Ao,ToOc,ScPo]=Lin2LogSampAcTrans(A,FSampHz,NTo,MiToHz,MaToHz)
% Linear To Log (in Sample) Autocorrelogram Transformation 
%Parameters
%Remember:A0 27.5, A1 55, A2 110,  A3 220, A4 440, A5 880, A6 1760 Hz
%MiToHz=44; % Min Tone
%MaToHz=1000; % Max Tone

%
[nch, nk, nf]=size(A);
Ao=zeros(nch,NTo,nf);

for c=1:nch
    b=squeeze(A(c,:,:));
    [bo,ToOc,ScPo]=Lin2LogSampTrans(b,FSampHz,NTo,MiToHz,MaToHz);    
    Ao(c,:,:)=bo;
    
%     ToOc
%     subplot(211), JImagesc(b)
%     subplot(212), JImagesc(bo)
%     pause
    
    
    
end












