function Y=Cl2ClPr(Cl,tncl)
%Y each column is a sample NCl*NSamples
%Cl=[0 2 0 4 1 ..];
%tncl: total number of classes

nf=length(Cl);
Y=zeros(tncl,nf);

for i=1:nf
    Y(Cl(i)+1,i)=1;    
end

