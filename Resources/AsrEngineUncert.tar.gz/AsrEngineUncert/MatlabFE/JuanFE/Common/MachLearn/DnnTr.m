function DnnTr(modelFile,XTr,YTr,XDev,YDev,SpnBinDir,NG,P,TrCl)
% Dnn Training (use matlab functions, different from DbnTr based on Michi Wohlmayr code) 
%YTr: must be a vector of 0s


fprintf('Tr and Dev: %d and %d samples\n',size(XTr,2),size(XDev,2));


%
SpnMatF=RoMod2JuMatSpnFN(modelFile,TrCl);
[ModDir,bn]=fileparts(SpnMatF);

TmpDir=[ModDir '/Tmp']; [x,x,x]=rmdir(TmpDir,'s'); [x,x,x]=mkdir(TmpDir);

%
YDevM=GetPostM(YDev);
YTrM=GetPostM(YTr);


%
ClS=DbnTr(XTr,YTrM,XDev,YDevM,TmpDir);
save(SpnMatF,'ClS');
fprintf('Written: %s\n',SpnMatF);

% subplot(311), jimagesc(XTr)
% subplot(312), jimagesc(YDevM)
% subplot(313), jimagesc(ClPr)
% pause



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function YM=GetPostM(Y)
%
nf=length(Y);
NOut=max(Y)+1;
YM=zeros(NOut,nf); 
YM(sub2ind([NOut,nf],Y+1,1:nf))=1; %vector value of root layer









