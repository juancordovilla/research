function [PseudoLL]=DbnDir2LogLikUnc(Y,U,MF,SpnMatDir,NPdf,kind,LPrior)
%

%
MatF=[SpnMatDir '/SpnGMod.mat'];
S=load(MatF); ClS=S.ClS;
LPreA=DbnLPreA(Y,ClS);

%
nf=size(Y,2);
LPrior=log((1/NPdf)*ones(NPdf,1)); %we dint use the original data set for training. We used the same number of sample per pdf in the training
PseudoLL=LPreA-repmat(LPrior,[1,nf]); 

% subplot(411), jimagesc(Y)
% subplot(412), jplot(LPrior)
% subplot(413), jimagesc(LPreA)
% subplot(414), jimagesc(PseudoLL)
% pause


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [LPreA]=DbnLPreA(X,ClS)
%Deep belief network Classifier
XT=X';
YT=randn(size(XT,1),ClS.size(end))>0; %fake output for Cls.L which we dont use
ClS=nnff(ClS,XT,YT);
LPost=log(ClS.a{end})'; %last neurons output (posterior because we assume is a softmax)
Cte=0;
LPreA=LPost+Cte; %the constant is not important