function ClS=SvmTr(X,Y,ClDir)
% SVM supports only binary (two-group) classification!
%

%YCl=ClPr2Cl(Y);

% load fisheriris
% xdata = meas(51:end,3:4);
% group = species(51:end);
% 
% xdata
% u=unique(group);
% Y=zeros(length(group),1);
% t=strcmp(group,u{1}); Y(t)=0;
% t=strcmp(group,u{2}); Y(t)=1;



xdata=X';
ncl=size(Y,1);
for i=1:ncl
    group=Y(i,:)';  
    Svm=svmtrain(xdata,group);
    ClS.Svm(i)=Svm;    
end
ClS.ncl=ncl;   


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


