function Gmm2Spn(HmmDir,Gmm)
%
%Gmm=models.Pdfs;
%Variances:     V=1./Inv_vars;
%Means:         M=Means_invvars./Inv_vars;           
%Gconsts:       log((Weights.*exp(-0.5*sum(M.^2./V)))./sqrt(((2*pi)^k)*prod(V)))=
%Gconsts:       log(Weights)-0.5*sum(M.^2./V) - 0.5*k*log(2*pi)-0.5*sum(log(V)); 
%               k is the feature dimension. Gconsts includes information of M and V



MatDir=[HmmDir '/SpnMat']; [x,x,x]=mkdir(MatDir);

FL=size(Gmm{1}.Means_invvars,1);

Me=zeros(FL,1);
Std=ones(FL,1);
Info.modelFile='-1'; 
Info.NS.AvTr=-1;

NPdf=length(Gmm);
for i=1:NPdf    
    
    Spn=Gmm2Spn1(Gmm{i});       
    ModelMat=[MatDir '/Spn' num2str(i-1) '.mat'];        
    save(ModelMat,'Spn','Me','Std','Info');      
    fprintf('Written: %s\n',ModelMat);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







