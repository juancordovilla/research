function   [Los,BSpn]=SavSpnEpBest(EpDir,BN2,Spn,Info,BSpnI,LosI,e)
%Save Spn Epoch and the select Best

Los=LosI;
BSpn=BSpnI;


EpSpn=[EpDir '/'  BN2 '_Ep' num2str(e) '_Tr' num2str(Los.Tr(e),4) '_Dev' num2str(Los.Dev(e),4) '.mat'];       
save(EpSpn,'Spn','Info');  fprintf('Written:%s\n',EpSpn);



if Los.Dev(e)<Los.BDev    
    Los.BTr=Los.Tr(e);
    Los.BDev=Los.Dev(e);
    BSpn=Spn;           
    fprintf('UPDATED the best model\n\n');
else

    fprintf('NO UPDATED the best model\n\n');
end


