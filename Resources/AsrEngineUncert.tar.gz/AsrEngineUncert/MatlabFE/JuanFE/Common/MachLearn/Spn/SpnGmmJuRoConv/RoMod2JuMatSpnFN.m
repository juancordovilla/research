function [SpnMatF,SpnMatDir,BN]=RoMod2JuMatSpnFN(modelFile,MatSufix)
%Robert .mod To Juan .mat Spn File Name
%SpnMatF
[pn,bn,ext]=fileparts(modelFile);
%Info.modelFile=[bn ext];
[pn2, bn2]=fileparts(pn);
bn2(4:6)='Mat';
SpnMatDir=[pn2 '/' bn2]; 
[x,x,x]=mkdir(SpnMatDir); 
BN=['Spn' MatSufix];
SpnMatF=[SpnMatDir '/'  BN '.mat'];