function AppFa2Spn(SpnMatDir,NPdf)
%Append Father all Spns of a SpnMatDir

fprintf('App fathers of %d:\n',NPdf);
for i=1:NPdf       
    fn=[SpnMatDir '/Spn' num2str(i-1) '.mat'];
    S=load(fn);   
    Me  =S.Me;
    Std =S.Std;
    Info=S.Info;
    Spn =S.Spn;    
    
    [Spn.FaIdx, Spn.FaLW]=Spn2FaIdxLW(Spn); 
    
    S.Spn=Spn;        
    save(fn,'Me','Std','Info','Spn');
    fprintf('App father to: %s\n',fn);    
end