function L2MIdx=Li2MaIdxSpn(Idx,TNNod)
%Linear To Matrix Indexation of Spn (for the opposit, Matrix To Idx, use Idx)
%L2MIdx: Dictionary

%Linear To Matrix Index Dictionary
L2MIdx=zeros(TNNod,2);
NLay=size(Idx,1);
for la=1:NLay
    i=Idx(la,1):Idx(la,2);
    nn=length(i);    
    L2MIdx(i,1)=la*ones(nn,1); %Layer
    L2MIdx(i,2)=1:nn; %Node
end