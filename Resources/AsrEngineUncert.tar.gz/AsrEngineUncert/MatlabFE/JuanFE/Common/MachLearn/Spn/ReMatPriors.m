function [LPrior,frameCounts]=ReMatPriors(TrGParMat)
%Similar to ReKaldPriors but for matlab


S=load(TrGParMat);
ModBN=S.I.ModBN;
ModFrC=S.I.ModFrC;
NPdfs=length(ModFrC);
frameCounts=zeros(1,NPdfs);
for i=0:NPdfs-1
    j=strcmp(['Tr' num2str(i)],ModBN);     
    frameCounts(i+1)=ModFrC(j);
end
LPrior=log(frameCounts./sum(frameCounts))';