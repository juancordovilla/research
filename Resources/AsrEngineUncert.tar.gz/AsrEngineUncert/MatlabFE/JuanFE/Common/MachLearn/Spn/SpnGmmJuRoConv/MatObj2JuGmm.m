function [W,Me,Si]=MatObj2JuGmm(Gmm)
%Gmm is the Matlab Structure (Object)
%Gmm.Sigma: Variance (not standard deviation)

W=Gmm.PComponents;
Me=Gmm.mu';
%Sigma is variance not standard-deviation. Include shiftdim in case best ng=1
Si=sqrt(squeeze(shiftdim(Gmm.Sigma))); 



