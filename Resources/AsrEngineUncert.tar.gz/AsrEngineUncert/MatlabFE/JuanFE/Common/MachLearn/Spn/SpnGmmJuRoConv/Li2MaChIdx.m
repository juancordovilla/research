function [Ch,L2MIdx]=Li2MaChIdx(TNNod,Idx,ChIdx)
%Linear To Matrix Children Indexation 
%Ch: In Juan format of columns (Robert prefers rows)
%L2MIdx: Dictionary Linear to Matrix Indexation




%
L2MIdx=Li2MaIdxSpn(Idx,TNNod);



NLay=size(Idx,1);
%Linear To Matrix indexation of Children
Ch=cell(NLay,1); %probably for Scope
%Ch=cell(1,NLay);
for la=1:NLay
    ChLa=ChIdx{la}; %Child of Layer
    nn=length(ChLa);
    for n=1:nn
        L=L2MIdx(ChLa{n},1); %Layer
        N=L2MIdx(ChLa{n},2); %Node       
        Ch{la}{n}=[L N]; %probably for Scope         
        %Ch{la}{n}=[L N]';         
    end    
end
