function GmmObj=Ju2MatGmmObj(W,Me,Si)
%Gmm is the Matlab structure (Object)
%Si: is standard deviation (not variance)


PComponents=W;
mu=Me';
[k,d]=size(mu);

Sigma=zeros(1,d,k);
for i=1:k    
    Sigma(1,1:d,i)=(Si(:,i)').^2;
end

GmmObj=gmdistribution(mu,Sigma,PComponents);


% W=Gmm.PComponents;
% Me=Gmm.mu';
% %Sigma is variance not standard-deviation. Include shiftdim in case best ng=1
% Si=sqrt(squeeze(shiftdim(Gmm.Sigma)));

