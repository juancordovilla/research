function [BTrX,BTrY,BDevX,BDevY]=TrDevBatchI(TrX,TrY,DevX,DevY,TrBL,DevBL,i)
%Give Train and Development Batch number I.
%if i=-1 output BTrX is the maximun number of batches (tr and dev) (floor
%number for safe)

TrNB=floor(size(TrX,2)/TrBL);
DevNB=floor(size(DevX,2)/DevBL);
if i==-1
    BTrX=min(TrNB,DevNB);
    BTrY=[]; BDevX=[]; BDevY=[];
else
    tri=TrBL*(i-1)+1:TrBL*i;
    BTrX=TrX(:,tri);
    BTrY=TrY(tri);
    devi=DevBL*(i-1)+1:DevBL*i;
    BDevX=DevX(:,devi);
    BDevY=DevY(devi);
end

