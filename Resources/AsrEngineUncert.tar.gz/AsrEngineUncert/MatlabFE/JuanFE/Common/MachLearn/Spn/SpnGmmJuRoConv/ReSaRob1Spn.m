function [Spn,Info] = ReSaRob1Spn(SpnInfoMat,savef)
%savef: 0 (only load) 1 (Ro2Ju read and save) 2 (Ro2Ju read)
%FUTURE: Change or delete


I=load(SpnInfoMat);
[SpnModDir]=fileparts(SpnInfoMat); 


ModelMod=[SpnModDir '/' I.ModS.modelFile];
[pn, bn,ext]=fileparts(ModelMod); Ext=ext(2:end); Ext(1)=upper(Ext(1));
ModelMat=[pn '/Mat' bn  Ext '.mat'];

if nargin<2; savef=0; end
if ~exist(ModelMat,'file')&& savef~=2; savef=1; end     



switch savef
    case 0
        %fprintf('WARNING: Loading %s\n',ModelMat);
        S=load(ModelMat);    spn=S.spn;
        
    case 1
        fprintf('Robert 2 Juan reading %s\n',ModelMat)
        spn=Ro2JuSpn(ModelMod);
        fprintf('Saving %s\n',ModelMat); save(ModelMat,'spn');
        
    case 2
        fprintf('Robert 2 Juan reading %s\n',ModelMat)
        spn=Ro2JuSpn(ModelMod);
end

Spn=spn; Info=I;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



