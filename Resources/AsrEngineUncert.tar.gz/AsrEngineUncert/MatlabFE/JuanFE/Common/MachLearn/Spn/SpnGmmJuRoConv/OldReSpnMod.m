function [xx]=ReSpnMod(ModF)
%

fi=fopen(ModF,'r');


%[A,count] = fscanf(fi, ['%d' degrees 'C'])

fscanf(fi,'%s\n',1); %SPN_NETWORK
NumLayers=fscanf(fi,'NumLayers: %d\n') %NumLayers
fscanf(fi,'TYPES: '); Types=fscanf(fi,'%d',[1 NumLayers]) %TYPES
fscanf(fi,'\n');
fscanf(fi,'LAYER %d: TYPE %d\n');
NumNodes=fscanf(fi,'NumNodes: %d\n') %NumNodes
fscanf(fi,'\n');
fscanf(fi,'LAYER %d: TYPE %d\n')
NumNodes=fscanf(fi,'NumNodes: %d\n') %NumNodes

% NumNodes: 440
%NumNodes=fscanf(fi,['NumNodes: %d\n']) 



pause




fclose(fi);
pause