function LayK=SpnLayerKind(Spn)
%Spn Layer Kind
%

NLay=size(Spn.Idx,1);
FaLW=Spn.FaLW;
LW=Spn.LW;

%
LayK=char(NLay,1);
for l=NLay:-1:1
    if l==1
        LayK(l)='v'; %variable
    elseif l==2
        LayK(l)='g'; %gaussian        
    elseif ~isempty(FaLW{l}{1})
        LayK(l)='p'; %product   
    elseif ~isempty(LW{l}{1})
        LayK(l)='s'; %sum
    else
        warning('Unknown layer kind')
    end
end
