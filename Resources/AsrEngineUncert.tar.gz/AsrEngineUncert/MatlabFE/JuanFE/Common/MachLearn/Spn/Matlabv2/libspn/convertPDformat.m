function success = convertPDformat(inputmodel, width, height, outputmodel, varargin)

success = 0;
params = {'binPath', 'normalize'};

if mod(length(varargin), 2) ~= 0
    error('varargin must contain even number of entries')
end

for k = 1:length(params)
    eval(sprintf('%s = [];', params{k}));
end

k = 1;
while k < length(varargin)
    foundmatch = 0;
    for p = 1:length(params)
        if strcmpi(params{p}, varargin{k})
            eval(sprintf('%s = varargin{k+1};', params{p}));
            foundmatch = 1;
            k = k + 1;
        end
    end
    if foundmatch == 0
        error('unknown parameter')
    end
    k = k + 1;
end

cmd = sprintf('"%s/convertPDformat" %s %d %d %s', binPath, inputmodel, width, height, outputmodel);
if ~isempty(normalize)
   cmd = [cmd, spintf(' normalize = %d',normalize)];
end

[sysStat, sysRes] = system(cmd, '-echo');

if (sysStat ~= 0)
    disp(sysRes)
    error('failed to convert')
end
