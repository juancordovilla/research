function binpath = getBinPath()

binpath = 'C:\Users\pehrob\Documents\Visual Studio 2013\Projects\libspn\x64\Release\';