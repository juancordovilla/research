function [value,params] = checkParams(params,fieldname,value)

if(isfield(params,fieldname))
    value = getfield(params,fieldname);
else
    params = setfield(params,fieldname,value);
end