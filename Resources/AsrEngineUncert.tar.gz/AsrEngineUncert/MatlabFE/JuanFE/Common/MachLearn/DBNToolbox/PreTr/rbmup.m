function x = rbmup(rbm, x)
%size(x)
%size(rbm.W)
%size(rbm.c)

if(sum(log2(size(x)))<20)
    x = sigm(repmat(rbm.c', size(x, 1), 1) + x * rbm.W');
    
else
    %large scale data
    fprintf('large scale mode of rbmup ...');
    evalin('caller',['clear x']); %TODO: make this more generic
    P = 1000; %process chunks of this size
    y = [];
    while (size(x,1)>0)
        N = min(size(x,1),P);
        yp = sigm(repmat(rbm.c', N, 1) + x(1:N,:) * rbm.W');
        x = x((N+1):end,:);
        y = [y;yp];
        %size(x)
        %size(y)
    end
    
    x = y;
    fprintf('large scale mode done ...');
    %size(x)
end
