function ClS=DaTr(X,YO,ClDir,type)
% Discriminant Analysis (linear or quadratic)
% function fitcdiscr only in Matlab2014!!!!!!!!!!!!!!!
%

[ncl]=size(YO,1);
Y=ClPr2Cl(YO);


Y=Y';
X=X';



[C,err,P,logp,coeff] = classify(X(1,:),X,Y,type);
ClS.X=X;
ClS.Y=Y;
ClS.ncl=ncl;
%ClS.type=type;


%C, Y(i), pause





   