function Nest=MinStatN(Y,FSSec,NoiseK)
%Minimum Statistic Noise (from VoiceVox)
%Y: in Magnitude

switch NoiseK
    case '1' %Rainer Martin
        [Nest]=estnoisem(Y',FSSec); Nest=Nest';
    case '2' %Gerkmann, T. & Hendriks, R. C.
        [Nest]=estnoiseg(Y',FSSec); Nest=Nest';
end
