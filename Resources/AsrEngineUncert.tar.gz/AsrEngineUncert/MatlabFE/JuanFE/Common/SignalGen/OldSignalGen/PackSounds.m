function PackSounds
%Pack Sounds
%To load x Phone (a e i o u) at y dB (yc y20 y15 y10 y5 y0 y_5): >> v=S.x.y; 
%Noise used: car
%USE: Firstly generate all.mat (File with all Phones at diferents SNRs)

addpath('../')
addpath('../../ShefFuns')

% Generate all.mat
f=Phone('f');
g=Phone('g');
s=Phone('s');
z=Phone('z');
ra=Phone('ra');
sa=Phone('sa');
ya=Phone('ya');

save cons f g s z ra sa ya


%
S=load('cons');
v=[S.ra.y0];
v=[S.ra.yc];
%v=[S.e.y0 S.u.y0];
%v=[S.e.yc S.u.yc];
%v=[S.e.y0 S.o.y0 S.a.y0 S.u.y0 S.i.y0];
%v=[S.e.yc S.o.yc S.a.yc S.u.yc S.i.yc];
plot(v)
soundsc(v)

%%%%%
function S=Phone(x)
%
sx=Signals('PhoJuan', x);
sn=Signals('NA2','carr');
[S.y20,yc,n]=Mix(sx,sn,20,0.5);
[S.y15,yc,n]=Mix(sx,sn,15,0.5);
[S.y10,yc,n]=Mix(sx,sn,10,0.5);
[S.y5,yc,n]=Mix(sx,sn,5,0.5);
[S.y0,yc,n]=Mix(sx,sn,0,0.5);
[S.y_5,S.yc,n]=Mix(sx,sn,-5,0.5);
