function [n,rnt]=ARMANoiseRx(N,G,b,a)
%GIVE A VECTOR OF ARMA NOISE depending on Rx

%b=1;
%a=[1 0];       %White-Flat             (the most narrow)
%a=[1 -0.4];    %Low Pass slowly        (little-broad, no vibration)
%a=[1 -0.85];   %Low Pass quickly       (broad, no vibration)
%a=[1 0.4];     %High Pass slowly       (little-broad, vibration)
%a=[1 0.85];    %High Pass quickly      (broad, vibration) 
    


        nw = G*randn(1,50000+N-1); 
        n = filter(b,a,nw);
        n = n(50000:end);


%TEOR AR(1)
rn=xcorr(n,n, 'biased'); rn=rn((length(rn)+1)/2:end);
k=0:N-1; rnt=(G.^2*(-a(2)).^abs(k))/(1-a(2).^2);
subplot(211), plot(k,rnt), hold on, plot(k,rn(k+1),'g'), hold off
NFT=512; M=abs(G*fft(b,NFT)./fft(a,NFT)); M=M(1:NFT/2);
subplot(212), plot(M)
pause

