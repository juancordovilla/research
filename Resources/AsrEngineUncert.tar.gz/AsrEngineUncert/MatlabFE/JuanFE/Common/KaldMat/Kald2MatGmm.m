function [W,Me,Si]=Kald2MatGmm(Gmm)
%See ReKaldGmm.m 
%%Variances:     V=1./Inv_vars;
%Means:         M=Means_invvars./Inv_vars;    
%Weights:       sum(Weights)=1;
%Si: is not the Variance is the Standard Deviation

Si=sqrt(1./Gmm.Inv_vars); 
Me=Gmm.Means_invvars./Gmm.Inv_vars;  
W=Gmm.Weights;  


