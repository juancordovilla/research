function [PhN]=PdfN2PhN(PdfN,models)
%Phone Number To Pdf Number
%PdfN: is a vector (from 1.....NPdfN (as in models))
%PhN: is a cell (same length as PdfN) (each element is a vector) (from
%1...351 as in silence.csl)

TPh=models.TransitionModel.Triples(:,1); %Ph
%TSt=models.TransitionModel.Triples(:,2); %States
TPdf=models.TransitionModel.Triples(:,3); %Pdf

l=length(PdfN);
PhN=cell(l,1);
for i=1:l
    j=PdfN(i)==TPdf;
    PhN{i}=unique(TPh(j))';
end
