function Gmm=Mat2KaldGmm(W,Me,Si)
%Matlab To Kald Gmm (do not confuse Gmm with Pdf structure, ensemble of Gmms)
%Si: is not the Variance is the Standard Deviation
Gmm.Weights=W; 
Gmm.Inv_vars=1./(Si.^2); 
Gmm.Means_invvars=Me.*Gmm.Inv_vars;
