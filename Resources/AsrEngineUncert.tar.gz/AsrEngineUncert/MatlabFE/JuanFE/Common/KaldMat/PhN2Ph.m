function PhC=PhN2Ph(PhNC,PhPhNDicF)
%Phone Number To Ph (string)
%PhNC: each cell element must be a row vector
%PhNC: 1...NumberOfPh

[D.Ph,D.PhN]=ReDictF(PhPhNDicF); D.PhN=strtrim(D.PhN);
[v,in,en]=Cell2M(PhNC);
s=num2str(v);
C = strsplit(s,' ');
Ph=Key2ValDict(C',D.PhN,D.Ph,1);
PhC=M2Cell(Ph',in,en);

