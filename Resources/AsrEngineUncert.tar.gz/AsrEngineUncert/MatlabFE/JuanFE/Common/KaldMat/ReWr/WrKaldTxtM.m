function WrKaldTxtM(loglikes_rspecifier,BN,StPr)
%Write Kald Txt Matrix, with BaseName at the beggining
%IMPORTANT: size(StPr)= NumFram*FramLength (oposite to Matlab)



% if size(StPr,2)~=2006 %To delete in future
%     fprintf('WARNING AND PAUSED: you have to correct StPr because it doesnt have 2006 states\n')
%     pause
% end



[nr, nc]=size(StPr);
fi=fopen(loglikes_rspecifier,'w');
fprintf(fi,'%s  [\n  ',BN);
for i=1:nr-1
    fprintf(fi,'%f ',StPr(i,:));
    fprintf(fi,'\n');
end
fprintf(fi,'%f ',StPr(nr,:));
fprintf(fi,']');
fclose(fi);
fprintf('Written %s\n',loglikes_rspecifier);
