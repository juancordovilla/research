function [BN,LL]=ReKaldTxtM(loglikes_rspecifier)
%Read Kaldi Txt Matrix, with Base Name at the begginig
%IMPORTANT: size(LL)= NumFram*FramLength (oposite to Matlab)


%Read
fi=fopen(loglikes_rspecifier,'r');
C = textscan(fi,'%s','delimiter','\n'); C=C{:};
fclose(fi);
%BaseName
a=strsplit(C{1}); BN=a{1};
%Remove from C
C(1)=[];
C{end}(end)=[];
%nr, nf
nr=length(C); 
a=sscanf(C{1},'%f'); nc=length(a);
%Read C
LL=zeros(nr,nc);
for i=1:nr
    LL(i,:)=sscanf(C{i},'%f');    
end
fprintf('Read %s\n',loglikes_rspecifier);
