function [BN,FrLa]=ReKaldAlign(TxtF,k)
%Read Kaldi Alignement


[Key,Val]=ReDictF(TxtF); %Pdfs are in model.pdf{1},... model.pdf{47}


l=length(Key);

BN=cell(l,1);
FrLa=cell(l,1);
for i=1:l
    
 
    
    switch k    
        case {'pdf', 'ph'}    
            
            a=sscanf(Val{i},'%f ')'; 
   
            
            
            
%             C=strsplit(Val{i});        
%             a=C(1:end-1);   
%             a=str2double(a);
            
        case 'post'
            a=sscanf(Val{i},'[ %d %d ] ');  a=a(1:2:end)'; 
    end

    BN{i}=Key{i};
    FrLa{i}=a;


end