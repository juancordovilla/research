function [CG,CGA]=AcTG(y,P)
%AutoCorr ToneGram

[My, nf]=Segmx(y,P.FL,P.FS);
[x, x, x, Rosau] =M2AC(My);
CG=Rosau(1:P.MaPitSa+1,:); 

CG(CG<0)=0; %negatives to 0 

s=sign(CG); CG=s.*sqrt(abs(CG)); %CG from power to magnitude


%CG=TGTransf(CG,'norm',-1);

CGA=CG; %CG All
CG(1:P.MiPitSa,:)=0; %CG Rejecting low low values


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 