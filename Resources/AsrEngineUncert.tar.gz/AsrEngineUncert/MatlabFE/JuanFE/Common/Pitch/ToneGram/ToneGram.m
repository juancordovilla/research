function [TGc,Fb]=ToneGram(y,CG,CGe,P,k)
%


switch k
    
    case 'Ac'
        [TG,Fb]=AcTG(y,P);
        
    case 'MAc'
        
        [TG,Fb]=MaskAcTG(CG,CGe,P);
        
    case 'PiFb' 
        [TG,Fb]=PiFbTG(CG,CGe,y,P);
        
end

%TGc=TG(P.Li2LoST+1,:); %Linear To Log2 (auditory)
TGc=TG;




