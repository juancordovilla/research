function labm=LabArPM(S,pym,fmai)
%Labs around Mean Pit 
pyma=pym*fmai; pymi=pym/fmai;
i=S.pyma>pymi & S.pymi<pyma;
labm=S.lab(i);
