function [pos,x,l]=RegPit(TGs,xmi,xma,nf)
%Region Line. Return q in its correct position (to xmi)
%pos: position (1:end) and not pitch of the maximum


i=max(1,xmi-1);
f=min(xma+1,nf);

TG=-1*TGs(:,i:f)+1;
%C = [1 1 1.0; -1 1 1.0; 0 1 1.0; -2 1 1.0; 2 1 1.0; -3 1 1.0; 3 1 1.0]; 
C = [1 1 1.0; -1 1 1.0; 0 1 1.0; -2 1 1.0; 2 1 1.0]; 
%C = [1 1 1.0; -1 1 1.0; 0 1 1.0;]; 

[p,q]=dpfast_cons(TG,C); p=p(2:end-1); q=q(2:end-1)+xmi-2; 
%[x p]=min(TG); p=p(2:end-1); q=xmi:xma;
l=length(q);
x=zeros(1,nf); x(1:l)=q(1:l); 
pos=zeros(1,nf); pos(1:l)=p(1:l); 

