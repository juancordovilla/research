function [Ml]=DTWLinFeat(TG,BWr)
%DTW Lines and their Feat
BWr(:,1)=0; BWr(:,end)=0; 

[Lab,nr]=bwlabel(BWr); %Labs and number of regions


[FL, nf]=size(BWr);
Ml=IniDtwS(nr,nf);
for i=1:nr
    [r,c]=find(Lab==i);      
    ind=sub2ind([FL nf],r,c);       
    TGs=zeros(FL,nf); TGs(ind)=TG(ind); xmi=min(c); xma=max(c); 
    
    [pos,x,l]=RegPit(TGs,xmi,xma,nf);   py=pos-1;
       
    Ml=FillDtwS(i,Ml,x,py,l,0,0,FL,nf,TG);    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


