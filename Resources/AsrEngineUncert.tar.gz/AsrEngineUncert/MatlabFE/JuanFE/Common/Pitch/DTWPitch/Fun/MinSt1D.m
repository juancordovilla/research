function Eb=MinSt1D(Etg,hs,hmi)
%Minimun Statistic (1D for the moment)
Etgs=Smooth1D(Etg,hs); Eb=MinF(Etgs,hmi); 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function xs=Smooth1D(x,hl)
%hl: half window length
ns=length(x);
xs=x;
for i=1+hl:ns-hl; xs(i)=mean(x(i-hl:i+hl)); end