function S=FillDtwS(k,S,x,py,l,E,EI,FL,nf,TG)
%Fill Line Structure
i=py>FL-1; py(i)=FL-1;
S.x(k,:)=x; S.py(k,:)=py; 
S.xmi(k)=min(x(1:l)); S.xma(k)=max(x(1:l)); S.pymi(k)=min(py(1:l)); S.pyma(k)=max(py(1:l)); 

if E==0; ind=sub2ind([FL nf],round(py(1:l)+1),x(1:l)); a=TG(ind); S.E(k)=mean(a); S.EI(k,1:l)=a;
else S.E(k)=E; S.EI(k,:)=EI; end
S.lab(k)=k; S.l(k)=l; 