function [pym,Smal]=MeanSpeakerPit(TG,Sdtw,PitP)
%Mean Speaker Pitch
[lmadtw]=MaxLinSel(Sdtw.lab,Sdtw,PitP.shl,'E',TG);
[oct]=OctEst(Sdtw,lmadtw,PitP.tho,PitP.feq,PitP.oma,TG);
[Smal]=MaxLineTG(Sdtw,lmadtw,oct,PitP.oma,TG);
[pym]=MeanPitch(Smal,PitP.shl,TG,PitP.pl);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%