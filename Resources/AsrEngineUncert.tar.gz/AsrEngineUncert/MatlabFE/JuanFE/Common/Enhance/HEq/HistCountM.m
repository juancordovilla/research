function Count=HistCountM(X,E)
%Histogram Count of a Matrix (chanel by chanel)
[nch,NE]=size(E); NB=NE-1;
Count=zeros(nch,NB);
if ~ isempty(X)
    for ch=1:nch
        [Count(ch,:)]=HistCount(X(ch,:),E(ch,:));
        %    subplot(211), plot(X(c,:))
        %    subplot(212), plot(E(c,:),n(c,:))
        %    pause
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [count]=HistCount(x,e)
%e: edeges (1+N);
NB=length(e)-1;
count=zeros(1,NB);
for i=1:NB
    j=x>e(i) & x<e(i+1);
    count(i)=sum(j);   
end