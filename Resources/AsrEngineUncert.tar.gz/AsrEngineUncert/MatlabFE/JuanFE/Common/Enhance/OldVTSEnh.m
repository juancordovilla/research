function [Fbxest,pxest]=OldVTSEnh(y,ys,MicLa,RefMic,P,x,xs)
%

%
[S.My S.nf]=Segmx(y,P.FL,P.FS);
[S.Y, S.CY]=Msd(S.My,'x',P.N2pi,P);
S.Fby=SmoothFreqCompr(S.Y,P.NCH,P.FSamp,P.N2pi,P.MF);
S.pit=-1; S.vad=-1; S.GSNR=-1; S.N=-1; S.Fbn=-1; 
S.Fbnest=VadPitN(S.My,S.Y,S.Fby,S.pit,S.vad,S.GSNR,P,S.N,S.Fbn);




%
fprintf('Imputation with : %s\n',P.ImputeGmmDir);
load([P.ImputeGmmDir '/Gmm.mat']); 
P.GMM=mix;
M=[S.Fby(:,1:P.FLFr) S.Fby(:,end-P.FLFr:end)]; v=var(M,0,2); CovFbnest=repmat(v,[1, S.nf]);	   
Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,CovFbnest,P.MF,'VtsCov');	


subplot(211), imagesc(S.Fby)
subplot(212), imagesc(Fbxest)
pause


% %xest
% Xest=MelMsd2Msd(exp(Fbxest),P.FSamp,P.N2pi,'1');
% Xest2=[Xest(1:end,:);  Xest(end-1:-1:2,:)];
% CXest=Xest2.*exp(1i*angle(S.CY));
% xest=ACMsd2Sig(CXest,P.FL,P.FS,P.win,y);
% 
% 
% %Pitch
% [Mxest nf]=Segmx(xest,P.FL,P.FS);
% pxest=AcPitch(Mxest,P); 

pxest=-1;

% %

% subplot(613), imagesc(Fbxest)
% subplot(614), plot(y)
% subplot(615), plot(xest)
% subplot(616), plot(pxest)
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function OldVtsEnh2()
% DONT DELETE UNTIL BE SURE THAT I UNDERNSTAND ALL VTS TYPES
%
% if (P.ImputK~=0) %if 0, don't estimate noise
%     S.Fbnest=VadPitN(S.My,S.Y,S.Fby,S.pit,S.vad,S.GSNR,P,S.N,S.Fbn);
% end
% 
% if ((~isempty(strfind(do,'Train')))||(P.ImputK==0)) %Fbxest=Fby
%     S.Fbxest=S.Fby;
%     
% elseif (P.ImputK==1)    %Vts without covariance
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,S.mask,P.MF,'Vts');
%     
% elseif (P.ImputK==2) %Vts with covariance averaged from first-last frames   
%     fprintf('GmmDir: %s\n',P.GmmDir);
% 
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;    
%     M=[S.Fby(:,1:P.FLFr) S.Fby(:,end-P.FLFr:end)]; v=var(M,0,2); CovFbnest=repmat(v,[1, S.nf]);	   
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,CovFbnest,P.MF,'VtsCov');	
% 	
% elseif (P.ImputK==3) %Vts with covariance hafl from first, half from last frames 
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;
%     S.mask=YNHardMask(exp(S.Fby),exp(S.Fbnest),P.Thr,exp(P.MF));    
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,S.mask,P.MF,'BinI');
%     
% else
%     fprintf('ERROR: Unknown Imput\n');
% end















