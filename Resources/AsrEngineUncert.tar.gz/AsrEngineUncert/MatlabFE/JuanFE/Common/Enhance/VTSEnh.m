function  Fbxest=VTSEnh(Fby,Fbnest,k,P)
%


[NCH,nf]=size(Fby);




% Load Model
fprintf('Imputation %s with model: %s\n',k,P.ImputeGmmDir);
load([P.ImputeGmmDir '/Gmm.mat']); P.GMM=mix;



%

switch k
    
     case 'Vts'
        Fbxest=Impute(P.GMM,Fby,Fbnest,-1,P.MF,'Vts');
    
    
    case 'VtsCov'        
        %FLFr=20; M=[Fby(:,1:FLFr) Fby(:,end-FLFr:end)]; v=var(M,0,2); CovFbnest=repmat(v,[1, nf]);
        v=var(Fbnest,0,2); CovFbnest=repmat(v,[1, nf]);        
        Fbxest=Impute(P.GMM,Fby,Fbnest,CovFbnest,P.MF,'VtsCov');	
        
    case 'VtsCov0'
        CovFbnest=zeros(NCH,nf); 
        Fbxest=Impute(P.GMM,Fby,Fbnest,CovFbnest,P.MF,'VtsCov');
end        
        
     
%IMPORTANT: Check output
i=isnan(Fbxest)|isinf(Fbxest);
if sum(i(:))>0
    Fbxest(i)=P.MF;
    fprintf('WANING in TmpVTSEnh: Some NaN or Inf replaced by P.MF\n');
end

% subplot(411), jimagesc(Fby)
% subplot(412), jimagesc(Fbx)
% subplot(413), jimagesc(Fbn)
% subplot(414), jimagesc(Fbxest)
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function OldVtsEnh2()
% DONT DELETE UNTIL BE SURE THAT I UNDERNSTAND ALL VTS TYPES
%
% if (P.ImputK~=0) %if 0, don't estimate noise
%     S.Fbnest=VadPitN(S.My,S.Y,S.Fby,S.pit,S.vad,S.GSNR,P,S.N,S.Fbn);
% end
% 
% if ((~isempty(strfind(do,'Train')))||(P.ImputK==0)) %Fbxest=Fby
%     S.Fbxest=S.Fby;
%     
% elseif (P.ImputK==1)    %Vts without covariance
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,S.mask,P.MF,'Vts');
%     
% elseif (P.ImputK==2) %Vts with covariance averaged from first-last frames   
%     fprintf('GmmDir: %s\n',P.GmmDir);
% 
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;    
%     M=[S.Fby(:,1:P.FLFr) S.Fby(:,end-P.FLFr:end)]; v=var(M,0,2); CovFbnest=repmat(v,[1, S.nf]);	   
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,CovFbnest,P.MF,'VtsCov');	
% 	
% elseif (P.ImputK==3) %Vts with covariance hafl from first, half from last frames 
%     load([P.GmmDir '/Gmm.mat']); P.GMM=mix;
%     S.mask=YNHardMask(exp(S.Fby),exp(S.Fbnest),P.Thr,exp(P.MF));    
%     S.Fbxest=Impute(P.GMM,S.Fby,S.Fbnest,S.mask,P.MF,'BinI');
%     
% else
%     fprintf('ERROR: Unknown Imput\n');
% end



