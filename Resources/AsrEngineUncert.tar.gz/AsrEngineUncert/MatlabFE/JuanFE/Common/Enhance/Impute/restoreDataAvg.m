function out= restoreDataAvg( dataWin, maskWin, winIndexes, frames, params )
out= zeros(params, frames);
for t=1:frames
    i= find( winIndexes==t )';
    i2= (i-1)*params+1;
    i3= repmat(i2, params, 1);
    i4= bsxfun(@plus, i3, (0:params-1)');   
    x_est= dataWin(i4);
    out(:,t)= mean( x_est, 2 ); %The estimates computed by the imputation technique are averaged
end