function MO=OrM(M)
%Or of the Matrix rows
[RoomN,nf]=size(M);
MO=M;
for i=1:RoomN
  a=M(i,:); a=repmat(a,[RoomN,1]);
  MO=MO|a;  
end

