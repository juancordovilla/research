function v=StArFNExtract(S,FN)
%FN: 'st'
%Structure Array Field Name Extraction





N=length(S);

v=[];

if N>0

if isfield(S, FN) && ~isempty(S(1).(FN))

    c=class(S(1).(FN));
    if length(S(1).(FN))>1; c='char'; end
    switch c
        case 'double'
            v=zeros(1,N); for i=1:N;  v(i)=S(i).(FN); end
        case 'char'
            v=cell(1,N); for i=1:N;   v{i}=S(i).(FN); end
    end

end

end


