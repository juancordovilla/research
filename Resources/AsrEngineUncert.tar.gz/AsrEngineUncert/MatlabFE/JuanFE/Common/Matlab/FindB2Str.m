function fs=FindB2Str(s,a,b)
%Find Between Two Strings
%fs: found string in s Between String a and string  b (show the first ocurrence)
% 

la=length(a);
lb=length(b);
k=strfind(s,a); k=k(1);
s2=s(k+la:end);
k=strfind(s2,b); k=k(1);
fs=s2(1:k-lb); %found string

