function t=StrcmpTokCell(C,Tok)
%String comparison of Tok in a Cell
l=length(C);
t=false(1,l);
for i=1:l;  
    t(i)=~isempty(strfind(C{i},Tok)); 
end
