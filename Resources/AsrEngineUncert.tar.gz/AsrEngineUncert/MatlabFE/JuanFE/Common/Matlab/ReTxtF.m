function O=ReTxtF(TxtF,k)
%

switch k
    case 'Lin'
        O=ReLinTxtF(TxtF);
    case 'Word'
        L=ReLinTxtF(TxtF);
        O=Lin2Word(L);
        
        
    case ''
        
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function W=Lin2Word(L)
%Line To Word
l=length(L);
W=cell(l,1);
for i=1:l    
    b=strsplit(L{i});
    t=strcmp(b, ''); b=b(~t);     %remove ''
    W{i}=b;
end



function Li=ReLinTxtF(TxtF)
%Read Lines from Txt File
%C: cell of the lines
fi=fopen(TxtF);
l = fgets(fi); i=1;
while ischar(l)    
    Li{i}=l;
    l=fgets(fi); i=i+1;
end
fclose(fi);
