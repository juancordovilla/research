function C=M2Cell(M,in,en)
%Matrix 2 Cell
%in/en referes to M columns to split M columns (see Cell2M) 
l=length(in);
C=cell(l,1);
for i=1:l
    C{i}=M(:,in(i):en(i));
end
