function [Key,Val]=ReDictF(Dict)
%Read Dictionary File (Key and Val)
%

%
[pn,bn]=fileparts(Dict);
TmpF=[pn '/TmpDic' bn '.txt'];


if ~exist(Dict,'file')
    fprintf('ERROR in ReDictF: Doesnt exist Dict %s\n',Dict);
else
    
     
    %Keys
    c=['awk ''{ print $1}'' ' Dict];    system([c ' > ' TmpF]);
    fi=fopen(TmpF,'r');    A=textscan(fi, '%s');   Key=A{:};   fclose(fi);
    
    

    %Val
    %Print 2 to end column
    c=['awk ''{for(i=2;i<=NF;i++) {printf "%s ", $i}; printf "\n"}'' ' Dict]; system([c ' > ' TmpF]);           
    fi=fopen(TmpF,'r');    A=textscan(fi, '%s', 'delimiter', '\n');  Val=A{:}; fclose(fi);
    
%     fi=fopen(TmpF,'r');
%     nr=length(Key);
%     Val=cell(nr,1);
%     for i=1:nr
%         l = fgetl(fi);        
%         Val{i}=l;         
%     end
%     fclose(fi);

end

delete(TmpF);

