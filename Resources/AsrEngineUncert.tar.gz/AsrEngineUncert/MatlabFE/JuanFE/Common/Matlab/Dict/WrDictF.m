function WrDictF(DictF,Key,Val)
%Write Dictionary File

fi=fopen(DictF,'w');
l=length(Key);
for i=1:l
    fprintf(fi,'%s %s\n',Key{i},Val{i});    
end
fclose(fi);
fprintf('Written %s\n',DictF);
