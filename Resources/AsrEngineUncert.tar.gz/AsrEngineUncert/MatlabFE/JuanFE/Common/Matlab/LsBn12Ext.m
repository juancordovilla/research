function [CList,BNNum]=LsBn12Ext(Dir,bn1,bn2,ext)
%List Directory (Ls) given BaseName1 BaseName2 and Extention
%Basename can be meta-caracters such as '*'


fy=dir([Dir '/' bn1 bn2 ext]); 

l=size(fy,1);
CList=cell(l,1);
for i=1:l
    CList{i}=[Dir '/' fy(i).name];    
end


%Temporal

lbn1=length(bn1);
k=1;
for i=1:l
   [pn,bn]=fileparts(CList{i});
   n=str2num(bn(lbn1+1:end));
   if ~isempty(n)
    BNNum(k)=n;
    k=k+1;
   end   
end
