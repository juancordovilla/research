function Iad=DilateF(Vad,hw)
%Dilate Filter
%Usefull for Voice Activity Detection To Utterance Activity Detection
%Stick hw (half window) 1s
[ai,di]=FindAscDesc1(Vad);
nf=length(Vad);
ai=max(ai-hw,1);
di=min(di+hw,nf);
Iad=zeros(1,nf); 
for i=1:length(ai); Iad(ai(i):di(i))=1; end