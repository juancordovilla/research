function xf=MinF(x,hw)
%Minimum Filter
nf=length(x); xf=x;
for i=1+hw:nf-hw; 
    xf(i)=min(x(i-hw:i+hw));
end
xf(1:hw)=min(x(1:hw)); xf(nf-hw+1:nf)=min(x(nf-hw+1:nf));
