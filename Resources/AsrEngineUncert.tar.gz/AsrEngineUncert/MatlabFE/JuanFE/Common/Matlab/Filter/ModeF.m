function xf=ModeF(x,hw)
%Mode Filter
x=x*1.0; %Convert real to Logical
xf=x; lx=length(x);
for i=1+hw:lx-hw
    xf(i)=mode(x(i-hw:i+hw));
end
xf(1:hw)=mode(x(1:hw));
xf(lx-hw+1:end)=mode(x(lx-hw+1:end));
