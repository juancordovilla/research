function SC=Num2StrCell(NC)
%Number To String a Cell 
%NC: a Cell of matrixes (or Cells) to one Matrix (or one cell) see Cell2M
[v,in,en]=Cell2M(NC);
s=int2str(v);
b=strsplit(s);
SC=M2Cell(b,in,en);

