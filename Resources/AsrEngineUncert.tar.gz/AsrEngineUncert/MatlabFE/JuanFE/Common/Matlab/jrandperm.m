function p=jrandperm(n,k,kind)
%From n take k
switch kind    
    case 'r' %rand
        p=randperm(n,k);        
    case 'f' %first
        p=1:k;        
    case 'rc' %rand control 
        rng(n);
        p=randperm(n,k);        
end
