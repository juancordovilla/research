function NA=NormA(A,k)
%Normalize Array
%There are different kinds: min/max, sum=1, etc..

switch k
    case 'MiMa' %Now: only all matrix. Future: also col/row
        ma=max(A(:)); mi=min(A(:)); NA=(A-mi)/(ma-mi); 
        
        
    case 'Sum' %Now: only col of matrix. Future: also row/all
        NA=NormCol(A);
        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function B=NormCol(A)
%
[FL,nf]=size(A);
s=sum(A); s(s==0)=realmin;
B=A./repmat(s,[FL,1]);