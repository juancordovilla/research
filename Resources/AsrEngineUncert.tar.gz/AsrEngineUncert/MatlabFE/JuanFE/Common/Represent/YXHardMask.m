function m=YXHardMask(Y,X,Th,Fl)
%Y,N: should be in Magnitud Spectrum domain
%Th: (-3db)
%Fl: 0.0608 (exp(-2.80))
Nest=Y-X; i=Nest<Fl; Nest(i)=Fl; 
SNR=20*log10(X./Nest);
m=SNR>Th; 

