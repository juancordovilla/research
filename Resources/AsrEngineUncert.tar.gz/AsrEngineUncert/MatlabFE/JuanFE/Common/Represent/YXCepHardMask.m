function m=YXCepHardMask(Y,X,Th)
%Y,N: should be in Magnitud Spectrum domain
%Th: (-3db)
%Fl: 0.0608 (exp(-2.80))
Nest=abs(Y-X);
SNR=20*log10(X./Nest);
m=SNR>Th; 