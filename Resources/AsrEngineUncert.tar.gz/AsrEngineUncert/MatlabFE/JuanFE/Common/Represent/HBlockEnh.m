function [Fbxest,pxest]=HBlockEnh(ym,ys,nf,P,xm,xs)
%House Block Enhancement. Each block is 1+3+1 seconds
%ym: y mono signal
%ys: y stereo or array signal
%

[ly, MicN]=size(ys);
[ly, MicNM]=size(ym);
%


RoomN=length(P.ARoomN);

Fbxest=zeros(RoomN,P.NCH,nf);
pxest=zeros(RoomN,nf);

BatchN=ceil(nf/P.BatchSFr);
fprintf('Block enhac. with BatchN %d:\n',BatchN);

for i=4:BatchN
%for i=22
    sff=(i-1)*P.BatchSFr+1; eff=i*P.BatchSFr; %start and end filling frames
    %sfs=(sff-1)*P.FS+1; efs=eff*P.FS;
    sf=(sff-P.BatchEFr); ef=(eff+P.BatchEFr)+P.FillFrN; %start and end frames    
    ss=(sf-1)*P.FS+1; es=ef*P.FS; %start and end samples
               
    [ymb,xmb,ysb,xsb]=BatchSign(ym,ys,ly,MicNM,MicN,ss,es,xm,xs);    
    fprintf('%d ',i);
    
    %
    [Fbxestb,pxestb]=HSpEnh(ymb,ysb,P,xmb,xsb,i);

    int2=P.BatchEFr:(P.BatchSFr+P.BatchEFr-1);    
    
    Fbxest(:,:,sff:eff)=Fbxestb(:,:,int2);
    pxest(:,sff:eff)=pxestb(:,int2);

   
    
end


pxest=pxest(:,1:nf);
Fbxest=Fbxest(:,:,1:nf);
fprintf('\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ymb,xmb,ysb,xsb]=BatchSign(ym,ys,ly,MicNM,MicN,ss,es,xm,xs)
%

int=ss:es; li=length(int); nzi=(int>=1)&(int<=ly); 
intb=1:li;    
intb=intb(nzi);     
int=int(nzi); 
ymb=zeros(li,MicNM);
xmb=zeros(li,MicNM); 
ysb=zeros(li,MicN);
xsb=zeros(li,MicN); 

ymb(intb,:)=ym(int,:);
xmb(intb,:)=xm(int,:);
ysb(intb,:)=ys(int,:);
xsb(intb,:)=xs(int,:);


