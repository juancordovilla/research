function m=YNHardMask(Y,N,Th,Fl)
%Y,N: should be in Magnitud Spectrum domain
%Th: (-3db)
%Fl: 0.0608 (exp(-2.80))
Xest=Y-N; i=Xest<Fl; Xest(i)=Fl; 
SNR=20*log10(Xest./N);
m=SNR>Th; 

