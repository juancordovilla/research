function MakeRecDir(SMRoot,SoftRoot,RecRoot,ExtraFunRoot)
%Create RecDir.sh and execute from the OS with system

%
addpath('./Fun')
AddSMPathF='./Fun/AddSMPath.m';
%[SMRoot, SoftRoot, SpeechRoot, ResRoot, RecRoot, ExtraFunRoot]=AddSMPath('0'); 

%McrRoot = '/afs/spsc.tugraz.at/opt/matlab/R2013a'; 
%McrRoot = '/usr/local/MATLAB/R2014b';
McrRoot = matlabroot;

MakeShF='./RecDir.sh';
delete(MakeShF);

%


fi2=fopen(MakeShF,'w');

fprintf(fi2,'%s\n\n',['#!/bin/csh']);
fprintf(fi2,'%s\n',['set path = (' McrRoot '/bin $path)']);
fprintf(fi2,'%s\n',['mcc -R -nojvm -R -nodisplay -R -singleCompThread -v -m Fun/RecDir.m \']);

fi=fopen(AddSMPathF,'r');
l = fgetl(fi);
while ischar(l)
    if ~isempty(strfind(l, 'addpath(')) && isempty(strfind(l, '%'))
        C = regexp(l,'''(.*?)''','tokens'); C1=C{:}; C1=sprintf('%s',C1{:});
        C = regexp(l,'[(.*?)''','tokens');  C2=C{:}; C2=sprintf('%s',C2{:});
        p='';
        if(strcmp(C2,'SMRoot '))
            p=SMRoot;
        elseif(strcmp(C2,'SoftRoot '))
            p=SoftRoot;
        elseif(strcmp(C2,'ExtraFunRoot '))
            p=ExtraFunRoot;
        elseif(strcmp(C2,'RecRoot '))
            p=RecRoot;
        end
        s=['-I ' p C1 '\'];
        fprintf(fi2,'	%s\n',s);
        
    end
    l = fgetl(fi);
end
fclose(fi);

s=['rm -rf  DBParam.m~  RecDir.sh~  mccExcludedFiles.log  readme.txt run_RecDir.sh; mv RecDir Fun/bin/RecDirBin'];
fprintf(fi2,'\n%s\n',s);
fclose(fi2);

%
system(['cat ' MakeShF]);

fprintf('Compiling.....\n')
system(['chmod 744 ' MakeShF '; '  MakeShF]);
fprintf('Finished compilation\n')


