function [iv,l]=DBSize2IdxV(DBSize,l)
%Dabase Size To Idexe Vector


iv=1:l;

if ~strcmp(DBSize,'All');    
    if DBSize(1)=='R'
        iv=randperm(l); l=str2double(DBSize(2:end)); iv=iv(1:l); 
    else
        l=str2double(DBSize); iv=iv(1:l); 
    end        
end