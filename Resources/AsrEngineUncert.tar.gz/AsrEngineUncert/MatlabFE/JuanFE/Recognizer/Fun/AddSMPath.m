function [SMRoot, SoftRoot, SpeechRoot, ResRoot, RecRoot, ExtraFunRoot, KaldiTrunkRoot, ExOptF, AsrResRoot,JHome]=AddSMPath(AddPath,ExOpt)
%Add Script Matlab Paths
% AddPath=0; %To avoid adding again and waste time



%Juan and Grid Home
% %pcinfo=java.net.InetAddress.getLocalHost; HostName=pcinfo.getHostName; % need java initialization
% HomeRoot=pwd;
% AsrEngineFound = strfind(pwd,'AsrEngine');
% HomeRoot = HomeRoot(1:AsrEngineFound(end)-2);
% AsrResRoot=HomeRoot;

%AsrEngD and AsrResRoot
a=pwd; [p1, b1]=fileparts(a); [p2, b2]=fileparts(p1); [p3, b3]=fileparts(p2); [p4, b4]=fileparts(p3);
AsrEngD=p3; AsrResRoot=p4;
%JHome='/home/jmorales';
%JHome='/home/jamc';
JHome=p4;


%Get Paths from HomeRoot
SMRoot          = [AsrEngD '/MatlabFE']; %Script Matlab Dir
RecRoot         = [AsrEngD '/Recognizer']; 
ExtraFunRoot    = [AsrEngD '/ExtraFun']; %ExtraFun

ResRoot         = [AsrResRoot '/Results']; % Features Dir
%SpeechRoot      = [AsrResRoot '/SpeechData']; %Speech database Dir
SpeechRoot      = [JHome '/SpeechData']; %Speech database Dir

SoftRoot        = [SpeechRoot '/Softwares']; %Software Dir
KaldiTrunkRoot  = [SoftRoot '/Kaldi/kaldi-trunk-r4710'];


%Execution Extra Options
ExOptF=[SMRoot '/JuanFE/Recognizer/Fun/ExOpt.mat']; 
save(ExOptF,'ExOpt');

%Machine depending path
[xx, hn] = system('hostname'); HostName = deblank(hn);
switch HostName   %change if GPU      
     case {'puma', 'ecureuil'}
         %home = getenv('HOME'); 
         home = AsrResRoot;
         SpeechRoot=[home '/SpeechData'];
         ResRoot     = [home '/Results']; % Features Dir
         
         KaldiTrunkRoot ='/logiciels/kaldi-trunk-4710';
         %ResRoot     = [home '/Results']; % Features Dir
             
end






%FE External 
if strcmp(AddPath,'a')    
    
    %Recursive patth addition
    %pathString = genpath(SMRoot);   addpath(pathString); 
    
    %
 addpath([SMRoot '/ExtFun'])
    addpath([SMRoot '/JuanFE'])
    addpath([SMRoot '/JuanFE/BaseFE'])
    
    addpath([SMRoot '/JuanFE/Chi3FE'])
    addpath([SMRoot '/JuanFE/Chi3FE/Enh'])
    
    
    addpath([SMRoot '/JuanFE/UncFE'])
    addpath([SMRoot '/JuanFE/UncFE/Fun'])
    addpath([SMRoot '/JuanFE/UncFE/MC'])
    addpath([SMRoot '/JuanFE/UncFE/MC/Statistic'])    
    addpath([SMRoot '/JuanFE/UncFE/DnnUncert'])
    addpath([SMRoot '/JuanFE/UncFE/GmmUncert'])
    addpath([SMRoot '/JuanFE/UncFE/SpnUncert'])
    
  

    
    addpath([SMRoot '/JuanFE/Common'])    
    addpath([SMRoot '/JuanFE/Common/Matlab'])
    addpath([SMRoot '/JuanFE/Common/Matlab/Filter'])
    addpath([SMRoot '/JuanFE/Common/Matlab/Dict'])
    addpath([SMRoot '/JuanFE/Common/MicArray'])
    addpath([SMRoot '/JuanFE/Common/ReWr'])
    addpath([SMRoot '/JuanFE/Common/KaldMat'])
    addpath([SMRoot '/JuanFE/Common/KaldMat/ReWr'])
    addpath([SMRoot '/JuanFE/Common/Enhance'])
    
    
    addpath([SMRoot '/JuanFE/Common/RunExample'])
    
    addpath([SMRoot '/JuanFE/Common/MachLearn'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/Spn'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/Spn/SpnGmmJuRoConv'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/Spn/Matlabv2/libspn'])

    
    
    addpath([SMRoot '/JuanFE/Common/MachLearn/Fun'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/DBNToolbox'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/DBNToolbox/PreTr'])
    addpath([SMRoot '/JuanFE/Common/MachLearn/DBNToolbox/FineTr'])
    
    
    addpath([SMRoot '/JuanFE/Common/Pitch'])
    
    
    
    addpath([SMRoot '/JuanFE/Common/Pitch/ToneGram'])
    addpath([SMRoot '/JuanFE/Common/Pitch/DTWPitch'])
    addpath([SMRoot '/JuanFE/Common/Pitch/DTWPitch/Fun'])
    
    addpath([SMRoot '/JuanFE/Common/CASA'])
    addpath([SMRoot '/JuanFE/Common/CASA/Fun'])
    addpath([SMRoot '/JuanFE/Common/VAD'])    
    addpath([SMRoot '/JuanFE/Common/VAD/VadPit4EmbCl'])
    
    addpath([SMRoot '/JuanFE/Common/SignalGen'])
    addpath([SMRoot '/JuanFE/Common/Enhance/Impute'])
    addpath([SMRoot '/JuanFE/Common/Enhance/HEq'])
    
    addpath([SMRoot '/JuanFE/Common/NoiseEst'])
    
    
    addpath([SMRoot '/JuanFE/Common/Represent'])
    addpath([SMRoot '/JuanFE/Common/PlotRepr'])
    addpath([SMRoot '/JuanFE/Recognizer'])
     
    addpath([SMRoot '/JuanFE/Recognizer/Fun'])
    addpath([SMRoot '/JuanFE/Recognizer/Test'])   
    addpath([SMRoot '/JuanFE/Recognizer/Train'])   
    addpath([SMRoot '/JuanFE/Recognizer/Train/LM']) 
    addpath([SMRoot '/JuanFE/Recognizer/Train/Spn']) 
    addpath([SMRoot '/JuanFE/Recognizer/Train/Spn/TrDataUtil']) 
     addpath([SMRoot '/JuanFE/Recognizer/Train/ReWr']) 
    
    addpath([SMRoot '/JuanFE/Recognizer/AnalRes'])   
    
    %    
    addpath([ExtraFunRoot '/Transcription'])  
    addpath([ExtraFunRoot '/Transcription/Fun'])
    addpath([ExtraFunRoot '/CrDBase/Chime3/ShareASRFun']) 
    addpath([ExtraFunRoot '/CrDBase/Chime3/ShareASRFun/simulation']) 
    
    addpath([ExtraFunRoot '/ParSeqExe'])

   
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





