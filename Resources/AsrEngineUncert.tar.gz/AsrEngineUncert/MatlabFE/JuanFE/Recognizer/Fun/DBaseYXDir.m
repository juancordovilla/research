function [TrDir, TeDir]=DBaseYXDir(SDBase,DBaseRoot)
%Return TrDir, TeDir


k=SDBase;



if (strcmp(k,'FBKGEDIRHA')) 
    
    TrDir={'Dev1/S1'}; 
    TeDir={'Dev1/S1'}; 
    
    %TrDir={'Dev1/S1IsolCleanNoRev'}; 
    %TeDir={'Dev1/S1IsolCleanNoRev'}; 
    

    
elseif (strcmp(k,'CHIME3'))
       
    
%     TeDir={'DevTe/dt05_bus_real'    'DevTe/dt05_caf_real' ...
%             'DevTe/dt05_ped_real'    'DevTe/dt05_str_real' ...
%             'DevTe/et05_bus_real'    'DevTe/et05_caf_real' ...
%             'DevTe/et05_ped_real'    'DevTe/et05_str_real'};         
        
%    TeDir={'DevTe/dt05_bus_simu'    'DevTe/dt05_caf_simu' ...
%           'DevTe/dt05_ped_simu'    'DevTe/dt05_str_simu'};            
%      TeDir={'DevTe/et05_bus_simu'    'DevTe/et05_caf_simu' ...
%             'DevTe/et05_ped_simu'    'DevTe/et05_str_simu'};
    
    
    %TeDir=Root2DirList([DBaseRoot '/DevSpl' ],'DevSpl/');
    TeDir=Root2DirList([DBaseRoot '/TeSpl' ],'TeSpl/');
    
   
    %TeDir=[TeDir TeDir2];
    
    
    TrDir={...
        'Tr/tr05_bus_simu' 'Tr/tr05_caf_simu' 'Tr/tr05_ped_simu' 'Tr/tr05_str_simu' ...
        'DevTe/dt05_bus_simu' 'DevTe/dt05_caf_simu' 'DevTe/dt05_ped_simu' 'DevTe/dt05_str_simu' ...
        'DevTe/et05_bus_simu' 'DevTe/et05_caf_simu' 'DevTe/et05_ped_simu' 'DevTe/et05_str_simu' ...
        %'Tr/tr05_bus_real' 'Tr/tr05_caf_real' 'Tr/tr05_ped_real' 'Tr/tr05_str_real' ...
        %'DevTe/dt05_bus_real' 'DevTe/dt05_caf_real' 'DevTe/dt05_ped_real' 'DevTe/dt05_str_real' ...
        %'DevTe/et05_bus_real' 'DevTe/et05_caf_real' 'DevTe/et05_ped_real' 'DevTe/et05_str_real' ...
        };
   
 
        



  
elseif (strcmp(k,'GRAZCONV'))
    %YDir={'Test1/NoConv'};   
    YDir={'Test1/Conv001M'};
    %YDir={'Train1Clean/001M'};      
    
    
elseif (strcmp(k,'A2'))
    %YDir={'testa/N2_SNR0'};      
    YDir={'testa/N1_SNR5'};   
    %YDir={'testa/clean'};
    %YDir={'Train1Clean/c1'};     
    
    
    
    
elseif (strcmp(k,'DIRHAGRID'))
 
  %YDir={'Test2/S2'};
  YDir={'Dev1/S1'};
  %YDir={'Dev2/S1Clean'};  
  %YDir={'Train1Clean/Dev1S1'};       
 

    
elseif (strcmp(k,'EMBEDDIRHA'))
    
    %YDir={'TestEmbed1/0dB'};       
    YDir={'TestEmbed1/10dBCleanReverb'}; 
        
%     YDir={'VadDevEmbed1/10dBCleanReverb' 'VadDevEmbed1/10dB' 'VadDevEmbed1/0dB' ...
% 		  'VadTrEmbed1/10dBCleanReverb' 'VadTrEmbed1/10dB' 'VadTrEmbed1/0dB'};
%     XDir=YDir;
    %YDir={'VadDevEmbed1/10dB'};       XDir={'VadDevEmbed1/10dBCleanReverb'}; 
    %YDir={'VadTrEmbed1/0dB'};       XDir={'VadTrEmbed1/0dBCleanReverb'};  
    %YDir={'TestEmbed1/10dBCleanReverb'};       XDir={'TestEmbed1/10dBCleanReverb'}; 
    %YDir={'TestEmbed1/10dB'};       XDir={'TestEmbed1/10dBCleanReverb'}; 
            
    
elseif (strcmp(k,'EMBEDBAS'))
    %YDir={'TestEmbed1/0dB'};       XDir={'TestEmbed1/0dBCleanReverb'};   
    %YDir={'TestEmbed1/10dBCleanReverb'};      XDir={'TestEmbed1/10dBCleanReverb'}; 
    %YDir={'Train1Reverb/alzn'};     XDir=YDir; 

   % YDir={'Train1Clean/alzn', 'Train1Clean/behn', 'Train1Clean/chsn', 'Train1Clean/fern'};
   % YDir={'Test1Reverb/T1' 'Test1Reverb/T2' 'Test1Reverb/T3' 'Test1Reverb/T4' 'Test1Reverb/T5'};    
   % YDir={'Test1Clean/T1' 'Test1Clean/T2'};        

elseif (strcmp(k,'CHIME'))
   YDir={'DevIsol/0dB'}; XDir={'DevIsol/CleanReverb'};       

elseif (strcmp(k,'BAS'))
    %YDir={'TrainClean/G1', 'TrainClean/G2'}; 
    YDir={'TrainReverb/G1', 'TrainReverb/G2'}; 
    %YDir={'TestReverb/T5'};    
  
    
elseif (strcmp(k,'A4'))
    YDir={'train_clean/G1', 'train_clean/G2'}; XDir={'train_clean/G1', 'train_clean/G2'}; 
   
else
    disp('ERROR: Unknown Database')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function C=Root2DirList(Root,Pref)
%

S=dir(Root);
l=size(S,1);
C=[]; j=1;
for i=1:l
    d=[S(i).name];
    a = strsplit(d,'_');
    if length(a)==4
        C{j}=[Pref d];
        j=j+1;
    end    
end

%C=C(1:5);
%C=C(1);

%C=C(round(j/2):end);
%C=C(1);










