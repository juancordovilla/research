function [S]=FETrTeDir(dy,do,P)
%Feature Extractor for Training and Test of files of a Dir dy
%

%Stamp the starting date with the creation of ParamUsed.txt (used in AnalRes.m)
[x,x,x]=mkdir(do); WrStructF(P,[do '/ParamUsed.txt']);


%Analyze every file of directory
fy=dir([dy '/*' P.YExt]); 
[iv,l]=DBSize2IdxV(P.DBSize,size(fy,1));
fprintf('FETrTeDir (start at %s) for %d files of dy: %s\n',datestr(clock),l,dy);


S.BN=[]; S.OrtT=[];
for i=iv   
%for i=14
    fprintf('FE of %d (%s)\n',i,[dy '/' fy(i).name]);    
    [pn, bn]=fileparts(fy(i).name);    
    [y,P]=ReNormYX(dy,bn,P);      
    
    
    
%     [S.BN{i},S.OrtT{i},S.a(i,:)]=FERecogBase(y, x, do, bn, P);
%     a(i,:)=FEAWin(y, x, do, bn, P);
%     a(i,:)=FESift(y, x, do, bn, P);
%     a(i,:)=FEVADTunN(y, x, do, bn, P);
%     a(i,:)=FEVADHarmM(y, x, do, bn, P);
%     a(i,:)=FEDTWPit(y, x, do, bn, P);
%     a(i,:)=FEChime2(y, x, do, bn, P);
%     a(i,:)=FEChime1NingF(y, x, do, bn, P);
%     [S.BN{i},S.OrtT{i},S.a(i,:)]=FEEmbBase(y, x, do, bn, P);

%     [S.BN{i},S.OrtT{i},S.a(i,:)]=FEDirha(y,do, bn, P);


  [S.BN{i},S.OrtT{i}]=FEUnc(y,do,bn,P);

  
  
    
end












