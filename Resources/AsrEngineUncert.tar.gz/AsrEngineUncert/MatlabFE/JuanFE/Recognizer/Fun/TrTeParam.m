function [P]=TrTeParam(do,P)
%Test Parameters

P.HtkDir        = [P.SoftRoot '/HTKGrid'];
P.SpnBinDir     = [P.SoftRoot '/SPNv2/CPP/bin'];
%P.SpnBinDir     = [P.SoftRoot '/SPNv1/CPP/bin'];

P.KaldiRoot     = [P.KaldiTrunkRoot '/src'];

KTrain          = 'Clean'; %Kind of Training 
%KTrain         = 'Noisy'; 
%KTrain         = 'Enh';

%
P.SpDep         = 0; %Speaker Dependent
P.HmmDir        = [P.SpeechRoot '/Models/ASR/' 'Hmm' P.SDBase KTrain 'JuanFeat'];
%P.HmmDir        = [P.SpeechRoot '/Models/ASR/' 'Hmm' P.SDBase KTrain P.JuanKaldFeat 'DifFLNG'];
P.ExpHmmDir     = [P.ExpRoot '/HMM_0_0']; %Exp Hmm Dir (not confuse with HmmDir which is the final)
P.RecDataDir = [P.RecRoot '/Data/' P.SDBase];




%JobDir Id
P.JDirId=[P.SpCond1 '_' P.SpCond2 '_' num2str(P.TrOpt1) '_' num2str(P.TrOpt2) '_' num2str(P.TeOpt1) '_' num2str(P.TeOpt2)]; %Identifier: Dir + TrOpt + TeOpt


% WoPh=0;
% switch WoPh;  %Recognition Prefix 'Ph' (for Phonemes) or 'Wo' (for words)   
%     case 0
%         P.RecPref       = 'Wo'; %Recognition Prefix 'Ph' (for Phonemes) or 'Wo' (for words)
%         P.Hmm           = [P.HmmDir '/SI/HMMs.txt'];
%         P.WoTriPhList   = [P.HmmDir '/SI/TriPhList.txt']; %List Used in
%         P.Gram          = [RecDir '/TestGen/TestDir/' P.SDBase '/' P.RecPref 'FlatSlfGr.txt']; 
%       
%     case 1
%         P.RecPref       = 'Ph'; 
%         P.Hmm           = [P.HmmDir '/PhSI/HMMs.txt'];
%         P.WoTriPhList   = [P.RecRoot '/RecStages/TestGen/TestDir/' P.SDBase '/' P.RecPref 'W2AUDic.txt'];
%         P.Gram          = [RecDir '/TestGen/TestDir/' P.SDBase '/' P.RecPref 'SlfGr.txt']; 
% end
% 
% P.WPenalty      = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Training
%P.TransRoot   =[P.ExtraFunRoot '/Transcription'];

P.TransDir    =[P.RecDataDir '/Trans'];


[P.TrDir,P.TeDir]=DBaseYXDir(P.SDBase,[P.SpeechRoot '/' P.SDBase '_All']); %Need in GenInfo of Training

P.PhPhNDic =[P.SpeechRoot '/' P.SDBase '_All' '/LM/lang_test_tgpr_5k/phones.txt']; %Used in Spn Training
P.Ph2SVUDic=[P.SpeechRoot '/' P.SDBase '_All' '/LM/lang_test_tgpr_5k/Ph2SVUDic.txt']; %Used in Spn Training
P.Ph2GPhDic=[P.SpeechRoot '/' P.SDBase '_All' '/LM/lang_test_tgpr_5k/Ph2GPhDic.txt']; %Used in Spn Training
P.SilCsl   =[P.SpeechRoot '/' P.SDBase '_All' '/LM/lang/phones/silence.csl']; %Used in Vad Posterior Weight


% fprintf('Loading....');
% %P.TrAli=load([P.ExpHmmDir '/Spn/Tr/AliTr.mat']); %Very heavy!!!
% P.DevAli=load([P.ExpHmmDir '/Spn/Dev/AliDev.mat']); %Very heavy!!!
% fprintf('load\n')





