function KaldWer(Wer,EstT,TrueT)
%





