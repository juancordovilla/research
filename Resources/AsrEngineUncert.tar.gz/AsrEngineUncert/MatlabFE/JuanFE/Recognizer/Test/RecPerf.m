function RecPerf(S,do,P)
%Recognition Performance


%
IgnWord1    = '!JENTER'; %Ignored Word 1
IgnWord2    = '!JEXIT'; %Ignored Word 2
IgnWord3    = 'sil'; %Ignored Word 1
%IgnWord2    = 'sil'; %Ignored Word 2

TestDir     = [P.RecRoot '/RecStages/TestGen/TestDir/' P.SDBase];
P.TrueMlfT	= [TestDir '/' P.RecPref 'MlfWTrans.txt']; 
P.WList 	= [TestDir '/' P.RecPref 'WList.txt'];


%ResDir
[p1, b1]    = fileparts(do); [p2, b2]=fileparts(p1); [p3, b3]=fileparts(p2); 
ResDir      = [p3 '/RES/FEMatRes']; mkdir(ResDir); 


EstMlfT     = [ResDir '/EstMlfT_' b2 '_' b1 '_' num2str(P.TeOpt1) '_' num2str(P.TeOpt2) '.txt'];
HtkRes      = [ResDir '/HtkRes_' b2 '_'   b1 '_' num2str(P.TeOpt1) '_' num2str(P.TeOpt2) '.txt']; 

%Unwrap
BN=UnwrapCell(S.BN);
OrtT=UnwrapCell(S.OrtT);

%Avoid it if training (for future)
BNTranDic2Mlf(EstMlfT,BN,OrtT,'.rec');
s=[P.HtkDir '/HResults -e ''???'' \' IgnWord1 '  -e ''???'' \' IgnWord2  '  -e ''???'' \' IgnWord3 ' -I ' P.TrueMlfT ' ' P.WList ' ' EstMlfT ' > ' HtkRes]; 
system(s);
fprintf('Htk result in: %s\n',HtkRes);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function US=UnwrapCell(S)
%
n=length(S);
US={};
for i=1:n
    if ~isempty(S{i})
        a=S{i};        US=[US a{:}]; 
    end
end
