function [FBN,Trans]=SortCatStTrans(Isol,do,bn,kind)
%Sorted (based on st time) and Cat or Structured Trainscriptions



FBN=[]; Trans=[];

if ~isempty(Isol)

st=StArFNExtract(Isol,'st'); [sto,idx]=sort(st,'ascend');

switch kind
    
    case 'c' %cat
        t='';
        for i=idx
            t=[t ' ' Isol(i).EstWTrans];   
        end               
        [pn1 bn1]=fileparts(do); [pn2 bn2]=fileparts(pn1); 
        Trans{1}=t; 
        FBN{1}=[lower(bn2) bn];
        
    case 's' %structure
        for i=idx
            Trans{i}=Isol(i).EstWTrans;   
            FBN{i}=Isol(i).bn; 
        end

end
        

end