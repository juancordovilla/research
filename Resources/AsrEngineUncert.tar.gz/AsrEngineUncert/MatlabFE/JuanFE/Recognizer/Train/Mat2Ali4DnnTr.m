function Mat2Ali4DnnTr(do,FiTr,FiDev)
%

[x,x,x]=mkdir(do);

TrX=FiTr.X; TrY=FiTr.Y; DevX=FiDev.X; DevY=FiDev.Y;




123
pause