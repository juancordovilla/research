function AliFmllrT(TrKaldDir,InfoDir,K,P)
%Compute Alignement and Fmllr Transformation


AliK='InAliFmllr';
%AliK='fmllr';
AlignDir = '/home2/jamc/SpeechData/Models/ASR/Feats/HMM_0_0/Align';

%Common
MfccInfo        = [InfoDir '/Mfcc' K 'InfoDir'];
MfccData       =[MfccInfo '/TmpDir'];
LM                 = [AlignDir '/lang']; %/home/jmorales/Results/FE_0_0_0_0/HMM_0_0/LM/lang
ODir              = [AlignDir '/' K 'ODir']; 
AliGz             = [AlignDir '/' K 'Ali.1.gz'];


FeatType       = 'Kald'; 

%Change if mono-si or fmllr
% HmmTree = [AlignDir '/mono0a_tr05_multi_enhanced']; 
HmmTree = [AlignDir '/tri3b_tr05_multi_enhanced'];


%Prepare
Info2Data(MfccInfo,MfccData);
c1=['cd ' TrKaldDir]; %due to not absolute path of align_si.sh functions 


%
switch AliK
    case 'si'
        c2=[TrKaldDir '/GmmTr/align_si.sh --nj 1 --use-graphs true ' MfccData ' ' LM ' ' HmmTree ' ' ODir ' ' FeatType ' ' P.KaldiTrunkRoot ' ' TrKaldDir];
    case 'fmllr'
        c2=[TrKaldDir '/DnnTr/align_fmllr.sh --nj 1 ' MfccData ' ' LM ' ' HmmTree ' ' ODir ' ' P.KaldiTrunkRoot];
    case 'InAliFmllr'
        c2=[TrKaldDir '/DnnTr/InAlign_fmllr.sh --nj 1 ' MfccData ' ' LM ' ' HmmTree ' ' ODir ' ' P.KaldiTrunkRoot ' ' AliGz];       
end


system([c1 ' ;' c2]);

%rmdir([MfccData '/TmpDir'],'s');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Info2Data(IDir,ODir)
%Info (Juan name format) To Data (Kaldi name format)
[x,x,x]=mkdir(ODir);
copyfile([IDir '/CmvnScp.txt'],[ODir '/cmvn.scp']);
copyfile([IDir '/FeatScp.txt'],[ODir '/feats.scp']);
copyfile([IDir '/Spk2Utt.txt'],[ODir '/spk2utt']);
copyfile([IDir '/Utt2Spk.txt'],[ODir '/utt2spk']);
copyfile([IDir '/Text.txt'],[ODir '/text']);

% apply-cmvn --utt2spk=ark:/home/jmorales/Results/FE_0_0_0_0/HMM_0_0/Info/MfccDevInfoDir/TmpDir/split1/1/utt2spk 
% scp:/home/jmorales/Results/FE_0_0_0_0/HMM_0_0/Info/MfccDevInfoDir/TmpDir/split1/1/cmvn.scp 
% scp:/home/jmorales/Results/FE_0_0_0_0/HMM_0_0/Info/MfccDevInfoDir/TmpDir/split1/1/feats.scp 


