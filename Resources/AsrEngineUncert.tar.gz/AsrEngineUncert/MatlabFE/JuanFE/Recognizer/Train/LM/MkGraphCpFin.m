function MkGraphCpFin(TrKaldDir,LMRes,GmmRes,P)
%Make Graph HCLG.fst and Copy Final results




%Makegraph
LM      = [LMRes '/lang_test_tgpr_5k'];
HmmTree = [GmmRes '/MDir/exp/tri3b_tr05_multi_enhanced']; 
ODir    = [HmmTree '/graph_tgpr_5k'];
Opt     = ''; %--mono %For Monophone: $LMPrepDir/mkgraph.sh --mono      $langtest $HmmTree $HmmTree/graph_tgpr_5k  $KaldiRoot

%c=[TrKaldDir '/LMPrep/mkgraph.sh ' Opt ' '   LM ' ' HmmTree ' ' ODir ' ' P.KaldiTrunkRoot ' ' TrKaldDir];
%system(c)

%Copy to Final GmmRes
%[x,x,x]=mkdir([GmmRes '/4Dnn']); system(['cp ' HmmTree '/* ' GmmRes '/4Dnn']);
%[x,x,x]=mkdir([GmmRes '/FinalGmm']); system(['cp ' HmmTree '/final.mat ' HmmTree '/graph_tgpr_5k/HCLG.fst ' GmmRes '/FinalGmm'])
%copyfile([HmmTree '/35.mdl'], [GmmRes '/FinalGmm/final.alimdl'])



%Old
% if exist([HmmTree '/final.alimdl'],'file')
%     123
%     copyfile([HmmTree '/final.alimdl'], [GmmRes '/FinalGmm'])
% else
%     copyfile([HmmTree '/35.mdl'], [GmmRes '/FinalGmm/final.alimdl'])
% end