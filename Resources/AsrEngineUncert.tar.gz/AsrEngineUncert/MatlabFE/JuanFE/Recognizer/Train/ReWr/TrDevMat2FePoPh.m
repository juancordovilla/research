function [Tr,Dev,NS]=TrDevMat2FePoPh(TrMat,DevMat,AsTr,AsDev,PermK,MixTrDevSamp)                                                             
%Read Development Training  of 1 align Label
%Tr, Dev: set of samples from tr dev data
%kind: 'f' (first), 'r' (random)


if MixTrDevSamp    
   error('To finish')    
else




%Load
[TrFe,TrModO,TrPo,TrPh]=LoChFePoPh(TrMat);
[DevFe,DevModO,DevPo,DevPh]=LoChFePoPh(DevMat);


AvTr=size(TrFe,2); %Original
AvDev=size(DevFe,2);






    

    %Re Distribute
    [ptr,pdev,pdev_tr]=SampDistrTrDevSet(AvTr,AsTr,AvDev,AsDev,PermK,TrModO);

    %Number of Sample info
    NS.AvTr=AvTr; NS.AvDev=AvDev; 
    NS.ptr=length(ptr); NS.pdev=length(pdev); NS.pdev_tr=length(pdev_tr);

    %Take
    Tr.Fe=TrFe(:,ptr); 
    Tr.Po=TrPo(:,ptr); 
    %Tr.Ph=TrPh(:,ptr); 
    Tr.ModO=TrModO(:,ptr); 

    Dev.Fe=[DevFe(:,pdev) TrFe(:,pdev_tr)];
    Dev.Po=[DevPo(:,pdev) TrPo(:,pdev_tr)];
    %Dev.Ph=[DevPh(:,pdev) TrPh(:,pdev_tr)];
    Dev.ModO=[DevModO(:,pdev) TrModO(:,pdev_tr)]; 


end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



