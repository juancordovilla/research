function [Feat,ModO,Post,Phone]=LoChFePoPh(MatF)
%Load and Check Feat Post and Phone 


if exist(MatF,'file')      
    S=load(MatF);
    Feat=S.Feat;
    ModO=S.ModO;
    Post=S.Post;
    %Phone=S.Phone;   
    Phone=[];
   
    
    %CheckAliMat(Feat,Post,Phone,PhoneNa); miss models
    
else
    fprintf('WARNINGIN: Doesnt exist %s\n',MatF); %Not official Matlab because missing is allowed
    Feat=[]; Post=[];  ModO=[]; Phone={};
end