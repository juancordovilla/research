function CheckAliMat(Feat,ModO,Post,Phone,models)
%Check Alignement .Mat (Posterior, Phone and Feature) 
%Kind: 'Post' 'Ph'
%TrueLa: True Label

nf=size(Feat,2);
if length(Post)~=nf
    warning('length(Post)~=nf\n');
end
if length(Phone)~=nf
    warning('length(Phone)~=nf\n');
end

if length(ModO)~=nf
    warning('length(ModO)~=nf\n');   
end

%
%CheckPhPoTrCl(Post,Phone,models)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CheckPhPoTrCl(Po,Ph,models)
%Check Phone (0...PhNumb-1) and Posteriors (0...NPdf-1) of a Training Class


%FUTURE: Convert Ph (names) to number


UPh=unique(Ph);



for i=1:length(UPh)   
    %
    UPdf=PhN2PdfN(UPh(i),models); TUPo=UPdf{1}-1; %True Unique Posteriors
    j=Ph==UPh(i);   FUPo=unique(Po(j)); %Found UPo    
    % 
    Lia = ismember(FUPo,TUPo);      %Lia = ismember(A,B); %data in A is found in B   
    if sum(Lia)~=length(Lia)
        error('Ph-Po bad match')
    end  
end
