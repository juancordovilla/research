function SaChFePoPh(MatF,Feat,ModO,Post,Phone,models)
%Save and Check Features Posteriors and Phonemes


CheckAliMat(Feat,ModO,Post,Phone,models);

save(MatF,'Feat','ModO','Post','Phone');    
fprintf('Written: %s\n',MatF);

