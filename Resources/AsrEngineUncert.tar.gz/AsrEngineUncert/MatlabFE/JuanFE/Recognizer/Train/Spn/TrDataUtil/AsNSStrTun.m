function [AsTr,AsDev,AsFiTr,AsFiDev]=AsNSStrTun(TrNS,TrDevR,PDFiR)
%Asked Number of Samples (of Tr and Dev) for Structure and Tunning

AsTr=TrNS;
AsDev=round(TrDevR*AsTr);
AsFiTr=AsTr*PDFiR; 
AsFiDev=AsDev*PDFiR; 

