function SpnMatF=SaMod2MatSpn(modelFile,TrY,DevY,Info,MatSufix,Save)
%Save .Mod To .Mat Spn
%Save

SpnMatF=RoMod2JuMatSpnFN(modelFile,MatSufix);


%
if (nargin<8)
    Save=1;
end




if Save==1    
    
    fprintf('Mod2Mat %s....\n',SpnMatF);
    
    %
    Info.Y=unique([TrY DevY]);    
    %
    Spn=Ro2JuSpn(modelFile);    
    [Spn.FaIdx,Spn.FaLW,Spn.ChFaNoIdx,Spn.NFa]=Spn2FaIdxLW(Spn);    
    Spn.LayK=SpnLayerKind(Spn);
    
    save(SpnMatF,'Spn','Info');
    fprintf('Saved Spn model:%s\n',SpnMatF);
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

