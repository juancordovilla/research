function DiscrSpnTrFE(x,do,bn,P)
%Discriminative Spn Training Feature Extraction




%Future: Switch TrAli DevAli
%A=P.TrAli;
A=P.DevAli;

% %Align Pdf     
AAliPdf=Key2ValDict({bn},A.BN,A.PoC,1);   
AliPdf=AAliPdf{:}; %extract cell
%AliPdf=-1;



% %Save
fn=[do '/Ali' bn '.mat'];
save(fn,'AliPdf');
fprintf('Written: %s\n',fn);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%For Discrimative with NBest
% %PseudoLL
% P.FEOpt1=0;
% P.FEOpt2=-1;    
% [Y,U,HmmDir,RecK,X]=FeUncSwit(-1,-1,x,do,bn,P);
% PseudoLL=Unc2LikGramDnn(Y,U,HmmDir,RecK,P);  
% %NBest Pdf 
% [Lat,Trans]=Lik2LattTrans(PseudoLL,HmmDir,do,bn,P);    
% %S.OrtT{1}=Trans; S.BN{1}=bn; RecPerfDirKald(S,do,P);
% NBest=Lat2NBest(Lat,10,do,bn,P);    
% NBestPdf=NBest2PdfSeq(NBest,HmmDir,P.KaldiRoot);
% 
% 
% %Save
% fn=[do '/Pdf' bn '.mat'];
% save(fn,'AliPdf','NBestPdf');
% fprintf('Written: %s\n',fn);


