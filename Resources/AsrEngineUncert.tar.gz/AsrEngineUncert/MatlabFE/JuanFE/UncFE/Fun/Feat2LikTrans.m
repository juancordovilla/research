function Trans=Feat2LikTrans(Y,U,HmmDir,RecK,do,bn,P)
%Features To Likegram and Transcription

% fn=[P.do '/PseudoLL' P.bn '.mat'];
% fn=strrep(fn, '/home/jmorales/', '/home/jmorales/Mnt/Grid5000Home/');
% S=load(fn); PseudoLL=S.PseudoLL;
% jimagesc(PseudoLL)
% pause

%
% fn2=strrep(fn, '/FE_3_-1_0_0/', '/FE_0_-1_0_0/'); S=load(fn2); PseudoLL2=S.PseudoLL;
% fn3=strrep(fn, '/FE_3_-1_0_0/', '/FE_1_-1_0_0/'); S=load(fn3); PseudoLL3=S.PseudoLL;
% %
% subplot(311), jimagesc(PseudoLL)
% subplot(312), jimagesc(PseudoLL2)
% subplot(313), jimagesc(PseudoLL3)
% D=(PseudoLL-PseudoLL2); mean(abs(D(:))) 
% D=(PseudoLL-PseudoLL3); mean(abs(D(:))) 
% pause
% %
% [FL,nf]=size(PseudoLL);
% for i=1:10:nf
%     a1=PseudoLL(:,i);
%     a2=PseudoLL2(:,i);
%     a3=PseudoLL3(:,i);    
%     %plot(exp(a1)), hold on, plot(exp(a2),'ro'), plot(exp(a3),'g+'), hold off, 
%     subplot(311), plot(exp(a1)), 
%     subplot(312), plot(exp(a2)), 
%     subplot(313), plot(exp(a3)),     
%     pause    
% end
% PseudoLL=PseudoLL;


%
switch RecK{1}  
        
%     case 'KaldGmm'
%         [Lat,Trans]=KaldFeatGram2Lat(Y,'Gmm',HmmDir,do,bn,P);        
%     case 'KaldDnn'
%         [Lat,Trans]=KaldFeatGram2Lat(Y,'Dnn',HmmDir,do,bn,P);
%       
%     case 'KaldDnnLik'
%         PseudoLL=Feat2KaldLikGram(Y,HmmDir,do,bn,P);    
%         [Lat,Trans]=Lik2LattTrans(PseudoLL,HmmDir,do,bn,P);    
%         
%     case {'Gmm', 'GmmEn_OU2', 'GmmMC_OU2', 'GmmMD_OU2','UnGmm','MDGmm','MDNGmm'}
%         PseudoLL=Unc2LikGramGmm(Y,U,HmmDir,RecK,do,bn,P);              
%         [Lat,Trans]=Lik2LattTrans(PseudoLL,HmmDir,do,bn,P);
        
    case {'Spn','Gmm'}
        [PseudoLL]=Unc2LikGramSpn(Y,U,HmmDir,P.FEOpt3,P.ExOpt.MvnK,RecK{2},P);        
        
    otherwise %DNN uncertainty        
        PseudoLL=Unc2LikGramDnn(Y,U,HmmDir,RecK{2},P);       
         
        
end

[Lat,Trans]=Lik2LattTrans(PseudoLL,HmmDir,do,bn,P); 
%Trans='-1';


%fn=[P.do '/PseudoLL' P.bn '.mat'];
%save(fn,'PseudoLL'); fprintf('Written: %s\n',fn);
%fprintf('\n\nRecognition of %s: %s\n\n',bn,Trans);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%











