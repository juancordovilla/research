function FeatScp2Cmvn(CmvnFeat,CmvnScp,Spk2Utt,Utt2Spk,FeatScp,KaldiRoot)
%
%Also it produces Spk2Utt, Utt2Spk. All of them are automatically sorted



FeatScp2Spk2Utt(Spk2Utt,Utt2Spk,FeatScp);  
        
        
compute_cmvn_stats =[KaldiRoot '/featbin/compute-cmvn-stats'];        
c=[compute_cmvn_stats ' --verbose=0 --spk2utt=ark:' Spk2Utt ' scp:' FeatScp ' ark,scp:' CmvnFeat ',' CmvnScp];
system(c);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function FeatScp2Spk2Utt(Spk2Utt,Utt2Spk,FeatScp)
%
fi=fopen(FeatScp,'r');
C=textscan(fi,'%s %s'); A=C{1}; B=C{2};
fclose(fi);

%Utt2Spk
fi=fopen(Utt2Spk,'w');
l=length(A);
for i=1:l;    
    a=A{i};  

    sp{i}=a(1:3); 
    fprintf(fi,'%s %s\n',a,sp{i});
end
fclose(fi);

%Spk2Utt
usp=unique(sp);
l2=length(usp);
fi=fopen(Spk2Utt,'w');
for i=1:l2
    j=strcmp(usp{i},sp);    B=A(j);   
    fprintf(fi,'%s ', usp{i});    fprintf(fi,'%s ',B{:});    fprintf(fi,'\n');    
end
fclose(fi);