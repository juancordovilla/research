function PdfSeq=NBest2PdfSeq(NBest,HmmDir,KaldiRoot)
%
%PdfSeq: is NBest*nf matrix with the sequences of Pdfs

models=ReSaKaldGmm([HmmDir '/final.mdl'],0,KaldiRoot);


%NBest=Id2PdfNBest(NBest)
%PhC=PhN2Ph(PhNC,P.PhPhNDic);

u=1; %Now for only 1 utterance. Future perhaps many


b=NBest.nbest{u};
NumNBest=length(b);
nf=length(b{1}.seq);
PdfSeq=zeros(NumNBest,nf);
for n=1:NumNBest
    ids=b{n}.seq;
    state=models.TransitionModel.Id2state(ids);        %from transition-id to transition state
    PdfSeq(n,:)=models.TransitionModel.Triples(state,3);      %from transition state to pdf-id    
end


