function [Lat,Trans]=LikGram2LattNBest(StPr,HmmDir,do,bn,P)
%



%Common
TestDir           =[P.RecRoot '/RecStages/TestGen/TestDir/' P.SDBase];
WList             =[TestDir '/' P.RecPref 'WList.txt']; 

%Old version (with noisy Lat, not delete until I obtain good results with new version)
 NumNBest    ='1000';
 models      =readkaldigmms([HmmDir '/final.mdl'],P.KaldiRoot); %0.9s
 
%
OLatGz       =[do '/' bn 'OLatGz.ark'];
 
 
%
StPrC{1}=StPr;    
Lat2ULatNBest(OLatGz,LatGz,StPrC,models,WList,do,bn,NumNBest,P);
 
 
%
Trans=LatGz2Trans(LatGz,do,bn,P);
Lat=ReKaldLatt(LatGz,WList,P.KaldiRoot,P.KaldiTrunkRoot);
 
 
 %
 delete(OLatGz);
 