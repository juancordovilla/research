function StPr=Feat2KaldLikGram(Feat,HmmDir,do,bn,P)
%


%
FeatScp =[do '/' bn 'FeatScp.txt'];
FeatArk    =[do '/' bn 'Feat.ark'];

A.utt={bn}; A.feature={Feat};
WrKaldFeat(A,FeatArk,FeatScp,P.KaldiRoot);


%
nnet_forward        =[P.KaldiRoot '/nnetbin/nnet-forward --verbose=0']; %Brno and Microsoft, Karel Vesely
copy_feats          =[P.KaldiRoot '/featbin/copy-feats --verbose=0'];
%    3 //         Copyright 2009-2012  Microsoft Corporation, Karel Vesely
%     4 //                2013  Johns Hopkins University (author: Daniel Povey)
%     5 //                2014  Guoguo Chen

%Model
feature_transform   =[HmmDir '/final.feature_transform']; %generated at training
class_frame_counts  =[HmmDir '/ali_train_pdf.counts'] ;
nnet                =[HmmDir '/final.nnet'];


%Command
feat=['ark,s,cs:' copy_feats ' scp:' FeatScp ' ark:- |'];
loglikes_rspecifier=[FeatScp(1:end-3) 'ark'];  

c=[nnet_forward ' --feature-transform=' feature_transform ' --no-softmax=true --class-frame-counts=' class_frame_counts ... 
   ' --use-gpu=no ' nnet ' "' feat '" ark,t:' loglikes_rspecifier];
system(c);

%Read
[BN,StPr]=ReKaldTxtM(loglikes_rspecifier);

delete(FeatScp,FeatArk,loglikes_rspecifier);

StPr=StPr'; %in Matlab we work as nst*nf

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


