function NBest=Lat2NBest(Lat,NumNBest,do,bn,P)
%Lat: Matlab latix (no .gz)
%NBest: Matlab NBest (no .gz) 



TmpNBestGz     =[do '/Tmp' bn 'NBest.gz'];
TmpLatGz       =[do '/Tmp' bn 'LatGz.ark'];


%
WList          = [P.RecDataDir '/WoWList.txt'];
WrKaldLatt(Lat,TmpLatGz,WList,P.KaldiRoot,P.KaldiTrunkRoot)


%
%fprintf('lattice_to_nbest....');
lattice_to_nbest=[P.KaldiRoot '/latbin/lattice-to-nbest'];
c=[lattice_to_nbest '  --acoustic-scale=0.10 --n=' num2str(NumNBest) ' ark:"gunzip -c ' TmpLatGz ' |" ark:"|gzip -c > ' TmpNBestGz '"'];
system(c);  
%fprintf('done\n');

%
NBest=readkaldinbests(TmpNBestGz,WList,P.KaldiRoot,P.KaldiTrunkRoot); %2.5 sec









