function Trans=LatGz2Trans(LatGz,do,bn,P)
%


WList             = [P.RecDataDir '/WoWList.txt'];


TempScor=  [do '/TempScor' bn '.txt'];
TempETran= [do '/TempETran' bn '.txt'];



%LatGz to TempScor
%--inv-acoustic-scale=4 (default) [1,10]. 
c=[P.KaldiRoot '/latbin/lattice-scale --inv-acoustic-scale=4 ' ...
   '"ark:gunzip -c ' LatGz '|" ark:- | ' P.KaldiRoot '/latbin/lattice-add-penalty ' ...
   '--word-ins-penalty=0.0 ark:- ark:- |' ...
   P.KaldiRoot '/latbin/lattice-best-path --word-symbol-table=' WList ' '...
   'ark:- ark,t:' TempScor];
system(c);



%TempScor to TempETran
int2sym=[P.KaldiTrunkRoot '/egs/wsj/s5/utils/int2sym.pl'];
c=['cat ' TempScor ' | ' int2sym ' -f 2- ' ...
WList ' | sed s:\<UNK\>::g > ' TempETran];
system(c);

%
[BN,Trans]=ReDictF(TempETran);
Trans=Trans{1};


delete(TempScor,TempETran)