function [FeatCo]=gmm_applyContext(Feat,finalmat,k,do,bn,P)
%

%In features (From FE)
CmvnFeat=[do '/' bn 'CmvnFeat.ark']; 
CmvnScp =[do '/' bn 'CmvnScp.txt'];
Utt2Spk =[do '/' bn 'Utt2Spk.txt'];
Spk2Utt =[do '/' bn 'Spk2Utt.txt'];
FeatScp =[do '/' bn 'FeatScp.txt'];
FeatArk =[do '/' bn 'Feat.ark'];
KaldFeatTxt    =[do '/' bn 'KaldFeat.txt'];

%
A.utt={bn}; A.feature={Feat};
WrKaldFeat(A,FeatArk,FeatScp,P.KaldiRoot);
FeatScp2Cmvn(CmvnFeat,CmvnScp,Spk2Utt,Utt2Spk,FeatScp,P.KaldiRoot);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
splice_feats        =[P.KaldiRoot '/featbin/splice-feats --verbose=0'];
transform_feats     =[P.KaldiRoot '/featbin/transform-feats --verbose=0'];
apply_cmvn          =[P.KaldiRoot '/featbin/apply-cmvn --verbose=0'];
add_deltas          =[P.KaldiRoot '/featbin/add-deltas --verbose=0'];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% feats="ark,s,cs:apply-cmvn $cmvn_opts --utt2spk=ark:$sdata/JOB/utt2spk scp:$sdata/JOB/cmvn.scp scp:$sdata/JOB/feats.scp ark:- | add-deltas ark:- ark:- |";;
% 
% apply-cmvn --utt2spk=ark:/home/jmorales/Results/FE_0_0_0_0/HMM/Gmm/MDir/data/tr05_multi_enhanced/split1/JOB/utt2spk 
% scp:/home/jmorales/Results/FE_0_0_0_0/HMM/Gmm/MDir/data/tr05_multi_enhanced/split1/JOB/cmvn.scp 
% scp:/home/jmorales/Results/FE_0_0_0_0/HMM/Gmm/MDir/data/tr05_multi_enhanced/split1/JOB/feats.scp ark:- | add-deltas ark:- ark:- |

switch k
    case 'Delta'
        c=[apply_cmvn ' --utt2spk=ark:' Utt2Spk ' scp:' CmvnScp ' scp:' FeatScp ' ark:- | ' add_deltas ' ark:- ark,t:' KaldFeatTxt];
    case 'Lda'
        c =[apply_cmvn ' --utt2spk=ark:' Utt2Spk ' scp:' CmvnScp ' scp:' FeatScp ' ark:- | '  ... 
        splice_feats ' --left-context=3 --right-context=3 ark:- ark:- | ' transform_feats ' ' finalmat ' ark:- ark,t:' KaldFeatTxt];
end


system(c);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[BN,FeatCo]=ReKaldTxtM(KaldFeatTxt); FeatCo=FeatCo'; %in Matlab we work FL*nf

delete(CmvnFeat,CmvnScp,Utt2Spk,Spk2Utt,FeatScp,FeatArk,KaldFeatTxt)

% subplot(211), jimagesc(Feat)
% subplot(212), jimagesc(FeatCo)
% pause



