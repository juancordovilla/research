function [LPreA3D,Post3D]=X3D2ContPostDnn(X3D,config,nnet)
%X3D (featuregram samples in 3D matrix) To Context (append suround frames) and Posteior with Dnn 

%Apply context and compute posteriors
[NSamp,FL,nf]=size(X3D);
NSt=length(nnet{end});

LPreA3D=zeros(NSamp,NSt,nf);
Post3D=zeros(NSamp,NSt,nf);

for i=1:NSamp    
    if config==-1
        FeC=squeeze(X3D(i,:,:));
    else
        FeC=nnet_applyContext(squeeze(X3D(i,:,:)),config,'feat');
    end
    [LPreA3D(i,:,:),Post3D(i,:,:)]=nnet_forward(nnet,FeC);  
end


