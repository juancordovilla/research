function LPostF=Av3DLPost(LPreA3D,Post3D,w,OUK)
%Average 3D matrix Log Posterior
%LPreA3D,Post3D: PreActivations and Posteiors
%w: weigth per sample (they should sum 1)
%OUK: OU (average) Kind


%Average Likel
switch OUK
    case 'OU1'
        fprintf('OU1\n');
        LPostF=MeVa3DM(LPreA3D,w);
    case 'OU2' %Best results WER=42.45!!!!
        fprintf('OU2\n');
        LPostF=log(MeVa3DM(Post3D,w));
    case 'OU3'
        fprintf('OU3\n');       
        LPostF=MeVa3DM(log(Post3D),w);            
end