function PseudoLL=Unc2LikGramGmm(Y,U,HmmDir,RecK,do,bn,P)
%Uncertainty To Likelihood Gram (Acoustic States Prob of Observation)
%Y: feature has already context 


%
models =ReSaKaldGmm([HmmDir '/final.alimdl'],1,P.KaldiRoot);




%
Pdfs=models.Pdfs;              
NPdf=length(Pdfs);

%Gmm2Spn(HmmDir,Pdfs); pause

   
%
fprintf('UnGmm: %s...\n',RecK);

switch RecK       
    
    case 'Gmm'
        PseudoLL=GmmLogLik(Y,Pdfs);           
        %PseudoLL=SpnLogLikUnc(Y,U,P.MF,HmmDir,NPdf,'Spn',[P.SpnBinDir '/'],-1); %With SPN       
     
        
    case {'UnGmm'}
        
        %PseudoLL2=GmmLogLikUnc(Y,U,Pdfs,P.MF,RecK); %Orignal
        PseudoLL=SpnDir2LogLikUnc(Y,U,P.MF,HmmDir,NPdf,'UnSpn',[P.SpnBinDir '/'],-1,HmmDir,models,P); %With SPN
                           
        
%         subplot(211), jimagesc(PseudoLL)
%         subplot(212), jimagesc(PseudoLL2)
%         sum(PseudoLL2(:))
%         sum(PseudoLL(:))
%         pause
        
        
    case {'MDGmm'}    
        
        PseudoLL=SpnLogLikUnc(Y,U,P.MF,HmmDir,NPdf,'MDSpn',[P.SpnBinDir '/'],-1); %With SPN
        %PseudoLL2=GmmLogLikUnc(Y,U,Pdfs,P.MF,RecK); %Orignal                
           
        
%         subplot(411), jimagesc(Y)
%         subplot(412), jimagesc(U)
%         subplot(413), jimagesc(PseudoLL)
%         subplot(414), jimagesc(PseudoLL2)
%         sum(PseudoLL(:))
%         sum(PseudoLL2(:))
%         pause
        
        
    case {'GmmEn_OU2','GmmMC_OU2', 'GmmMD_OU2'}    
        [X3D,w]=GenMCSamp(Y,U,RecK(4:5),P);        
        
        %%%%%%%%%%%%%%%        
        [NSamp,FL,nf]=size(X3D);     NPdf=length(Pdfs);
        PseudoLL3D=zeros(NSamp,NPdf,nf); PseudoL3D=zeros(NSamp,NPdf,nf);
        for i=1:NSamp                
            PseudoLL3D(i,:,:)=GmmLogLik(squeeze(X3D(i,:,:)),Pdfs); 
            PseudoL3D(i,:,:)=exp(PseudoLL3D(i,:,:));
        end        
        %%%%%%%%%%%%%%%%%%%        
        PseudoLL=Av3DLPost(PseudoLL3D,PseudoL3D,w,RecK(end-2:end));
        
        
end



% subplot(311), jimagesc(Y)
% subplot(312), jimagesc(U)
% subplot(313), jimagesc(PseudoLL)
% sum(PseudoLL(:))
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%










