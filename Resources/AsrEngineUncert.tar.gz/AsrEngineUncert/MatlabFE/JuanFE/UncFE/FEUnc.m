function [bn,Trans]=FEUnc(ym,doo,bn,P)
%bn:


%Parameters
P       = DerivParam(P);
Trans   = '--1';


if strcmp(P.RecSt,'FETe')   

do      = ['/tmp' doo];  if ~exist(do,'dir'); system(['mkdir -p ' do]); end
P.do    = [doo]; P.bn=bn; if ~exist(P.do,'dir'); system(['mkdir -p ' P.do]); end


y=SignEnh(ym,P.nm,P.FSamp,'RefMic',P);  
x=SignEnh(ym,P.nm,P.FSamp,'Cl',P);  

[Y,U,HmmDir,RecK,P]=FeUncSwit(y,ym,x,do,bn,P);

Trans=Feat2LikTrans(Y,U,HmmDir,RecK,do,bn,P);

      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
else
    
    %Clean, Enh or Noisy signal
    do=doo;
    %x=SignEnh(ym,P.nm,P.FSamp,'Cl',P,bn);
    %y=SignEnh(ym,P.nm,P.FSamp,'RefMic',P); x=y;
    xest=SignEnh(ym,P.nm,P.FSamp,'Chi4Arie',P,bn); x=xest;
 
    
%     %0) Standard
%      Cx=Sign2Feat(x,P,'Mfcc');      
%      Fbx=Sign2Feat(x,P);      
   
    
        
    %1) 40x1 Fmllr
     HmmDir=[P.ExpHmmDir '/Spn/FinalSpn'];
     Cx=Sign2Feat(x,P,'Mfcc');      
     Fbx=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
     Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1);      

     
%     %2) 40x11 Fmllr
%      HmmDir=[P.ExpHmmDir '/Spn/FinalSpn'];
%      Cx=Sign2Feat(x,P,'Mfcc');      
%      Fbx=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%      Fbx=AppContext(Fbx,5);  
%      Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1); 
               
     
%      %3) 40x1 Fbank 
%      HmmDir=[P.ExpHmmDir '/Spn/FinalSpn'];
%      Cx=Sign2Feat(x,P,'Mfcc');    
%      Fbx=Sign2Feat(x,P);     
%      Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1); 
     
%       %4) 40x11 Fbank     
%       HmmDir=[P.ExpHmmDir '/Spn/FinalSpn'];
%       Cx=Sign2Feat(x,P,'Mfcc');    
%       Fbx=Sign2Feat(x,P); Fbx=AppContext(Fbx,5);     
%       Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1); 
     

%     subplot(311), jimagesc(Cx)
%     subplot(312), jimagesc(Fbx)    
%     subplot(313), jplot(x)
%     pause


    WriteHTKF([do '/' bn '.Cx'], Cx, 0, 1);
    WriteHTKF([do '/' bn '.Fbx'], Fbx, 0, 1);
    %DiscrSpnTrFE(x,do,bn,P);
    

    
end










