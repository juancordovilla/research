function [PseLL,PseL]=X3D2LogLikSpn(X3D,Y,U,MF,SpnMatDir,NPdf,UnK,P)
%X3D (featuregram samples in 3D matrix) To Context (append suround frames) and Posteior with Dnn 

%Apply context and compute posteriors

[NSamp,FL,nf]=size(X3D);


PseLL=zeros(NSamp,NPdf,nf);
for i=1:NSamp    
    Y=squeeze(X3D(i,:,:));
    [PseLL(i,:,:)]=SpnDir2LogLikUnc(Y,-1,P.MF,SpnMatDir,NPdf,'Sta',P);   
end

PseL=exp(PseLL);

