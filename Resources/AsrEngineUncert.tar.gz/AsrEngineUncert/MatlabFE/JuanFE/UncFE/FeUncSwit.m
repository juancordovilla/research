function [Y,U,HmmDir,RecK,P]=FeUncSwit(y,ym,x,do,bn,P)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%k=P.ExOpt.FeatK;
switch P.FEOpt4
    case 0
        k='40x1Fbank';
    case 1
        k='40x11Fbank';
    case 2
        k='40x1Fmllr';
    case 3
        k='40x11Fmllr';        
end

switch P.FEOpt1          
    case -1 %
        RecK{1}='Spn';
        HmmDir=[P.ResRoot '/FE_0_0_0_0/HMM_0_0/Spn/FinalSpn'];                 
     case 0 %Gmm
        RecK{1}='Gmm'; 
        HmmDir=[P.HmmDir '/FinalSpn' k];         
     case 1 %Spn
        RecK{1}='Spn';  
        HmmDir=[P.HmmDir '/FinalSpn' k];            
     case 2 %Dnn
        RecK{1}='Dnn'; 
        HmmDir=[P.HmmDir '/FinalDnn' k];                
end


switch P.FEOpt2
    case -1
        RecK{2}='Sta';
        Y=SignalToFeature(x,HmmDir,do,bn,k,P);
        U=-1;
    case 0
        RecK{2}='Sta';
        Y=SignalToFeature(y,HmmDir,do,bn,k,P);
        U=-1;
    case 1
        RecK{2}='Un';
        xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
        Y=SignalToFeature(xest,HmmDir,do,bn,k,P);
        U=zeros(size(Y));
    case 2
        RecK{2}='Un';
        xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
        X=SignalToFeature(x,HmmDir,do,bn,k,P);
        Y=SignalToFeature(xest,HmmDir,do,bn,k,P);
        U=(Y-X).^2;     
        
    case 3
        RecK{2}='Un';
        xest=SignEnh(ym,-1,P.FSamp,'Chi4Arie',P,bn);
        Y=SignalToFeature(xest,HmmDir,do,bn,k,P);
        U=zeros(size(Y));   
        
      
   case 4
        RecK{2}='En';
        xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
        X=SignalToFeature(x,HmmDir,do,bn,k,P);
        Y=SignalToFeature(xest,HmmDir,do,bn,k,P);
        P.TmpX=X;
        U=(Y-X).^2;             
        
                

        
%      case 4
%         RecK{2}='MD';
%         X=SignalToFeature(x,HmmDir,do,bn,k,P);
%         Y=SignalToFeature(y,HmmDir,do,bn,k,P);
%         P.MF=min(X(:))
%         pause
%         U=YXHardMask(exp(Y),exp(X),3,exp(P.MF));            
        
end

% 
%  subplot(211), jimagesc(Y)
%  subplot(212), jimagesc(U)
%  pause



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Fbx=SignalToFeature(x,HmmDir,do,bn,k,P)
%

%HmmDir=[P.ExpHmmDir '/Spn/FinalSpn'];

fprintf('SignalToFeature: %s\n',k)

switch k
    
    case '40x1Fbank'  
        Fbx=Sign2Feat(x,P);
        Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1);
        
    case '40x11Fbank'    
        Fbx=Sign2Feat(x,P); Fbx=AppContext(Fbx,5);
        Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1);
    
          
    case '40x1Fmllr'                
        Cx=Sign2Feat(x,P,'Mfcc');
        Fbx=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
        Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1);
        
    case '40x11Fmllr'
        Cx=Sign2Feat(x,P,'Mfcc');
        Fbx=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
        Fbx=AppContext(Fbx,5);
        Fbx=NormFeUn(Fbx,[HmmDir '/GPar'],'feat','GMvn',-1);  
        
end











%         
%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
%     
%     case 0
%         HmmDir=[P.HmmDir '/FinalDnn40x11Fbank'];       
%         P.NCH=40;
%         
%         switch P.FEOpt2
%             case -1
%                 RecK='Dnn';
%                 Y=Sign2Feat(x,P);
%                 U=-1;
%             case 0
%                 RecK='Dnn';
%                 Y=Sign2Feat(y,P);
%                 U=-1;
%             case 1
%                 RecK='Dnn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Y=Sign2Feat(xest,P);
%                 U=-1;
%             case 2
%                 RecK='En_OU2';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Y=Sign2Feat(xest,P);
%                 X=Sign2Feat(x,P);
%                 U=(Y-X).^2;
%         end
%         %Add Context
%         P.Tmp.Y=Y; P.Tmp.U=U;
%         config=ReKaldFeatTr([HmmDir '/final.feature_transform']); % Path to config file         
%         Y=nnet_applyContext(Y,config,'feat');       
%         U=nnet_applyContext(U,config,'unc');       
%         
%        
%         
% 
%      case 1 %
%         HmmDir=[P.HmmDir '/FinalSpn1985Pdfs40x11Fmllr1250PD']; 
%         P.NCH=40;        
%         switch P.FEOpt2       
%             case -1
%                 RecK='Spn';
%                 C=Sign2Feat(x,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); Y=AppContext(Y,5);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                  
%                 U=-1;        
%             case 0
%                 RecK='Spn';
%                 C=Sign2Feat(y,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); Y=AppContext(Y,5);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                 
%                 U=-1;      
%             case 1
%                 RecK='UnSpn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 C=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); Y=AppContext(Y,5);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1); 
%                 U=zeros(size(Y));  
%              case 2
%                 RecK='UnSpn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Cx=Sign2Feat(x,P,'Mfcc');  X=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P); X=AppContext(X,5);  
%                 X=NormFeUn(X,[HmmDir '/GPar'],'feat','GMvn',-1);               
%                 C=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); Y=AppContext(Y,5);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                
%                 U=(Y-X).^2;                      
%         end
%         
%       case 2 %
%         HmmDir=[P.HmmDir '/FinalDnn40x1Fmllr'];
%         P.NCH=40;        
%         switch P.FEOpt2            
%             case -1
%                 RecK='Dnn';
%                 C=Sign2Feat(x,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                 
%                 U=-1;                     
%             case 0
%                 RecK='Dnn';
%                 C=Sign2Feat(y,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P);
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                 
%                 U=-1;      
%             case 1
%                 RecK='Dnn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 C=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); 
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);
%                 U=zeros(size(Y));  
%              case 2
%                 RecK='En_OU2';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Cx=Sign2Feat(x,P,'Mfcc');  X=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P); 
%                 X=NormFeUn(X,[HmmDir '/GPar'],'feat','GMvn',-1);                
%                 C=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(C,'Fmllr',HmmDir,do,bn,P); 
%                 Y=NormFeUn(Y,[HmmDir '/GPar'],'feat','GMvn',-1);                
%                 U=(Y-X).^2;                 
%         end
%         
%         %Add Context
%         P.Tmp.Y=Y; P.Tmp.U=U;
%         config=ReKaldFeatTr([HmmDir '/final.feature_transform']); % Path to config file         
%         Y=nnet_applyContext(Y,config,'feat');       
%         U=nnet_applyContext(U,config,'unc');
%         
%         
% end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     case 1 %
%         HmmDir=[P.HmmDir '/FinalSpn40x1Fmllr10000PDx10EM'];
%         P.NCH=40;
%
%         switch P.FEOpt2
%             case -1
%                 RecK='Spn';
%                 Cx=Sign2Feat(x,P,'Mfcc');  Y=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%                 X=-1;    U=zeros(size(Y));
%             case 0
%                 RecK='Spn';
%                 Cx=Sign2Feat(y,P,'Mfcc');  Y=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%                 X=-1;    U=zeros(size(Y));
%             case 1
%                 RecK='UnSpn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Cx=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%                 X=-1;    U=zeros(size(Y));    P.Tmp.Y=Y; P.Tmp.X=X;
%             case 2
%                 RecK='UnSpn';
%                 xest=SignEnh(ym,-1,P.FSamp,'Chi3Or',P,bn);
%                 Cx=Sign2Feat(xest,P,'Mfcc');  Y=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%                 Cx=Sign2Feat(x,P,'Mfcc');     X=Juan2KaldFeat(Cx,'Fmllr',HmmDir,do,bn,P);
%                 U=(Y-X).^2;   P.Tmp.Y=Y; P.Tmp.X=X;
%
%         end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
