function [StSamp,NZSt,NZP]=DrawSampPdf(OP,N)
%Draw Samp from discrite univariate Pdf




%Peak Posterior (make 0 values <max_frame*0.1, a magnitude order)
[P,NZSt,NZP]=PeakPost(OP);
[nst,nf]=size(P);
StSamp=zeros(N,nf);
SampPost=zeros(N,nf);

%Select samples
for f=1:nf
    pdf=P(:,f);        
    st=discretesample(pdf,N);   
    pst=pdf(st);    
    StSamp(:,f)=st;      
    SampPost(:,f)=pst;   
    
    %Check that st and pst are in NZSt,NZP 
    
    
end

% subplot(211), plot(StSamp')
% subplot(212), plot(SampPost');
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [PP,NZSt,NZP]=PeakPost(P)
%
[NSt, nf]=size(P);
PP=P;
NZSt=cell(1,nf);
NZP=cell(1,nf);
for i=1:nf
    [PP(:,i),th,nzp,nzv]=PeakSel(P(:,i));        
     NZSt{i}=nzp;
     NZP{i}=nzv;      

end

% nz=sum(PP~=0);
% subplot(311), jimagesc(log(P))
% subplot(312), jimagesc(log(PP))
% subplot(313), plot(nz)
% sum(PP)
% pause


function [pp,th,nzp,nzv]=PeakSel(p)
%

%th=max(p)*0.25;
th=max(p)*0.1;
pp=p; i=pp<th;  pp(i)=0;
pp=pp/sum(pp);
%non zero postions and value
a=1:length(p);
nzp=a(not(i)); 
nzv=pp(nzp)';


