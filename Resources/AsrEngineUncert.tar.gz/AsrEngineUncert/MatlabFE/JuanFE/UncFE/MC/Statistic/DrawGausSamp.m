function [X,LPr]=DrawGausSamp(M,V)
%
[FL,nf]=size(M);
X=zeros(FL,nf);

for f=1:nf
    a=mvnrnd(M(:,f)',V(:,f)');
    X(:,f)=a';
end

LPr=LogMvnPdf(X,M,V);