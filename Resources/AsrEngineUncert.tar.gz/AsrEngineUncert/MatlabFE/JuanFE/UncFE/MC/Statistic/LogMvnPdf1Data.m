function LPr=LogMvnPdf1Data(x,M,V)
%Equivalent to LPr=log(mvnpdf(x',M(:,i)',V(:,i)'))   
%x: data, a column vector
%M: Mean Matrix (each column same dim as x)
%V: Variances Matrix 

k=length(x);

a1=k*log(2*pi);

a2=sum(log(V));
M2=(VPlusM(-x,M)).^2;
a3=sum(M2./V);


LPr=-0.5*(a1+a2+a3);
 
 
 

