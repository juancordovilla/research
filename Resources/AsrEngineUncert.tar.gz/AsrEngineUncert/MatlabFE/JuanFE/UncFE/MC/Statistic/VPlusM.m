function M2=VPlusM(V,M)
%Vector Plus Matrix (it respects order, to do difference)
%V is column vector
nf=size(M,2);
M2=repmat(V,[1,nf])+M;


