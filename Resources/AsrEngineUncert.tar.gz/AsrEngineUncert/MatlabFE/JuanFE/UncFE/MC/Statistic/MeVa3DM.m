function [M,V]=MeVa3DM(X3D,w)
%Average Matrixes Cell using weights
%w have to sum 1
%X3D: are posteriors


%
[NSamp,FL,nf]=size(X3D);



switch nargin 
        
    case 2
        sw=sum(w);
        w=w*(NSamp/sw);        
        if (sw>1+eps||sw<1-eps);      fprintf('WARNING in MeVa3DM: w changed to sum 1\n');     end
        
        for i=1:NSamp; X3D(i,:,:)=w(i)*X3D(i,:,:); end      
        
        
end
        
M=squeeze(mean(X3D,1));        
V=squeeze(var(X3D,1));
              


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






