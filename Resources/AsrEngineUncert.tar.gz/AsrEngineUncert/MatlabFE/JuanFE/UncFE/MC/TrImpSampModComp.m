function [M,V]=TrImpSampModComp(PS,FW,VW)
%Training Importance Sampling Model Computation

[FL,NS]=size(FW);
FL2=FL; %'diag'
%FL2=FL*FL; 'full'


%Mean
D=repmat(PS,FL,1);
M=FW./D;

%Covariance
D=repmat(PS,FL2,1);
M2=M.^2; %diag
%M2=? %full
V=(VW./D)-M2;