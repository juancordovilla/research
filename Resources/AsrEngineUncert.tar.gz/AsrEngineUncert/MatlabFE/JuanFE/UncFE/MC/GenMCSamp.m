function [X3D,w]=GenMCSamp(Y,U,WK,P)
%Generate MC (or En or MD or IS) Samples and corresponding weights (w)
%Y,U: featuregram and Uncertintygram
%WK: Weighting Kind
%P: Parameter structure

switch WK
    case {'En', 'MC', 'MD'}       
        [X3D,w]=EnMCMDSamp(Y,U,WK,P);        
        
       
    case 'IS'
        [X3D,w]=MCImpSamp(Y,U,P);
        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






