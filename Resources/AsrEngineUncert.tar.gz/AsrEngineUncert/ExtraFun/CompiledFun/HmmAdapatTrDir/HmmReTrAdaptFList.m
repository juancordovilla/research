function HmmReTrAdaptFList(DirO, DirI, FList, P)
%Hmm Re-Training Adaptation from a File List


NI=4;
P.PDir = [DirO '/PHmm'];
P.CDir = [DirO '/CHmm'];
P.FList=FList;


%
[x,x,x]=rmdir(DirO,'s'); mkdir(DirO); mkdir(P.PDir); mkdir(P.CDir); 


%
s=['cp ' DirI '/* ' P.PDir]; system(s);

fi=fopen(P.FList,'r'); C=textscan(fi,'%s'); fclose(fi); C=C{:};
fprintf('Selected List for HmmReTrAdaptFList:\n');
fprintf('%s\n',C{:});



%
for i=1:NI        
    IterGauss(P);   
    fprintf('Done IterGauss %d/%d\n',i,NI);
end




%
s=['cp ' P.PDir '/* ' DirO]; system(s);
s=['cp ' P.WList  ' ' DirO]; system(s); 
[x,x,x]=rmdir(P.PDir,'s');
[x,x,x]=rmdir(P.CDir,'s');
fprintf('Hmm adaptation in: %s\n',DirO);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function UpModel(P)
%
s=['rm ' P.PDir '/*; cp ' P.CDir '/* ' P.PDir '; rm ' P.CDir '/*'];
system(s);

function IterGauss(P)
%
s=[P.HtkRoot '/HERest -C ' P.Config ' -I ' P.MlfWTrans ' -T 0 -S ' P.FList ' -H ' P.PDir '/macros -H ' ...
    P.PDir '/' P.HmmName ' -M ' P.CDir ' ' P.WList ';'];
system(s);

UpModel(P);
