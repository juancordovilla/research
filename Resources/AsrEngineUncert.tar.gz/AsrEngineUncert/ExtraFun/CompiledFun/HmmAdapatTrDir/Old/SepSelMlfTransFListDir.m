function SepSelMlfTransFListDir(ORoot,OFList,OMlfWTrans,IDir,ISelTokF,FExt,Sep)
% Separate files of a folder depending on the Room (read from Info.txt)
% Select depending on tokens
% Mlf transcription
% FList
% 
% ORoot= '/clusterFS/home/user/jamc/RESULTS/FEDirha0000/FEAT/Adapt';
% OFList='/clusterFS/home/user/jamc/SPEECHDATA/Models/HMMs/HMMFBKGEDIRHACepAllBASNoisyFEDirha020x/TempTrList.txt.List1';
% OMlfWTrans='/clusterFS/home/user/jamc/SPEECHDATA/Models/HMMs/HMMFBKGEDIRHACepAllBASNoisyFEDirha020x/TempTrList.txt.Trans1';
% IDir='/clusterFS/home/user/jamc/RESULTS/FEDirha0000/FEAT/TrainBASNoisy/Dev1S1';
% ISelTokF='/clusterFS/home/user/jamc/SPEECHDATA/Models/HMMs/HMMFBKGEDIRHACepAllBASNoisyFEDirha020x/TempTrList.txt.Tok';
% FExt= '.Cxest'; 
% Sep='1';
% 
% addpath('/clusterFS/home/user/jamc/AsrEngine/FEMatlab/FEJuan/Common/ReWr')
% addpath('/clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/RECSTAGES/ExtraFun/Transcribe/Fun')

%
HRoom={'K' 'L' 'R' 'C' 'B'}; Sep=str2double(Sep);

%
[Afo,BN,WTrans]=Separate1Dir(ORoot,IDir,FExt,HRoom,Sep); 



%
[BN,WTrans,t]=SelBN(BN,WTrans,ISelTokF); Afo=Afo(t);


%
BNTranDic2Mlf(OMlfWTrans,BN,WTrans);

%
delete(OFList); fid=fopen(OFList,'w');
fprintf(fid,'%s\n',Afo{:});
fclose(fid); fprintf('Written %s\n',OFList);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Afo,BNO,WTransO]=Separate1Dir(ORoot,IDir,FExt,HRoom,Sep)
%
S=ReInfoDir(IDir,FExt);
BN=S.BN; WTrans=S.WTrans; Room=S.Room;
if Sep
    k=1;
    for a=HRoom
      ODir=[ORoot '/' a{:}];
      if ~exist(ODir,'dir'); mkdir(ODir); end
      t=strcmp(a,Room);
      RBN=BN(t); RWTrans=WTrans(t);  
      for j=1:length(RBN)
        fi=[IDir '/' RBN{j} FExt];
        fo=[ODir '/' RBN{j} FExt];          
        Afo{k}=fo; BNO{k}=RBN{j}; WTransO{k}=RWTrans{j};    k=k+1;
        copyfile(fi,fo);    
      end 
    end
    fprintf('Room-splitted %s in %s\n',IDir,ORoot); 
else
    BNO=BN; WTransO=WTrans;
    for i=1:length(BN); Afo{i}=[IDir '/' BN{i} FExt]; end    
end

function [BN,WTrans,t]=SelBN(BNI,WTransI,SelTokF)
%

fi=fopen(SelTokF,'r');
TokC=textscan(fi,'%s'); TokC=TokC{:};
fclose(fi);
if ~isempty(TokC)
    l=length(BNI); TokN=length(TokC);
    t=false(l,1);
    for i=1:l
        t(i)=0;
        for j=1:TokN
            t(i)=t(i)|~isempty(strfind(BNI{i},TokC{j}));
        end
    end    
    BN=BNI(t); WTrans=WTransI(t);
else    
    BN=BNI; WTrans=WTransI; t=true(1,length(BN));
end




