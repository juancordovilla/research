function S=ReInfoDir(IDir,FExt)
%




IExt='.txt';


fy=dir([IDir '/*' FExt]); l=size(fy,1);
for i=1:l
  [pn, BN{i}]=fileparts(fy(i).name);
  [WTrans{i},Room{i}]=ReInfo([IDir '/' BN{i} IExt]);  
end

S.BN=BN;
S.WTrans=WTrans;
S.Room=Room;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [WTrans,Room]=ReInfo(IF)
%
P=ReStr(IF);
if (isfield(P,'WTrans'))
    WTrans=P.WTrans;
    Room=P.Room;
else
    WTrans='xx';
    fprintf('WARNING: fake trans %s for %s\n',WTrans,IF);
end
