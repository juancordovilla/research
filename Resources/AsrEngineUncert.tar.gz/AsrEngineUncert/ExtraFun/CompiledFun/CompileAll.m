function CompileAll
%

%mcc -m ./AnalResDir/AnalRes.m


mcc -m ./HmmAdapatTrDir/HmmAdapatTr.m 

%mcc -m ./TrTeFunDir/HmmAdapatTr.m ...
%-I /clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/RECSTAGES/CompiledFun/TrTeFunDir;


% mcc -m ./MyHResultsDir/MyHResults.m
% mcc -m ./MyHResultsDir/MyHResultsKWS.m
% mcc -m ./Ctk2MlfDir/Ctk2Mlf.m

% mcc -m ./FList2CtkWTransDir/FList2CtkWTrans.m;
% mcc -m ./MyHViteDir/MyHVite.m
% mcc -m ./TestFunDir/ListSel.m

% mcc -m ./TrTeFunDir/SepSelMlfTransFListDir.m ...
% -I /clusterFS/home/user/jamc/AsrEngine/FEMatlab/FEJuan/Common/ReWr ...
% -I /clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/RECSTAGES/ExtraFun/Transcribe/Fun;



delete('run_*', 'mccExcludedFiles.log', 'readme.txt') 
