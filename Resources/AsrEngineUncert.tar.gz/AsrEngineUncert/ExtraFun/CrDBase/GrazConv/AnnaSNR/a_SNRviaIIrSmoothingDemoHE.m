%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   First-Order IIR Smoothing [1] 
%   07.06.2013
%   @ Anna Fuchs
%   
%   [1]Acoustic Echo and Noise Control A practical Approach; Eberhard
%   Haensler, Gerhard Schmidt; S.319; 13.4.4.4 First-Order IIR Smoothing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all;

setup.cur_dir = 'HE02M';
[sig,setup.Fsnew] = wavread('HE02Msen0025.wav');         

setup.Fsnew

snr = af_SNRiirSmoothing_(sig,setup.cur_dir,setup,1,'xx',setup.cur_dir);
snr


