function FbkGeDirha1
%

%Path

AsrRoot     = '/clusterFS/home/user/jamc/AsrEngine';
TransRoot   = [AsrRoot '/ExtraFun/Transcription'];


addpath([TransRoot '/Fun']); %for UtBNameOrtTDic
addpath([TransRoot '/WPhDic/Dic']); %for Raw2AdapOrt
addpath([AsrRoot '/ExtraFun/CrDBase/CommonFun']); %
addpath([AsrRoot '/ExtraFun/CrDBase/CommonFun/Fbk2TUGraz']); %


%addpath([RecRoot '/ExtraFun/CrDBase/FbkGeDirha/Fun']); %for Fbk2TUGrazDIRHAII
%addpath('/clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/ParSeqExe') %for ParSeqMatExe

ParalDir='/clusterFS/home/user/jamc/Results/LogMatParalDir'; [x,x,x]=rmdir(ParalDir,'s'); mkdir(ParalDir);


%In
AudIRoot='/clusterFS/project/DIRHA/ExpMatrix/DIRHAIIOut';
InfIRoot='/afs/spsc.tugraz.at/resources/databases/INCOMING/DIRHA_FBK_sim/DIRHA_sim2_v3/GE';

Sim={'sim1' 'sim2' 'sim3' 'sim4' 'sim5' 'sim6' 'sim7' 'sim8' 'sim9' 'sim10' 'sim11' 'sim12' 'sim13' 'sim14' 'sim15' ...
    'sim16' 'sim17' 'sim18' 'sim19' 'sim20' 'sim21' 'sim22' 'sim23' 'sim24' 'sim25' 'sim26' 'sim27' 'sim28' 'sim29' ...
    'sim30' 'sim31' 'sim32' 'sim33' 'sim34' 'sim35' 'sim36' 'sim37' 'sim38' 'sim39' 'sim40' 'sim41' 'sim42' 'sim43' ...
    'sim44' 'sim45' 'sim46' 'sim47' 'sim48' 'sim49' 'sim50' 'sim51' 'sim52' 'sim53' 'sim54' 'sim55' 'sim56' 'sim57' ...
    'sim58' 'sim59' 'sim60' 'sim61' 'sim62' 'sim63' 'sim64' 'sim65' 'sim66' 'sim67' 'sim68' 'sim69' 'sim70' 'sim71' ...
    'sim72' 'sim73' 'sim74' 'sim75'};


StBNOrtTDic=[TransRoot '/Trans/FBKGEDIRHA/StBNOrtTDic.txt'];
SDBase='FBKGEDIRHA';


%Out
P.OFSamp=16000; P.IFSamp=48000; P.MicN=40;
ORoot='/clusterFS/home/user/jamc/SpeechData/FBKGEDIRHA_All/Aux'; %If I modify only 
%The Info I can do directly without Aux because the .wav are not deleted Basename Ortographic Dictionary
%BNOrtD=UtBNameOrtTDic(StBNOrtTDic); 
%BNOrtD=Raw2AdapOrt(BNOrtD,SDBase,TransRoot); 
%save('./WorkSpace','BNOrtD');
load('./WorkSpace');
BNOrtD{2}=Ex2SiAsciiC(BNOrtD{2}); %Convert to simple ascii for comparison


%
WrDO(ORoot,'dev1',InfIRoot,AudIRoot,Sim,BNOrtD,TransRoot,P,ParalDir);
WrDO(ORoot,'test1',InfIRoot,AudIRoot,Sim,BNOrtD,TransRoot,P,ParalDir);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function WrDO(ORoot,SetK,InfIRoot1,AudIRoot1,Sim,BNOrtD,TransRoot,P,ParalDir)
%
JobList=[ParalDir '/JobList.txt'];
fi=fopen(JobList,'w');

for i=1:length(Sim)    
    
    P.DO=[ORoot '/' upper(SetK(1)) SetK(2:end) '/' 'S' num2str(ceil(i/15))];
    P.SetK=SetK;
    P.InfIRoot1=InfIRoot1;
    P.AudIRoot1=AudIRoot1;
    P.Sim=Sim{i};
    P.BNOrtD=BNOrtD;
    P.TransRoot=TransRoot;
    
    MatP=[ParalDir '/P' num2str(i) '.mat'];   save(MatP,'P');
    
    Fbk2TUGrazDIRHAII1Dir(MatP);    
    C=['/clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/RECSTAGES/ExtraFun/CrDBase/FbkGeDirha/Fun/' 'Fbk2TUGrazDIRHAII1Dir(''' MatP  ''')'];      
    fprintf(fi,'%s %s %s %s %s\n','J','1','-1','-1',C);  
    
end
fclose(fi);
%ParSeqMatExe(JobList,ParalDir,'p');





