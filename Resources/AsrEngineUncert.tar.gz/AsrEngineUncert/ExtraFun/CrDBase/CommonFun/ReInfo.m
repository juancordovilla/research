function S=ReInfo(dy,bn,lx)
%Read Info
infof=[dy '/' bn '.txt'];
if(exist(infof,'file'))
    fi=fopen(infof,'r');
    C = textscan(fi,'%s \t %s \t %s \t  %s \n');
    fclose(fi);
    l=length(C{1});    
    for i=1:l        
        S(i).st=C{1}{i}; 
        S(i).en=C{2}{i}; 
        S(i).pos=C{3}{i}; 
        a=C{4}(i); 
        [pn, S(i).bn] = fileparts(a{:});   
        %S(i).WTrans=GetTrans(S(i).bn,P.BNTransDic);
        S(i).WTrans='xx';
        
    end     
else
    fprintf('WARNING in ReNormYX: Invented %s\n',infof);
    S(1).st='1'; S(1).en=num2str(lx); S(1).pos='-1'; S(1).bn=bn; S(1).WTrans='-1';
end

