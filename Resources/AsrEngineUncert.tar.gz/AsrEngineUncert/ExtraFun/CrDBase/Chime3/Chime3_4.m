function Chime3_4
%Unsplit Dev (and Tr) in big folder



%IRoot
IRoot='/home/jamc/SpeechData/CHIME3_All/DevSpl';
Fo={'dt05_bus_simu' 'dt05_caf_simu'  'dt05_ped_simu'  'dt05_str_simu'};

%IRoot='/home/jamc/SpeechData/CHIME3_All/TeSpl';
%Fo={'et05_bus_simu' 'et05_caf_simu'  'et05_ped_simu'  'et05_str_simu'};


%
NSplDir=82;

%
ORoot=[IRoot '/Aux']; [x,x,x]=mkdir(ORoot);


for i=1:length(Fo)    
    %Noisy
    BN=Fo{i};
    IDirY=[IRoot '/' BN];   
    ODirY=[ORoot '/' BN];    
    UnSplitDir(ODirY,IDirY,NSplDir,'','.wav');    
    UnSplitDir(ODirY,IDirY,NSplDir,'_noise','.wav');   

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function UnSplitDir(OODir,IIDir,NSplDir,Suf,Ext)
%Split Directory
%NSplDir: Number of Spl Dir per Directory
ODir=[OODir Suf];
 [x,x,x]=mkdir(ODir);
for i=1:NSplDir    
    IDir=[IIDir '_' num2str(i) Suf];
    system(['cp ' IDir '/*' Ext ' ' ODir]);    
end
fprintf('Written: %s\n', ODir);








