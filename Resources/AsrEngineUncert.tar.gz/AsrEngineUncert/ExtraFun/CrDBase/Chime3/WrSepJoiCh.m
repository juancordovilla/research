function [M,Fs]=WrSepJoiCh(ODir,IDir,bn,k,P)
%Write Join or Separate several Channels


switch k
    case 'j' %Join (if ch0 doent exist, make 0)
        
        [y1,Fs]=audioread([IDir '/' bn '.CH1' P.Ext]);
        [y2,Fs]=audioread([IDir '/' bn '.CH2' P.Ext]);
        [y3,Fs]=audioread([IDir '/' bn '.CH3' P.Ext]);
        [y4,Fs]=audioread([IDir '/' bn '.CH4' P.Ext]);
        [y5,Fs]=audioread([IDir '/' bn '.CH5' P.Ext]);
        [y6,Fs]=audioread([IDir '/' bn '.CH6' P.Ext]);
        ns=length(y1);
        f=[IDir '/' bn '.CH0' P.Ext];
        if exist(f,'file')
            [y0,Fs]=audioread(f);
        else
            y0=zeros(ns,1); 
        end
        M=[y0 y1 y2 y3 y4 y5 y6];


        fno=[ODir '/' bn '.wav'];
        audiowrite(fno,M,Fs);
        fprintf('Written %s\n',fno); 

    case 's' %Separate
        
        for ch=0:6
            fni=[IDir '/' bn '.CH' num2str(ch) P.Ext];
            fno=[ODir '/' bn '.CH' num2str(ch) P.Ext];            
            if exist(fni,'file'); copyfile(fni,fno); end  
        
        end    
        
        
end