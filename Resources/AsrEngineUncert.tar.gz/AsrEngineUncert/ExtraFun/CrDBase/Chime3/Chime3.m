function Chime3
%Generate Tr and Dev sets by
%Join in one .wav file multiples channels (.ch0 .ch1 etc.) files

%
AsrRoot     = '/home/jmorales/AsrEngine';
addpath([AsrRoot '/ExtraFun/CrDBase/CommonFun']); %
addpath([AsrRoot '/ExtraFun/CrDBase/CommonFun/Fbk2TUGraz']); %


%IRoot
% Fo={'tr05_bth'       'tr05_bus_simu'  'tr05_caf_simu'  'tr05_ped_real'  'tr05_str_real' ...
%   'tr05_bus_real'  'tr05_caf_real'  'tr05_org'       'tr05_ped_simu'  'tr05_str_simu'};

%Fo={'et05_bth'  'et05_bus_real'  'et05_bus_simu'  'et05_caf_real'  'et05_caf_simu'  ...
%    'et05_ped_real'  'et05_ped_simu'  'et05_str_real'  'et05_str_simu'};

Fo={'embedded'};


IRoot='/local/parole3/source_separation/CHiME3/data/audio/16kHz';
P.Ext='.wav';

%ORoot
ORoot=['/home/jmorales/SpeechData/CHIME3_All/Emb/Aux']; 
mkdir(ORoot);


%
l=length(Fo);
for i=1:l
    %To paralize (qsub)
    IDir=[IRoot '/' Fo{i}];
    ODir=[ORoot '/' Fo{i}];
    
    
    JoinWav(ODir,IDir,P);
    
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function JoinWav(ODir,IDir,P)
%

fy=dir([IDir '/*.CH1' P.Ext]); 
lo=size(fy,1); 
[x,x,x]=mkdir(ODir);

%rp=randperm(lo); l=410; %case chose 410 randonly
rp=1:lo; l=lo; %normal case

for j=1:l
    
    i=rp(j);
    fprintf('%d/%d ',j,l);
    [pn, bn]=fileparts(fy(i).name);
    [pn, bn]=fileparts(bn);
    [M,Fs]=WrSepJoiCh(ODir,IDir,bn,'j',P);         
           
end
fprintf('Written: %s\n',ODir);












