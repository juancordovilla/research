function [S]=FindBackEmbBth1F(JSonS,bn,EmbK,EmbRoot,BackRoot,BthDir)
%Find Back Emb Bth of 1 File

l=length(JSonS);



for i=1:l
    f=JSonS{i};
    
    fbn=[f.speaker '_' f.wsj_name '_' f.environment];
    
    
    if strcmp(bn,fbn)
        
        [S]=ReEmb(f,bn,EmbK,EmbRoot,BackRoot,BthDir);
        
        %         nfbn=f.noise_wavfile;
        %         s=f.noise_start;
        %         e=f.noise_end;
        %         C=strsplit(nfbn,'_'); ndir=lower(C{end});
        %         backf=[P.BackRoot '/' ndir '/' nfbn '.wav'];
        %         embf=[P.EmbRoot '/' ndir '/' nfbn '.wav'];
        %         devbthf=[P.DevBthDir '/' f.speaker '_' f.wsj_name '_BTH' '.wav'];
        
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [S]=ReEmb(f,bn,k,EmbRoot,BackRoot,BthDir)
%

%Obtain embf
switch k
    
    case 'w' %wav
        nfbn=f.wavfile;  C=strsplit(nfbn,'_'); ndir=lower(C{end});        
        %S.embf=[EmbRoot '/' ndir '/' f.wavfile '.wav'];
        S.embf=[EmbRoot '/' f.wavfile '.wav'];
        S.s=f.start;
        S.e=f.end;
        
        
    case 'b' %background
        nfbn=f.noise_wavfile;  C=strsplit(nfbn,'_'); ndir=lower(C{end});
        S.backf=[BackRoot '/' ndir '/' nfbn '.wav'];
        S.s=f.noise_start;
        S.e=f.noise_end;
        
    case 'e' %embedded
        nfbn=f.noise_wavfile;  C=strsplit(nfbn,'_'); ndir=lower(C{end});        
        %S.embf=[EmbRoot '/' ndir '/' nfbn '.wav'];
        S.embf=[EmbRoot '/' nfbn '.wav'];
        
        S.s=f.noise_start;
        S.e=f.noise_end; 
        
end

S.dot=f.dot;
S.bnf=[f.speaker '_' f.wsj_name '_' f.environment];  %Basename: bth (dev) or wjs0 (tr) file
S.bthf=[BthDir '/' f.speaker '_' f.wsj_name '_BTH' '.wav'];




    
    