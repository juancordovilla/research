function n=Chime3Info2TrueNoise(S)
%

[bth,Fs]=audioread(S.bthf);

[emb,Fs]=ReLoFCoLe(S.embf,S.s,S.e); 



[n,ysimu]=GetDevNoise(bth(:,1),emb(:,1),emb(:,2:end),Fs);


% subplot(311), plot(bth)
% subplot(312), plot(emb)
% subplot(313), plot(n)
% pause




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [n,Fs]=ReLoFCoLe(backf,s,e)
%Read Long File and Compare with Lenght
%
%New Fast
info = audioinfo(backf); Fs=info.SampleRate;
ss=round(s*Fs); es=round(e*Fs);
[n,Fs]=audioread(backf,[ss+1,es+0]); %step very slow if not selected interval in advance
