function JSonS=LoSaMatJSon(JSonF,JSonMat)
%Load or Save (if not exist) Mat JSon
%Read and Load in .mat (for faster futures askings) InfoJSon


if ~exist(JSonMat,'file')
    
    fprintf('Creating JSonMat %s\n....',JSonMat)
    JSonF
    fi=fopen(JSonF,'r');
    
    raw=fread(fi,inf); 
    str=char(raw'); data=JSON.parse(str); %Replace JSON by the provided in CHiME3 utils
    fclose(fi);
    save(JSonMat,'data');
end
    
S=load(JSonMat); JSonS=S.data;

