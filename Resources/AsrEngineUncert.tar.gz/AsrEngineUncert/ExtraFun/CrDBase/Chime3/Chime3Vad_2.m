function Chime3Vad_2
%Create Info for embbed
%STOPPED WORK because
%Consider that embbed files have utterances not annotatated
%(repetaions from speaker readding mistakes)
%
%The file with usefull information about embed are:
% 'dt05_bth.json'  embed of type: in wavfile: 'M04_141107_010_BTH'
% 'tr05_bth.json'  embed of type: in wavfile: 'M02_141128_010_BTH'
% 'dt05_real.json' embed of type: in wavfile: 'M04_141107_040_BUS'
% 'tr05_real.json' embed of type: in wavfile: 'F02_141106_050_PED'
% 'dt05_simu.json' embed of type: in noise_wavfile: 'M04_141107_040_BUS'
% 'tr05_simu.json' embed of type: in noise_wavfile: 'BGD_150205_030_PED'
% 
%(not read 'tr05_org.json' because not embed)
%(not read 'tr05_simu.json' because it doesnt have information on embbed)


%
addpath('./utils'); %
addpath('./Fun'); %
addpath('../../../MatlabFE/JuanFE/Common/Matlab');


%IRoot  
CHI3Root='/home/jmorales/SpeechData/CHIME3_All';


ajson={'dt05_bth.json'  'et05_bth.json'  'tr05_bth.json' ...
       'dt05_real.json' 'et05_real.json' 'tr05_real.json' ...
       'dt05_simu.json' 'et05_simu.json'};
   
k    ={'w'              'w'             'w' ...
       'w'              'w'             'w' ...    
       'e'             'e'}; 
   
   
AnDir=[CHI3Root '/CHiME3/data/annotations']; %Annotation Dir
Fs=16000;
%
P.BackRoot  =[CHI3Root '/Back'];
P.EmbRoot   =[CHI3Root '/Emb'];
P.DevBthDir =[CHI3Root '/Dev/dt05_bth'];
P.Ext='.wav';

%ORoot
ORoot=[P.EmbRoot '/Aux']; mkdir(ORoot);

%Read All JSon 
AS=ReAllJSon(ajson,k,AnDir,P,'./Tmp');


%Unique embf
aembf=StArFNExtract(AS,'embf'); 
uembf=unique(aembf);
for i=1:length(uembf)
    
   % 
   j=strcmp(aembf,uembf{i});   
   SS=AS(j); %Selected Structure   
   s=StArFNExtract(SS,'s');
   e=StArFNExtract(SS,'e');    
   bnf=StArFNExtract(SS,'bnf');
   dot=StArFNExtract(SS,'dot');
   
   %  
   ss=round(s*Fs)+1; %formula of Chim3_2
   es=round(e*Fs); 

   
   
   embf=SS(1).embf; %take the first cause the others are the same 
   
   [p1 b1]=fileparts(embf); [p2 b2]=fileparts(p1);   
   %ODir=[ORoot '/' b2]; 
   ODir=[ORoot]; 
   [x,x,x]=mkdir(ODir);   
   info=[ODir '/' b1 '.txt'];
   InfoWr(info,ss,es,bnf,dot); 

end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



