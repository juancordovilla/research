function Chime3_Vad4
%Create Vad Tr, Dev and Test from Emb

addpath('../../../MatlabFE/JuanFE/Common/Matlab');


%
EmbRoot='/home/jmorales/SpeechData/CHIME3_All/Emb';
Fo={'BUS' 'CAF' 'PED' 'STR'};

%
ORoot=[EmbRoot '/Aux']; [x,x,x]=mkdir(ORoot);


% %
% l=length(Fo);
% for i=1:l
%     [TrL,DeL,TeL]=TrDeTeList(EmbRoot,Fo{i});    
%     CopyTrDeTeList(ORoot,Fo{i},TrL,DeL,TeL,0.3);
% end


ReInfoDir([ORoot '/Tr/Noisy/BUS'],'wav'); %Just to check Info





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function S=ReInfoDir(IDir,FExt)
%
IExt='.txt';
fy=dir([IDir '/*' FExt]); l=size(fy,1);
for i=1:l
  [pn, BN{i}]=fileparts(fy(i).name);
  [S]=ReEmbInfo([IDir '/' BN{i} IExt]);
  
  
  S, pause
end



function CopyTrDeTeList(ORoot,Fo,TrL,DeL,TeL,Prop)
%
CopyList([ORoot '/Tr/Noisy/' Fo],TrL,Prop);
CopyList([ORoot '/De/Noisy/' Fo],DeL,Prop);
CopyList([ORoot '/Te/Noisy/' Fo],TeL,Prop);

function CopyList(ODir,List,Prop)
%
l=length(List); l=round(l*Prop);


[x,x,x]=mkdir(ODir);

for i=1:l    
    [pn, bn]=fileparts(List{i});
    fi=[pn '/' bn '.wav'];
    fitxt=[pn '/' bn '.txt'];    
    fo=[ODir '/' bn '.wav'];
    fotxt=[ODir '/' bn '.txt'];    
    copyfile(fi,fo);
    copyfile(fitxt,fotxt);      
    
    fprintf('Written: %s\n',fo);

end






function [TrL,DeL,TeL]=TrDeTeList(EmbRoot,Fo)
%
fy=dir([EmbRoot '/*_' Fo '*.wav']); 
f=StArFNExtract(fy,'name');
l=length(f); rp=randperm(l); 
f=f(rp);
f=strcat(EmbRoot,'/',f);
a=round(l*3/5);
b=round(l*4/5);
c=round(l*5/5);
TrL=f(1:a);
DeL=f(a+1:b);
TeL=f(b+1:c);







