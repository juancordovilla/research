function InfoWr(info,sso,eso,bnfo,doto)
%
%Sort
[ss,i]=sort(sso);
es=eso(i);
bnf=bnfo(i);
dot=doto(i);


Pos='-1';
%check if repetions
uss=unique(ss);
if(length(uss)~=length(ss)); fprintf('WARNING: repetitions in ss\n'); end
%
en=length(ss); %events number
fi=fopen(info,'w');
for i=1:en
    fprintf(fi,'%d\t %d\t %s\t %s\t "%s"\n',ss(i),es(i),Pos,bnf{i},dot{i});     
end
fclose(fi);
%
fprintf('Written %s\n',info);


% %To listen and check one rand Vad annotation
% l=max(es);
% vad=zeros(1,l);
% EmbRoot='/home/jmorales/SpeechData/CHIME3_All/Emb';
% ir=round(rand(1)*en);
% for i=1:en
%     vad(ss(i):es(i))=1;    
%     if i==ir
%         
%         [pn, bn]=fileparts(info);
%         AudF=[EmbRoot '/' bn '.wav' ];
%         [y,Fs]=audioread(AudF,[ss(i)+1,es(i)]); %step very slow if not selected interval in advance
%         plot(y)
%         soundsc(y(:,6),Fs);        
%         fprintf('%d\t %d\t %s\t %s\t "%s"\n',ss(i),es(i),Pos,bnf{i},dot{i}); 
%         pause    
%     end        
% end
% %plot(vad), ylim([0 1.5])

