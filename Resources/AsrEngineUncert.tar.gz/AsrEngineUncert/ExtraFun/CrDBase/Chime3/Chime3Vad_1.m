function Chime3Vad_1
%Create Database for VAD experiments
% First: create clean reverb signals (Dev and Tr) (at random positions of
% the considering "house" or "ambient")


%
%IRoot='/home/jmorales/SpeechData/CHIME3_All/Tr';
%fo={'tr05_bus_simu' 'tr05_ped_simu' 'tr05_str_simu' 'tr05_caf_simu'};
IRoot='/home/jmorales/SpeechData/CHIME3_All/Dev';
fo={'dt05_caf_simu' 'dt05_str_simu' 'dt05_bus_simu' 'dt05_ped_simu'};

%
ORoot=['/home/jmorales/SpeechData/CHIME3_All/NoisyEmb/Aux']; [x,x,x]=mkdir(ORoot);


%
for i=1:length(fo)     
    DX=[ORoot '/' fo{i} '']; 
    DY=[IRoot '/' fo{i}];    
    CrClDir(DX,DY,[DY '_noise']);    
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CrClDir(DX,DY,DN)
%

[x,x,x]=mkdir(DX);

f=dir([DY '/*.wav']); 
l=size(f,1); 


for i=1:l
    
    
    fy=[DY '/' f(i).name];
    fn=[DN '/' f(i).name];
    fx=[DX '/' f(i).name];
    [y Fs]=audioread(fy);
    [n Fs]=audioread(fn);
    x=y-n;    
    
    audiowrite(fx,x,Fs);
    
%     
%     subplot(311), plot(y),
%     subplot(312), plot(n),
%     subplot(313), plot(x),
%     pause

    fprintf('%d/%d\n',i,l);
    
    
end
fprintf('Written %s\n',fx);
