function WriteInfo(S,fn)
%
IsolN=length(S.st);
fi=fopen(fn,'w');
for i=1:IsolN
    fprintf(fi,'%s \t %s \t %s \t  %s \n',S.st{i},S.en{i},S.pos{i},S.bn{i});
    %fprintf('%s\t%s\n', S.bn{i},S.Trans{i});
    
end
fclose(fi);
