function [ys,MicO]=All2MicSign(ya,AllMic,Mic)
%All signal To Microphone Signal
%AllMic: All Microphone labels
%Mic: Microphone labels
%MicO:Mic Ouput

MicN=length(Mic);

[ns,AllMicN]=size(ya);


if AllMicN==1;
    fprintf('WARNING in All2MicSign: AllMicN=1 and not microphone selection\n');
    MicO={'-1'};
    ys=ya;
else
    ys=zeros(ns,MicN);
    MicO=cell(1,MicN);
    for i=1:MicN
        t=strcmp(AllMic,Mic{i});   
        if sum(t)~=1; fprintf('ERROR in All2MicSign: not found mic label %s\n',Mic{i}); end        
        MicO{i}=AllMic{t};
        ys(:,i)=ya(:,t);    
    end
end







