#!/bin/csh

# Preparation for CTK
# 1)  Enter in csh 2) source initCTKssc.csh (change CTKROOT)
# 3) ctk ../RECSTAGES/TESTMD/decoders/A2decode_classic.ctk
 

# Root directory for this version of CTK
setenv CTKROOT /clusterFS/home/user/jamc/SPEECHDATA/Softwares/CTK11
setenv CTKLOCAL ${CTKROOT}/local
setenv PATH ${CTKROOT}/bin:${PATH}

# QTDIR should be the version built with the correct g++
# setenv QTDIR /usr/lib64/qt-3.3
# setenv QTDIR /usr/share/qt3
setenv QTDIR /usr/share/qt3
setenv PATH ${QTDIR}/bin:${PATH}

# Matlab
# setenv MATLABROOT /usr/local/matlab
# setenv LD_LIBRARY_PATH $MATLABROOT/sys/os/glnxa64:$MATLABROOT/bin/glnxa64:$QTDIR/lib
