function RSyncGridPr(Pr,GHome,ExMach)
%RSync to Grid a Program (dir or just a file)

%JHome=getenv('HOME');
JHome='/home2/jamc';

GPr=strrep(Pr, JHome, GHome);




switch ExMach
    case 'GRID'        
        GHostName='jmoralescordovilla@access.grid5000.fr'; %global
        %GHostName='jmoralescordovilla@access.nancy.grid5000.fr'; %locan INRIA
    case 'ALH'
        GHostName='jamc@alhambra.ugr.es';
end

%
if isdir(Pr)
    [GDir, bn]=fileparts(GPr);
    
    c=['rsync -r ' Pr ' ' GHostName ':' GDir];
else
    c=['rsync ' Pr ' ' GHostName ':' GPr];
end


fprintf('Synchronizing %s to %s:%s   .....\n',Pr,GHostName,GPr);
system(c);




