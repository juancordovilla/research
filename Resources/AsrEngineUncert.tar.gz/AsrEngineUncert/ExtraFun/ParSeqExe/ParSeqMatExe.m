function ParSeqMatExe(JobList,ParalDir,kind)
%Paralell Sequential Matlab Execution
%ParalDir: previusly cleaned and created


MainRoot='/clusterFS/home/user/jamc';


AsrRoot=[MainRoot '/AsrEngine'];
addpath([AsrRoot '/RECOGNIZER/ParSeqExe'])



%
job.email = 'moralescordovilla@tugraz.at';
job.type = 'matlab'; 
job.hardlimit.h_vmem = '12G'; 

%
fi=fopen(JobList,'r');
l=fgetl(fi); i=1;
while ischar(l)

    JobId=num2str(i);
    job.outputFile=[ParalDir '/out' JobId '.txt']; 
    job.errorFile=job.outputFile; 
     
    
    
    [job.workingDirectory,job.command,job.hardlimit.h_vmem]=AnalL(l);
    
    [status]=MatJobSub(job,kind);
    
    l=fgetl(fi); i=i+1;
end



fclose(fi);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [WDir,C,Mem]=AnalL(l)
%Analyze Line
w=regexpi(l, ' +', 'split');

for i=1:length(w)
    a=w{5};
    
    w2=regexpi(a, '(', 'split');    
    [pn, bn]=fileparts(w2{1});
    WDir=pn;
    C=[bn '(' w2{2}];
end

a=w{4};
if(strcmp(a,'-1'))
    Mem='4G';
end


