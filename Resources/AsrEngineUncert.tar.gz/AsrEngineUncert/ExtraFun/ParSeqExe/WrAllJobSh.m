function WrAllJobSh(AllJob,JobS)
%Wr All Jobs in Sh script

l=length(JobS);
fi=fopen(AllJob,'w');
fprintf(fi,'#!/bin/bash\n\n');

for i=1:l       
    fprintf(fi,'%s\n',JobS{i});    
end

fclose(fi);

fprintf('Written: %s\n',AllJob);
