function PrintStEO(JobC)
%

l=length(JobC);
%for i=1:l
for i=1:l    
  
    StO=JobC{i};
    
    fprintf('****************************************************************************\n');
    fprintf('Showing: %s\n',StO);
    fprintf('****************************************************************************\n');
    
    c=['cat ' StO];
    system(c);
    
    
    
    fprintf('Showed: %s\n',StO);
    system(['head --l 4 ' StO]);    
    fprintf('****************************************************************************\n');
    
   pause
    


end
