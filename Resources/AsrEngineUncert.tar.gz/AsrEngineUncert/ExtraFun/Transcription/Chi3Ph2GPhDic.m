function Chi3Ph2GPhDic
%Chime3 Phones (fine) To Gross Phones Dictionary

%Input
IPhF='/home/jmorales/SpeechData/CHIME3_All/LM/lang_test_tgpr_5k/phones.txt';
ISetF='/home/jmorales/SpeechData/CHIME3_All/LM/lang_test_tgpr_5k/phones/sets.txt';


%Output
OPhF='/home/jmorales/SpeechData/CHIME3_All/LM/lang_test_tgpr_5k/Ph2GPhDic.txt';

C=ReTxtF(ISetF,'Word');
K=[];
V=[];
for i=1:length(C)
    CC=FindClasRepr(C{i});        
    b=RepCell(CC,1,length(C{i}));
    V=[V b];    
    K=[K C{i}];       
end

[UK,i]=unique(K);
UV=V(i);

WrDictF(OPhF,UK,UV);








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function b=RepCell(a,l1,l2)
%
b=cell(l1,l2);
for i=1:l1
    for j=1:l2
        b{i,j}=a;
    end
end


function CC=FindClasRepr(C)
%
a=strsplit(C{1},'_');
CC=a{1};