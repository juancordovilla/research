function FeatScp2TexTran(TexTrans,FeatScp,TransDir,dy)
%Feat Scp file To Text Transcription (BN and Transcription dictionary)




[pn, bn]=fileparts(dy); C=strsplit(bn,'_'); bn=[C{1} '_' C{3}];

ABNTransDic=[TransDir '/' bn '.trn_all'];

%
[ABN,ATrans]=ReDictF(ABNTransDic); %Slow function


[FBN,x]=ReDictF(FeatScp);

%
[FTrans]=Key2ValDict(FBN,ABN,ATrans);  %Function in /Fun

%
WrDictF(TexTrans,FBN,FTrans); %Function in /Fun



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





